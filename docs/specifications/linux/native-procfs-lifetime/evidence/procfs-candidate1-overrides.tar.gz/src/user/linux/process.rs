//! Linux processes: `execve` setup and thread execution.
//!
//! [`LinuxProcess::spawn`] performs the work of `execve` for the initial
//! program — map the stack, load the ELF image and its interpreter, write
//! the argument/environment/auxiliary vectors, and set the entry registers
//! — and [`LinuxProcess::run`] executes the process's threads until the
//! process exits, routing each CPU event to the system-call layer or to
//! signal handling.

use std::path::PathBuf;
use std::sync::Arc;

use super::abi::errno::Errno;
use super::abi::{DEFAULT_STACK_LIMIT, LinuxAbi};
use super::arch::{CpuOptions, GuestCpu};
use super::fs::Vfs;
use super::fs::fd::{FdTable, FileObject, FileType, NOFILE_HARD, NOFILE_SOFT, OpenFile};
use super::loader::{ImageFile, LoadError, LoadedProgram};
use super::signal::deliver::SyscallEntry;
use super::signal::frame::FaultState;
use super::signal::{AltStack, SigInfo, SigPending, signal_name};
use super::stack::{InitialStack, StackError};
use super::syscall;
use super::wait::Blocked;
use crate::user::mm::AddressSpace;

/// Instructions per scheduling slice for cores whose run budget RAX sets
/// (AArch64, RV64); the x86-64 core yields on its own ~1 ms timer.
pub const DEFAULT_SLICE_INSNS: u64 = 1 << 20;

/// Default guest-memory arena: 16 GiB of address space, committed by the
/// host only as pages are touched.
pub const DEFAULT_ARENA_BYTES: u64 = 16 << 30;

/// Kernel release reported by `uname`: the UAPI revision RAX implements.
pub const DEFAULT_KERNEL_RELEASE: &str = "6.19.0";

/// How to start a process.
#[derive(Clone, Debug)]
pub struct LinuxConfig {
    /// `argv`, including `argv[0]`.
    pub argv: Vec<Vec<u8>>,
    /// `envp`.
    pub envp: Vec<Vec<u8>>,
    /// Guest path of the executable (`AT_EXECFN`, `/proc/self/exe`).
    pub exec_path: String,
    /// Guest root overlay (QEMU `-L`).
    pub sysroot: Option<PathBuf>,
    /// Permit external host services. Embedded profiles set this false.
    pub host_services: bool,
    /// A closed immutable file namespace, with the main image added at spawn.
    /// `None` preserves the host/sysroot filesystem. Other host services are
    /// controlled separately; this field alone is not process isolation.
    pub supplied_files: Option<crate::user::supplied_fs::Files>,
    /// Absolute guest working directory.
    pub cwd: String,
    /// `RLIMIT_STACK` soft limit in bytes.
    pub stack_limit: u64,
    /// Guest-memory arena size in bytes.
    pub arena_bytes: u64,
    /// CPU options.
    pub cpu: CpuOptions,
    /// Log every system call to standard error (`strace` format).
    pub strace: bool,
    /// Standard streams: inherited host descriptors or bounded captured buffers.
    pub console: crate::user::console::Console,
    /// Seed for `AT_RANDOM` and `getrandom`; `None` reads the host's
    /// entropy source.
    pub seed: Option<u64>,
    /// `uname -r`.
    pub kernel_release: String,
    /// Instructions per scheduling slice (AArch64, RV64).
    pub slice_insns: u64,
    /// Create new processes by forking the host process (`fork`, `vfork`,
    /// `clone` without `CLONE_THREAD`); otherwise they are `ENOSYS`. A
    /// forked child never returns from [`LinuxProcess::run`]: it ends the
    /// host process when the guest process ends. Enable it only in a
    /// single-threaded host process: a forked child has only the calling
    /// thread, so locks other threads held stay held. The first new
    /// process installs the emulator's host `SIGCHLD` handler.
    pub processes: bool,
    /// The System V IPC namespace's directory; `None` for the host user's
    /// default one.
    pub ipc_dir: Option<PathBuf>,
    /// Where inotify instances come from.
    pub fsnotify: super::fsnotify::Backend,
}

impl LinuxConfig {
    /// A closed process using supplied files, bounded captured streams, virtual
    /// identity and emulated threads. External host services are denied.
    pub fn embedded(
        exec_path: impl Into<String>,
        argv: Vec<Vec<u8>>,
        envp: Vec<Vec<u8>>,
        input: Vec<u8>,
        console_capacity: usize,
    ) -> Result<Self, SpawnError> {
        // Construct explicitly: do not read the embedding application's cwd.
        Ok(Self {
            argv,
            envp,
            exec_path: exec_path.into(),
            sysroot: None,
            host_services: false,
            supplied_files: Some(Default::default()),
            cwd: "/".into(),
            stack_limit: DEFAULT_STACK_LIMIT,
            arena_bytes: 128 << 20,
            cpu: CpuOptions::default(),
            strace: false,
            console: crate::user::console::Console::Captured(
                crate::user::console::CapturedConsole::new(input, console_capacity)
                    .map_err(|e| SpawnError::Unsupported(e.to_string()))?,
            ),
            seed: Some(0),
            kernel_release: DEFAULT_KERNEL_RELEASE.into(),
            slice_insns: DEFAULT_SLICE_INSNS,
            processes: false,
            ipc_dir: None,
            fsnotify: super::fsnotify::Backend::Disabled,
        })
    }

    /// A configuration for `exec_path` with `argv` and the defaults.
    pub fn new(exec_path: impl Into<String>, argv: Vec<Vec<u8>>, envp: Vec<Vec<u8>>) -> Self {
        let cwd = std::env::current_dir()
            .map(|p| p.to_string_lossy().into_owned())
            .unwrap_or_else(|_| "/".into());
        LinuxConfig {
            argv,
            envp,
            exec_path: exec_path.into(),
            sysroot: None,
            host_services: true,
            supplied_files: None,
            cwd,
            stack_limit: DEFAULT_STACK_LIMIT,
            arena_bytes: DEFAULT_ARENA_BYTES,
            cpu: CpuOptions::default(),
            strace: false,
            console: Default::default(),
            seed: None,
            kernel_release: DEFAULT_KERNEL_RELEASE.into(),
            slice_insns: DEFAULT_SLICE_INSNS,
            processes: false,
            ipc_dir: None,
            fsnotify: Default::default(),
        }
    }
}

/// How a process ended.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum ExitStatus {
    /// `exit_group(code)`; only the low 8 bits are reported to a parent.
    Exited(i32),
    /// Killed by a signal.
    Signaled {
        /// The signal.
        info: SigInfo,
        /// PC of the thread that received it.
        pc: u64,
        /// Whether the signal's default action is to dump core
        /// (`sig_kernel_coredump`). No core file is written: the default
        /// `RLIMIT_CORE` soft limit is zero.
        core: bool,
    },
    /// The emulator could not continue.
    Internal(String),
}

impl ExitStatus {
    /// The status a shell reports: `code & 0xff`, or `128 + signal`.
    pub fn shell_code(&self) -> i32 {
        match self {
            ExitStatus::Exited(code) => code & 0xff,
            ExitStatus::Signaled { info, .. } => 128 + info.signo,
            ExitStatus::Internal(_) => 125,
        }
    }
}

impl std::fmt::Display for ExitStatus {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            ExitStatus::Exited(code) => write!(f, "exited with status {}", code & 0xff),
            ExitStatus::Signaled { info, pc, core } => {
                write!(
                    f,
                    "killed by {} (si_code {}",
                    signal_name(info.signo),
                    info.code
                )?;
                // Faults carry si_addr; signals sent by a process carry its
                // PID (SI_USER, SI_TKILL, SI_QUEUE, ...).
                if info.code > 0 && info.code != super::signal::code::SI_KERNEL {
                    write!(f, ", address {:#x}", info.addr())?;
                } else if info.code <= 0 {
                    write!(f, ", sent by pid {}", info.pid())?;
                }
                write!(
                    f,
                    ") at pc {pc:#x}{}",
                    if *core { "; core not dumped" } else { "" }
                )
            }
            ExitStatus::Internal(why) => write!(f, "emulator error: {why}"),
        }
    }
}

/// Why a process could not be started.
#[derive(Debug)]
pub enum SpawnError {
    /// The image is not an executable for a supported ABI.
    Unsupported(String),
    /// Loading the image failed.
    Load(LoadError),
    /// Building the initial stack failed.
    Stack(StackError),
    /// The guest address space could not be created.
    Memory(crate::user::mm::MmError),
}

impl std::fmt::Display for SpawnError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            SpawnError::Unsupported(why) => write!(f, "{why}"),
            SpawnError::Load(e) => write!(f, "{e}"),
            SpawnError::Stack(e) => write!(f, "{e}"),
            SpawnError::Memory(e) => write!(f, "{e}"),
        }
    }
}

impl std::error::Error for SpawnError {}

/// A `struct k_sigaction`.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct SigAction {
    /// `SIG_DFL` (0), `SIG_IGN` (1), or a handler address.
    pub handler: u64,
    /// `SA_*` flags.
    pub flags: u64,
    /// `sa_restorer`.
    pub restorer: u64,
    /// Signals blocked while the handler runs.
    pub mask: u64,
}

/// Resource limits (`RLIMIT_*`), as `(soft, hard)`.
pub type Rlimits = [(u64, u64); 16];

/// `RLIM_INFINITY`.
pub const RLIM_INFINITY: u64 = u64::MAX;

/// Linux's initial limits (`include/asm-generic/resource.h` `INIT_RLIMITS`
/// with the usual distribution `RLIMIT_NOFILE` and `RLIMIT_STACK` values).
pub fn default_rlimits(stack_limit: u64) -> Rlimits {
    let inf = (RLIM_INFINITY, RLIM_INFINITY);
    [
        inf,                          // RLIMIT_CPU
        inf,                          // RLIMIT_FSIZE
        inf,                          // RLIMIT_DATA
        (stack_limit, RLIM_INFINITY), // RLIMIT_STACK
        (0, RLIM_INFINITY),           // RLIMIT_CORE
        inf,                          // RLIMIT_RSS
        (63_000, 63_000),             // RLIMIT_NPROC
        (NOFILE_SOFT, NOFILE_HARD),   // RLIMIT_NOFILE
        (8 << 20, 8 << 20),           // RLIMIT_MEMLOCK
        inf,                          // RLIMIT_AS
        inf,                          // RLIMIT_LOCKS
        (63_000, 63_000),             // RLIMIT_SIGPENDING
        (819_200, 819_200),           // RLIMIT_MSGQUEUE
        (0, 0),                       // RLIMIT_NICE
        (0, 0),                       // RLIMIT_RTPRIO
        inf,                          // RLIMIT_RTTIME
    ]
}

/// A deterministic or host-seeded byte source for `AT_RANDOM`/`getrandom`.
#[derive(Clone, Debug)]
pub struct Entropy {
    state: Option<u64>,
}

impl Entropy {
    fn new(seed: Option<u64>) -> Self {
        Entropy { state: seed }
    }

    /// Fills `buf`: SplitMix64 output when seeded, host entropy otherwise.
    pub fn fill(&mut self, buf: &mut [u8]) -> Result<(), Errno> {
        match &mut self.state {
            Some(s) => {
                for chunk in buf.chunks_mut(8) {
                    *s = s.wrapping_add(0x9E37_79B9_7F4A_7C15);
                    let mut z = *s;
                    z = (z ^ (z >> 30)).wrapping_mul(0xBF58_476D_1CE4_E5B9);
                    z = (z ^ (z >> 27)).wrapping_mul(0x94D0_49BB_1331_11EB);
                    z ^= z >> 31;
                    chunk.copy_from_slice(&z.to_le_bytes()[..chunk.len()]);
                }
                Ok(())
            }
            None => getrandom::fill(buf).map_err(|_| Errno(super::abi::errno_table::EIO)),
        }
    }
}

/// Memory-management bookkeeping (`struct mm_struct` fields RAX needs).
#[derive(Clone, Debug)]
pub struct MmState {
    /// `start_brk`.
    pub start_brk: u64,
    /// Current break.
    pub brk: u64,
    /// Top of the top-down mmap area.
    pub mmap_base: u64,
    /// The loaded program.
    pub program: LoadedProgram,
    /// The initial stack layout.
    pub stack: InitialStack,
    /// The lock flags new mappings take (`mm->def_flags & VM_LOCKED_MASK`,
    /// set by `mlockall(MCL_FUTURE)`); a new address space has none.
    pub def_lock: u32,
    /// `mm->locked_vm`, in pages: kept as the kernel keeps it, a count
    /// raised and lowered by the calls rather than the pages of the locked
    /// VMAs (`MREMAP_DONTUNMAP` unlocks the old range without lowering it).
    pub locked_vm: u64,
    /// `mm->pinned_vm`, in pages: memory io_uring pinned for its buffers.
    /// Shared with the rings that charged it, which may outlive the
    /// address space.
    pub pinned_vm: std::sync::Arc<std::sync::atomic::AtomicU64>,
}

/// Process-wide state shared by all threads.
pub struct ProcState {
    /// The ABI.
    pub abi: LinuxAbi,
    /// The address space.
    pub space: AddressSpace,
    /// Path resolution.
    pub vfs: Vfs,
    /// Descriptors.
    pub fds: FdTable,
    /// Process ID (the host process ID).
    pub pid: i32,
    /// Parent process ID.
    pub ppid: i32,
    /// `(uid, euid, gid, egid)`.
    pub creds: (u32, u32, u32, u32),
    /// Supplementary group IDs, sorted (`group_info`).
    pub groups: Vec<u32>,
    /// Memory bookkeeping.
    pub mm: MmState,
    /// Resource limits.
    pub rlimits: Rlimits,
    /// File-creation mask.
    pub umask: u32,
    /// Signal dispositions, indexed by signal number minus one.
    pub sigactions: [SigAction; 64],
    /// The thread-group leader's `comm`, kept for `/proc/<pid>/comm` after
    /// the leader exits; each thread's own is [`Thread::comm`].
    pub comm: Vec<u8>,
    /// Guest path of the executable.
    pub exe_path: String,
    /// Host path of the executable, when it came from the host.
    pub exe_host_path: Option<PathBuf>,
    /// The auxiliary vector as written, for `/proc/self/auxv`.
    pub auxv: Vec<(u64, u64)>,
    /// `/proc/self/cmdline` contents.
    pub cmdline: Vec<u8>,
    /// `/proc/self/environ` contents.
    pub environ: Vec<u8>,
    /// Entropy source.
    pub entropy: Entropy,
    /// The configuration the process was started with.
    pub config: LinuxConfig,
    /// Exit status once the process has exited.
    pub exit: Option<ExitStatus>,
    /// Next thread ID to assign.
    pub next_tid: i32,
    /// Exact issued thread IDs, retained after exit so procfs cannot name an
    /// unrelated host task. Sequential IDs use one compact inclusive run.
    pub procfs_thread_ids: super::procfs::ThreadIds,
    /// `personality(2)` value.
    pub persona: u32,
    /// `prctl(PR_SET_DUMPABLE)` value.
    pub dumpable: u64,
    /// `prctl(PR_SET_PDEATHSIG)` value.
    pub pdeathsig: i32,
    /// Signals pending for the process (`signal->shared_pending`).
    pub shared_pending: SigPending,
    /// Address of the signal-return trampoline in the `[vdso]` page (arm64
    /// `__kernel_rt_sigreturn`, riscv `__vdso_rt_sigreturn`); zero on x86-64,
    /// whose handlers must supply `SA_RESTORER`.
    pub sigtramp: u64,
    /// `SIGNAL_UNKILLABLE`: the process is its PID namespace's init (PID 1)
    /// and default-action signals do not kill it.
    pub unkillable: bool,
    /// Interval timers.
    pub itimers: super::timers::Itimers,
    /// POSIX timers (`timer_create`).
    pub timers: super::posix_timers::PosixTimers,
    /// Futex wait queues.
    pub futex: super::futex::FutexTable,
    /// `signal->curr_target`: the thread where the search for one to take a
    /// process-directed signal starts.
    pub curr_target: i32,
    /// The thread-group leader's final signal mask once it has exited while
    /// other threads run: it remains a zombie (`delay_group_leader`) that
    /// signals can still name.
    pub leader_exit: Option<u64>,
    /// The thread that last ran in user mode: another one resuming there
    /// was switched out in between (`rseq_sched_switch_event`).
    pub last_user: Option<i32>,
    /// Child processes.
    pub children: super::children::Children,
    /// The tasks this process's pidfds name.
    pub pidfds: super::fs::pidfd::Registry,
    /// Set in a forked process: its end of the status pipe to its parent.
    pub forked: Option<super::children::ForkedSelf>,
    /// `self_exec_id`: how many times the process called `execve`.
    pub exec_id: u64,
    /// System V IPC.
    pub ipc: super::ipc::IpcState,
    /// Linux AIO contexts (`mm->ioctx_table`).
    pub aio: super::aio::Table,
    /// The link to the parent process (made at `fork`; none for the first
    /// process), along which it traces or is traced.
    pub parent_link: Option<super::ptrace::Link>,
    /// The threads this process traces (`ptraced`).
    pub tracees: super::ptrace::Tracees,
    /// Links to tracees that are not children, by PID (their parents,
    /// tracees of this process, passed them over as they forked them).
    pub adopted: Vec<(i32, super::ptrace::Link)>,
    /// Ancestors reached through `adopted`, excluding the immediate parent.
    pub ancestor_pids: Vec<i32>,
    /// The link to this process's tracer (its PID) when the tracer is
    /// neither its parent nor a child.
    pub tracer_link: Option<(i32, super::ptrace::Link)>,
    /// The group stop a traced process is in (`SIGNAL_STOP_STOPPED` or
    /// `group_stop_count`) and its signal (`group_exit_code`). An untraced
    /// process's group stop stops the host process instead.
    pub group_stop: Option<i32>,
    /// The emulated file-system notification namespace, when the backend
    /// is the emulated one and its namespace could be opened.
    #[cfg(unix)]
    pub fsnotify: Option<std::sync::Arc<super::fsnotify::hub::Hub>>,
    /// What the running image keeps open (its executable and interpreter).
    pub exec_keep: Vec<crate::user::mm::Keep>,
    /// The pages io_uring locked for each user, by real user ID
    /// (`user->locked_vm`). The kernel's count is shared by all of the
    /// user's processes; this is what this process charged.
    pub locked_vm_users:
        std::collections::BTreeMap<u32, std::sync::Arc<std::sync::atomic::AtomicU64>>,
    /// The io_uring instances with entries in their poll tables (poll
    /// requests and requests waiting for their files), looked at again as
    /// the process makes system calls.
    pub uring_parked: Vec<std::sync::Weak<super::uring::Ring>>,
}

/// A Linux thread.
pub struct Thread {
    /// Thread ID.
    pub tid: i32,
    /// The CPU.
    pub cpu: GuestCpu,
    /// `set_tid_address` pointer, cleared and woken at exit.
    pub clear_child_tid: u64,
    /// `set_robust_list` head and length.
    pub robust_list: (u64, u64),
    /// The head a 32-bit call registered (`compat_robust_list`), a list of
    /// its own that exit also releases.
    pub compat_robust_list: u64,
    /// Blocked signals.
    pub sigmask: u64,
    /// Signals pending for this thread (`task->pending`).
    pub pending: SigPending,
    /// The alternate signal stack.
    pub altstack: AltStack,
    /// The mask a signal-waiting call replaced, restored on the return to
    /// user mode unless a handler frame saved it (`saved_sigmask` with
    /// `TIF_RESTORE_SIGMASK`).
    pub saved_sigmask: Option<u64>,
    /// The system call being returned from, for restart processing.
    pub syscall: Option<SyscallEntry>,
    /// Architectural fault record for signal frames.
    pub fault: FaultState,
    /// How `restart_syscall` continues an interrupted call
    /// (`restart_block`); `None` is `do_no_restart_syscall`.
    pub restart: Option<syscall::RestartBlock>,
    /// `TIF_SIGPENDING`: a signal may be pending for the thread. Set when a
    /// signal is sent that the thread should take (`signal_wake_up`) and
    /// recomputed from its mask (`recalc_sigpending`); a sleeping call ends
    /// when it is set.
    pub sigpending: bool,
    /// `real_blocked`: the mask `rt_sigtimedwait` replaced while it sleeps
    /// with the waited-for signals unblocked.
    pub real_blocked: u64,
    /// The system call the thread sleeps in.
    pub blocked: Option<Blocked>,
    /// `set_child_tid` (`CLONE_CHILD_SETTID`): receives the TID before the
    /// thread first returns to user mode.
    pub set_child_tid: u64,
    /// The `CLONE_VFORK` parent sleeping until this thread exits.
    pub vfork_parent: Option<i32>,
    /// `comm`: the thread's name (at most 15 bytes).
    pub comm: Vec<u8>,
    /// `PFA_NO_NEW_PRIVS` (`prctl(PR_SET_NO_NEW_PRIVS)`): kept across
    /// `execve` and inherited by new threads and processes.
    pub no_new_privs: bool,
    /// x86-64 `TIF_NOTSC` (`prctl(PR_SET_TSC)`, seccomp's strict mode):
    /// `RDTSC` faults. Kept across `execve` and inherited.
    pub notsc: bool,
    /// Its seccomp mode and filters.
    pub seccomp: super::seccomp::Seccomp,
    /// Its scheduling attributes and I/O priority.
    pub sched: super::priority::Sched,
    /// Its semaphore undo list (`sysvsem.undo_list`), if it has one.
    pub sysvsem: Option<super::ipc::UndoList>,
    /// Its restartable-sequences registration and pending events.
    pub rseq: Option<super::rseq::Rseq>,
    /// Its tracer and the stop it is in (`task->ptrace`, `last_siginfo`).
    pub ptrace: Option<super::ptrace::Traced>,
    /// Its registered io_uring rings (`tctx->registered_rings`), empty
    /// until `IORING_REGISTER_RING_FDS`.
    pub uring_rings: Vec<Option<std::sync::Arc<super::uring::Ring>>>,
}

impl Thread {
    /// A thread with `cpu` in its initial signal state: nothing blocked or
    /// pending and no alternate stack.
    pub fn new(tid: i32, cpu: GuestCpu) -> Self {
        Thread {
            tid,
            cpu,
            clear_child_tid: 0,
            robust_list: (0, 0),
            compat_robust_list: 0,
            sigmask: 0,
            pending: SigPending::new(),
            altstack: AltStack::DISABLED,
            saved_sigmask: None,
            syscall: None,
            fault: FaultState::default(),
            restart: None,
            sigpending: false,
            real_blocked: 0,
            blocked: None,
            set_child_tid: 0,
            vfork_parent: None,
            comm: Vec::new(),
            no_new_privs: false,
            notsc: false,
            seccomp: Default::default(),
            sched: Default::default(),
            sysvsem: None,
            rseq: None,
            ptrace: None,
            uring_rings: Vec::new(),
        }
    }
}

/// The threads other than the one running a system call.
pub struct Peers<'a> {
    /// Threads before it in the list.
    pub lo: &'a mut [Thread],
    /// Threads after it.
    pub hi: &'a mut [Thread],
}

impl Peers<'_> {
    /// No other threads.
    pub fn none() -> Self {
        Peers {
            lo: &mut [],
            hi: &mut [],
        }
    }
}

/// Every thread of a process, one of which may be borrowed separately as
/// the running thread (`current`). Iteration follows the thread list: the
/// order of creation, the leader first.
pub struct Threads<'a> {
    lo: &'a mut [Thread],
    cur: Option<&'a mut Thread>,
    hi: &'a mut [Thread],
}

impl ProcState {
    /// When the earliest interval or POSIX timer that runs while the
    /// process sleeps expires.
    pub fn timer_deadline(&self) -> Option<std::time::Instant> {
        [self.itimers.next_deadline(), self.timers.next_deadline()]
            .into_iter()
            .flatten()
            .min()
    }
}

impl<'a> Threads<'a> {
    /// `threads`, with the one at index `running` as the current thread.
    pub fn split(threads: &'a mut [Thread], running: Option<usize>) -> Self {
        match running {
            None => Threads {
                lo: threads,
                cur: None,
                hi: &mut [],
            },
            Some(i) => {
                let (lo, rest) = threads.split_at_mut(i);
                let (cur, hi) = rest.split_first_mut().expect("running index is valid");
                Threads {
                    lo,
                    cur: Some(cur),
                    hi,
                }
            }
        }
    }

    /// The running thread `cur` and the others.
    pub fn with_current(cur: &'a mut Thread, peers: Peers<'a>) -> Self {
        Threads {
            lo: peers.lo,
            cur: Some(cur),
            hi: peers.hi,
        }
    }

    /// The running thread.
    pub fn current(&mut self) -> Option<&mut Thread> {
        self.cur.as_deref_mut()
    }

    /// The running thread's TID.
    pub fn running(&self) -> Option<i32> {
        self.cur.as_ref().map(|t| t.tid)
    }

    /// The thread with TID `tid`.
    pub fn get_mut(&mut self, tid: i32) -> Option<&mut Thread> {
        self.iter_mut().find(|t| t.tid == tid)
    }

    /// Whether a thread with TID `tid` exists.
    pub fn contains(&self, tid: i32) -> bool {
        self.iter().any(|t| t.tid == tid)
    }

    /// The threads in list order.
    pub fn iter(&self) -> impl Iterator<Item = &Thread> {
        self.lo
            .iter()
            .chain(self.cur.as_deref())
            .chain(self.hi.iter())
    }

    /// The threads in list order, mutably.
    pub fn iter_mut(&mut self) -> impl Iterator<Item = &mut Thread> {
        self.lo
            .iter_mut()
            .chain(self.cur.as_deref_mut())
            .chain(self.hi.iter_mut())
    }

    /// The number of threads.
    pub fn len(&self) -> usize {
        self.lo.len() + usize::from(self.cur.is_some()) + self.hi.len()
    }

    /// Whether there are no threads.
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

/// A running Linux process.
pub struct LinuxProcess {
    /// Process-wide state.
    pub state: ProcState,
    /// Live threads.
    pub threads: Vec<Thread>,
    pub(super) scheduler: super::sched::Scheduler,
}

/// Wraps an inherited host descriptor as a guest standard stream with the
/// host descriptor's access mode.
#[cfg(unix)]
fn stdio(fd: i32, host: std::io::Result<std::os::fd::OwnedFd>) -> Option<Arc<OpenFile>> {
    let owned = host.ok()?;
    let mode = super::host::access_mode(&owned).ok()?;
    let file = std::fs::File::from(owned);
    let ftype = file
        .metadata()
        .map(|m| super::fs::file_type_of(&m))
        .unwrap_or(FileType::CharDevice);
    Some(OpenFile::new(
        FileObject::Host(file),
        ftype,
        format!("/dev/fd/{fd}"),
        None,
        mode,
    ))
}

impl LinuxProcess {
    /// Performs `execve` of `image` as the process's initial program.
    pub fn spawn(config: LinuxConfig, image: ImageFile) -> Result<Self, SpawnError> {
        super::embedding::validate_host(
            &config,
            super::HOST_SERVICES_AVAILABLE,
            crate::user::mm::FrameArena::supports_shared_mappings(),
        )?;
        if !config.host_services {
            super::embedding::validate(&config)?;
        }
        let exe_guest = super::fs::join_guest(&config.cwd, &config.exec_path);
        let (vfs, exe_path, exe_host) = if let Some(files) = &config.supplied_files {
            if config.sysroot.is_some() {
                return Err(SpawnError::Unsupported(
                    "supplied files and a host sysroot are mutually exclusive".into(),
                ));
            }
            let files = files
                .with_file(exe_guest.clone(), image.bytes.clone())
                .map_err(|e| SpawnError::Unsupported(e.to_string()))?;
            let vfs = Vfs::closed(files, config.cwd.clone())
                .map_err(|e| SpawnError::Unsupported(e.to_string()))?;
            (vfs, exe_guest, None)
        } else {
            let vfs = Vfs::new(config.sysroot.clone(), config.cwd.clone());
            // Host /proc/self/exe carries the symlink-resolved executable path.
            let host = vfs
                .host_path(&exe_guest, true)
                .map_err(|e| SpawnError::Unsupported(e.to_string()))?;
            let path = std::fs::canonicalize(&host)
                .map(|p| vfs.guest_path_of(&p))
                .unwrap_or(exe_guest);
            (vfs, path, Some(host))
        };
        let mut creds = (0, 0, 0, 0);
        let mut ppid = 1;
        let mut groups = Vec::new();
        let mut umask = 0o022;
        #[cfg(unix)]
        if config.host_services {
            creds = super::host::credentials();
            ppid = super::host::ppid();
            groups = super::host::groups();
            umask = super::host::umask() & 0o777;
        }
        let mut entropy = Entropy::new(config.seed);
        let img = super::exec::load_image(
            super::exec::ImageRequest {
                bytes: image.bytes.clone(),
                exe_path,
                exe_host,
                execfn: config.exec_path.as_bytes(),
                comm: super::exec::comm_of(config.exec_path.as_bytes()),
                argv: &config.argv,
                envp: &config.envp,
                stack_limit: config.stack_limit,
                arena_bytes: config.arena_bytes,
                cpu: &config.cpu,
                persona: 0,
            },
            &vfs,
            creds,
            &mut entropy,
        )?;
        let mut fds = FdTable::new();
        match &config.console {
            crate::user::console::Console::Captured(console) => {
                use crate::user::console::OutputStream;
                for (fd, stream) in [
                    (0, None),
                    (1, Some(OutputStream::Stdout)),
                    (2, Some(OutputStream::Stderr)),
                ] {
                    let file = OpenFile::new(
                        FileObject::Console {
                            console: console.clone(),
                            stream,
                        },
                        FileType::CharDevice,
                        format!("/dev/fd/{fd}"),
                        None,
                        if stream.is_none() {
                            super::abi::open::O_RDONLY
                        } else {
                            super::abi::open::O_WRONLY
                        },
                    );
                    fds.install_at(fd, file, false, NOFILE_HARD)
                        .expect("standard descriptors are below the limit");
                }
            }
            #[cfg(unix)]
            crate::user::console::Console::Host => {
                use std::os::fd::AsFd;
                for (fd, host) in [
                    (0, std::io::stdin().as_fd().try_clone_to_owned()),
                    (1, std::io::stdout().as_fd().try_clone_to_owned()),
                    (2, std::io::stderr().as_fd().try_clone_to_owned()),
                ] {
                    if let Some(file) = stdio(fd, host) {
                        fds.install_at(fd, file, false, NOFILE_HARD)
                            .expect("standard descriptors are below the limit");
                    }
                }
            }
            #[cfg(windows)]
            crate::user::console::Console::Host => {
                return Err(SpawnError::Unsupported(
                    "closed Linux embedding requires captured console".into(),
                ));
            }
        }

        let pid = if config.host_services {
            super::host::pid()
        } else {
            super::embedding::PID
        };
        let config_ipc_dir = config.ipc_dir.clone();
        #[cfg(unix)]
        let fsnotify = match &config.fsnotify {
            super::fsnotify::Backend::Disabled => None,
            super::fsnotify::Backend::Host => None,
            super::fsnotify::Backend::Emulated(dir) => super::fsnotify::hub::Hub::open(
                dir.clone()
                    .unwrap_or_else(super::fsnotify::hub::Hub::default_dir),
            )
            .ok(),
        };
        let host_services = config.host_services;
        let state = ProcState {
            abi: img.abi,
            space: img.space,
            vfs,
            fds,
            pid,
            ppid,
            creds,
            // A new process inherits its parent's groups.
            groups,
            mm: img.mm,
            rlimits: default_rlimits(config.stack_limit),
            // A new process inherits its parent's umask.
            umask,
            sigactions: [SigAction::default(); 64],
            comm: img.comm,
            exe_path: img.exe_path,
            exe_host_path: img.exe_host_path,
            auxv: img.auxv,
            cmdline: img.cmdline,
            environ: img.environ,
            entropy,
            config,
            exit: None,
            next_tid: pid + 1,
            procfs_thread_ids: super::procfs::ThreadIds::new(pid),
            persona: img.persona,
            dumpable: 1,
            pdeathsig: 0,
            shared_pending: SigPending::new(),
            sigtramp: img.sigtramp,
            unkillable: pid == 1,
            itimers: Default::default(),
            timers: Default::default(),
            futex: Default::default(),
            curr_target: pid,
            leader_exit: None,
            last_user: None,
            children: Default::default(),
            pidfds: Default::default(),
            forked: None,
            exec_id: 0,
            ipc: {
                #[cfg(unix)]
                {
                    if host_services {
                        super::ipc::IpcState::new(config_ipc_dir)
                    } else {
                        super::ipc::IpcState::disabled()
                    }
                }
                #[cfg(not(unix))]
                super::ipc::IpcState::disabled()
            },
            aio: Default::default(),
            parent_link: None,
            tracees: Default::default(),
            adopted: Vec::new(),
            ancestor_pids: Vec::new(),
            tracer_link: None,
            group_stop: None,
            #[cfg(unix)]
            fsnotify,
            exec_keep: Vec::new(),
            locked_vm_users: Default::default(),
            uring_parked: Vec::new(),
        };
        let mut leader = Thread::new(pid, img.cpu);
        leader.comm = state.comm.clone();
        Ok(LinuxProcess {
            state,
            threads: vec![leader],
            scheduler: Default::default(),
        })
    }

    /// The ABI.
    pub fn abi(&self) -> LinuxAbi {
        self.state.abi
    }

    /// The address space.
    pub fn space(&self) -> &AddressSpace {
        &self.state.space
    }
}

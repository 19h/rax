#![allow(clippy::literal_string_with_formatting_args)]

use byteorder::{ByteOrder, LittleEndian};
use solana_sbpf::{
    ebpf,
    elf::{get_ro_region, ElfError, Executable, Section},
    elf_parser::{
        consts::{ELFCLASS32, ELFCLASS64, ELFDATA2LSB, ELFDATA2MSB, ELFOSABI_NONE, EM_BPF, ET_REL},
        types::{Elf64Ehdr, Elf64Phdr, Elf64Shdr},
        Elf64, ElfParserError, DEBUG_SYMBOL_NAME_LENGTH_MAXIMUM, SECTION_NAME_LENGTH_MAXIMUM,
    },
    memory_region::{AccessType, MemoryMapping},
    program::{BuiltinFunctionDefinition, BuiltinProgram, SBPFVersion},
    vm::Config,
};
use std::{fs::File, io::Read, sync::Arc};
use test_utils::{assert_error, syscalls, TestContextObject};

type ElfExecutable = Executable<TestContextObject>;

fn loader() -> Arc<BuiltinProgram<TestContextObject>> {
    let mut loader = BuiltinProgram::new_loader(Config::default());
    syscalls::SyscallString::register(&mut loader, "log").unwrap();
    syscalls::SyscallU64::register(&mut loader, "log_64").unwrap();
    Arc::new(loader)
}

#[test]
fn test_strict_header() {
    let elf_bytes = std::fs::read("tests/elfs/strict_header.so").expect("failed to read elf file");
    let loader = loader();

    // Check that the unmodified file can be parsed
    {
        let loader = Arc::new(BuiltinProgram::new_loader(Config {
            enable_symbol_and_section_labels: true,
            ..Config::default()
        }));
        let executable = ElfExecutable::load(&elf_bytes, loader.clone()).unwrap();
        let (name, _pc) = executable.get_function_registry().lookup_by_key(4).unwrap();
        assert_eq!(name, b"entrypoint");
    }

    // Check that using a reserved SBPF version fails
    {
        let mut elf_bytes = elf_bytes.clone();
        elf_bytes[0x0030] = 0xFF;
        let err = ElfExecutable::load(&elf_bytes, loader.clone()).unwrap_err();
        assert_eq!(err, ElfError::UnsupportedSBPFVersion);
    }

    // Check that an empty file fails
    let err = ElfExecutable::load_with_strict_parser(&[], loader.clone()).unwrap_err();
    assert_eq!(err, ElfParserError::OutOfBounds);

    // Break the file header one byte at a time
    let expected_results = std::iter::repeat_n(&Err(ElfParserError::InvalidFileHeader), 16)
        .chain(std::iter::repeat_n(&Ok(()), 2))
        .chain(std::iter::repeat_n(
            &Err(ElfParserError::InvalidFileHeader),
            22,
        ))
        .chain(std::iter::repeat_n(&Ok(()), 12))
        .chain(std::iter::repeat_n(
            &Err(ElfParserError::InvalidFileHeader),
            6,
        ))
        .chain(std::iter::repeat_n(&Ok(()), 6));
    for (offset, expected) in (0..std::mem::size_of::<Elf64Ehdr>()).zip(expected_results) {
        let mut elf_bytes = elf_bytes.clone();
        elf_bytes[offset] = 0xAF;
        let result = ElfExecutable::load_with_strict_parser(&elf_bytes, loader.clone()).map(|_| ());
        assert_eq!(&result, expected);
    }

    // Break the program header table one byte at a time
    let expected_results_readonly =
        std::iter::repeat_n(&Err(ElfParserError::InvalidProgramHeader), 48)
            .chain(std::iter::repeat_n(&Ok(()), 8))
            .collect::<Vec<_>>();
    let expected_results = vec![
        expected_results_readonly.iter(),
        expected_results_readonly.iter(),
    ];
    for (header_index, expected_results) in expected_results.into_iter().enumerate() {
        for (offset, expected) in (std::mem::size_of::<Elf64Ehdr>()
            + std::mem::size_of::<Elf64Phdr>() * header_index
            ..std::mem::size_of::<Elf64Ehdr>()
                + std::mem::size_of::<Elf64Phdr>() * (header_index + 1))
            .zip(expected_results)
        {
            let mut elf_bytes = elf_bytes.clone();
            elf_bytes[offset] = 0xAF;
            let result =
                ElfExecutable::load_with_strict_parser(&elf_bytes, loader.clone()).map(|_| ());
            assert_eq!(&&result, expected);
        }
    }

    // Check that skipping the rodata without the PF_X flag indication fails
    {
        let program_header = &elf_bytes[std::mem::size_of::<Elf64Ehdr>()
            + std::mem::size_of::<Elf64Phdr>()
            ..std::mem::size_of::<Elf64Ehdr>() + std::mem::size_of::<Elf64Phdr>() * 2];
        let mut elf_bytes = elf_bytes.clone();
        elf_bytes[std::mem::offset_of!(Elf64Ehdr, e_phnum)] = 1;
        elf_bytes[std::mem::size_of::<Elf64Ehdr>() + std::mem::offset_of!(Elf64Phdr, p_offset)] =
            0x40;
        let err = ElfExecutable::load_with_strict_parser(&elf_bytes, loader.clone()).unwrap_err();
        assert_eq!(err, ElfParserError::InvalidFileHeader);
        // Check that skipping the rodata with the PF_X flag indication succeeds
        elf_bytes[std::mem::size_of::<Elf64Ehdr>()
            ..std::mem::size_of::<Elf64Ehdr>() + std::mem::size_of::<Elf64Phdr>()]
            .copy_from_slice(program_header);
        elf_bytes[std::mem::size_of::<Elf64Ehdr>() + std::mem::offset_of!(Elf64Phdr, p_offset)] =
            0x78;
        ElfExecutable::load_with_strict_parser(&elf_bytes, loader.clone()).unwrap();
    }

    // Check that an unaligned program header length fails
    {
        let mut elf_bytes = elf_bytes.clone();
        elf_bytes[0x98] = 0x29;
        elf_bytes[0xA0] = 0x29;
        let err = ElfExecutable::load_with_strict_parser(&elf_bytes, loader.clone()).unwrap_err();
        assert_eq!(err, ElfParserError::InvalidProgramHeader);
    }
}

#[test]
fn test_validate() {
    let elf_bytes = std::fs::read("tests/elfs/relative_call_sbpfv0.so").unwrap();
    let elf = Elf64::parse(&elf_bytes).unwrap();
    let mut header = elf.file_header().clone();

    let write_header = |header: Elf64Ehdr| unsafe {
        let mut bytes = elf_bytes.clone();
        std::ptr::write(bytes.as_mut_ptr().cast::<Elf64Ehdr>(), header);
        bytes
    };

    ElfExecutable::validate(&elf, &elf_bytes).expect("validation failed");

    header.e_ident.ei_class = ELFCLASS32;
    let bytes = write_header(header.clone());
    // the new parser rejects anything other than ELFCLASS64 directly
    Elf64::parse(&bytes).expect_err("allowed bad class");

    header.e_ident.ei_class = ELFCLASS64;
    let bytes = write_header(header.clone());
    ElfExecutable::validate(&Elf64::parse(&bytes).unwrap(), &elf_bytes).expect("validation failed");

    header.e_ident.ei_data = ELFDATA2MSB;
    let bytes = write_header(header.clone());
    // the new parser only supports little endian
    Elf64::parse(&bytes).expect_err("allowed big endian");

    header.e_ident.ei_data = ELFDATA2LSB;
    let bytes = write_header(header.clone());
    ElfExecutable::validate(&Elf64::parse(&bytes).unwrap(), &elf_bytes).expect("validation failed");

    header.e_ident.ei_osabi = 1;
    let bytes = write_header(header.clone());
    ElfExecutable::validate(&Elf64::parse(&bytes).unwrap(), &elf_bytes)
        .expect_err("allowed wrong abi");

    header.e_ident.ei_osabi = ELFOSABI_NONE;
    let bytes = write_header(header.clone());
    ElfExecutable::validate(&Elf64::parse(&bytes).unwrap(), &elf_bytes).expect("validation failed");

    header.e_machine = 42;
    let bytes = write_header(header.clone());
    ElfExecutable::validate(&Elf64::parse(&bytes).unwrap(), &elf_bytes)
        .expect_err("allowed wrong machine");

    header.e_machine = EM_BPF;
    let bytes = write_header(header.clone());
    ElfExecutable::validate(&Elf64::parse(&bytes).unwrap(), &elf_bytes).expect("validation failed");

    header.e_type = ET_REL;
    let bytes = write_header(header);
    ElfExecutable::validate(&Elf64::parse(&bytes).unwrap(), &elf_bytes)
        .expect_err("allowed wrong type");
}

#[test]
fn test_load() {
    let mut file = File::open("tests/elfs/relative_call_sbpfv0.so").expect("file open failed");
    let mut elf_bytes = Vec::new();
    file.read_to_end(&mut elf_bytes)
        .expect("failed to read elf file");
    ElfExecutable::load(&elf_bytes, loader()).expect("validation failed");
}

#[test]
fn test_load_unaligned() {
    let mut elf_bytes =
        std::fs::read("tests/elfs/relative_call_sbpfv0.so").expect("failed to read elf file");
    // The default allocator allocates aligned memory. Move the ELF slice to
    // elf_bytes.as_ptr() + 1 to make it unaligned and test unaligned
    // parsing.
    elf_bytes.insert(0, 0);
    ElfExecutable::load(&elf_bytes[1..], loader()).expect("validation failed");
}

#[test]
fn test_entrypoint() {
    let loader = loader();

    let mut file = File::open("tests/elfs/relative_call_sbpfv0.so").expect("file open failed");
    let mut elf_bytes = Vec::new();
    file.read_to_end(&mut elf_bytes)
        .expect("failed to read elf file");
    let elf = ElfExecutable::load(&elf_bytes, loader.clone()).expect("validation failed");
    let parsed_elf = Elf64::parse(&elf_bytes).unwrap();
    let executable: &Executable<TestContextObject> = &elf;
    assert_eq!(4, executable.get_entrypoint_instruction_offset());

    let write_header = |header: Elf64Ehdr| unsafe {
        let mut bytes = elf_bytes.clone();
        std::ptr::write(bytes.as_mut_ptr().cast::<Elf64Ehdr>(), header);
        bytes
    };

    let mut header = parsed_elf.file_header().clone();
    let initial_e_entry = header.e_entry;

    header.e_entry += 8;
    let elf_bytes = write_header(header.clone());
    let elf = ElfExecutable::load(&elf_bytes, loader.clone()).expect("validation failed");
    let executable: &Executable<TestContextObject> = &elf;
    assert_eq!(5, executable.get_entrypoint_instruction_offset());

    header.e_entry = 1;
    let elf_bytes = write_header(header.clone());
    assert!(matches!(
        ElfExecutable::load(&elf_bytes, loader.clone()),
        Err(ElfError::EntrypointOutOfBounds)
    ));

    header.e_entry = u64::MAX;
    let elf_bytes = write_header(header.clone());
    assert!(matches!(
        ElfExecutable::load(&elf_bytes, loader.clone()),
        Err(ElfError::EntrypointOutOfBounds)
    ));

    header.e_entry = initial_e_entry + ebpf::INSN_SIZE as u64 + 1;
    let elf_bytes = write_header(header.clone());
    assert!(matches!(
        ElfExecutable::load(&elf_bytes, loader.clone()),
        Err(ElfError::InvalidEntrypoint)
    ));

    header.e_entry = initial_e_entry;
    let elf_bytes = write_header(header);
    let elf = ElfExecutable::load(&elf_bytes, loader).expect("validation failed");
    let executable: &Executable<TestContextObject> = &elf;
    assert_eq!(4, executable.get_entrypoint_instruction_offset());
}

#[test]
fn test_text_section_at_region_boundary() {
    let mut elf_bytes =
        std::fs::read("tests/elfs/relative_call_sbpfv0.so").expect("failed to read elf file");

    let (shdr_offset, mut shdr, e_entry) = {
        let elf = Elf64::parse(&elf_bytes).unwrap();
        let header = elf.file_header();
        let (index, section) = elf
            .section_header_table()
            .iter()
            .enumerate()
            .find(|(_, section)| elf.section_name(section.sh_name).ok() == Some(&b".text"[..]))
            .unwrap();
        (
            header.e_shoff as usize + index * header.e_shentsize as usize,
            section.clone(),
            header.e_entry,
        )
    };

    let new_e_entry = ebpf::MM_REGION_SIZE + (e_entry - shdr.sh_addr);
    shdr.sh_addr = ebpf::MM_REGION_SIZE;
    unsafe {
        std::ptr::write_unaligned(
            elf_bytes.as_mut_ptr().add(shdr_offset).cast::<Elf64Shdr>(),
            shdr,
        );
        let mut header = Elf64::parse(&elf_bytes).unwrap().file_header().clone();
        header.e_entry = new_e_entry;
        std::ptr::write(elf_bytes.as_mut_ptr().cast::<Elf64Ehdr>(), header);
    }

    assert!(matches!(
        ElfExecutable::load(&elf_bytes, loader()),
        Err(ElfError::ValueOutOfBounds)
    ));
}

fn new_section(sh_addr: u64, sh_size: u64) -> Elf64Shdr {
    Elf64Shdr {
        sh_addr,
        sh_offset: sh_addr.checked_sub(ebpf::MM_REGION_SIZE).unwrap_or(sh_addr),
        sh_size,
        sh_name: 0,
        sh_type: 0,
        sh_flags: 0,
        sh_link: 0,
        sh_info: 0,
        sh_addralign: 0,
        sh_entsize: 0,
    }
}

#[test]
fn test_owned_ro_sections_not_contiguous() {
    let config = Config::default();
    let elf_bytes = [0u8; 512];

    // there's a non-rodata section between two rodata sections
    let s1 = new_section(10, 10);
    let s2 = new_section(20, 10);
    let s3 = new_section(30, 10);

    let sections: [(Option<&[u8]>, &Elf64Shdr); 3] = [
        (Some(b".text"), &s1),
        (Some(b".dynamic"), &s2),
        (Some(b".rodata"), &s3),
    ];
    assert!(matches!(
        ElfExecutable::parse_ro_sections(
            &config,
            sections,
            &elf_bytes,
        ),
        Ok(Section::Owned(offset, data)) if offset == ebpf::MM_REGION_SIZE as usize + 10 && data.len() == 30
    ));
}

#[test]
fn test_owned_ro_sections_with_sh_offset() {
    let config = Config {
        reject_broken_elfs: false,
        ..Config::default()
    };
    let elf_bytes = [0u8; 512];

    // s2 is at a custom sh_offset. We need to merge into an owned buffer so
    // s2 can be moved to the right address offset.
    let s1 = new_section(10, 10);
    let mut s2 = new_section(20, 10);
    s2.sh_offset = 30;

    let sections: [(Option<&[u8]>, &Elf64Shdr); 2] =
        [(Some(b".text"), &s1), (Some(b".rodata"), &s2)];
    assert!(matches!(
        ElfExecutable::parse_ro_sections(
            &config,
            sections,
            &elf_bytes,
        ),
        Ok(Section::Owned(offset, data)) if offset == ebpf::MM_REGION_SIZE as usize + 10 && data.len() == 20
    ));
}

#[test]
fn test_sh_offset_not_same_as_vaddr() {
    let config = Config {
        reject_broken_elfs: true,
        enabled_sbpf_versions: SBPFVersion::V0..=SBPFVersion::V0,
        ..Config::default()
    };
    let elf_bytes = [0u8; 512];

    let mut s1 = new_section(10, 10);

    {
        let sections: [(Option<&[u8]>, &Elf64Shdr); 1] = [(Some(b".text"), &s1)];
        assert!(ElfExecutable::parse_ro_sections(&config, sections, &elf_bytes).is_ok());
    }

    s1.sh_offset = 0;
    let sections: [(Option<&[u8]>, &Elf64Shdr); 1] = [(Some(b".text"), &s1)];
    assert_eq!(
        ElfExecutable::parse_ro_sections(&config, sections, &elf_bytes),
        Err(ElfError::ValueOutOfBounds)
    );
}

#[test]
fn test_owned_ro_region_no_initial_gap() {
    let config = Config::default();
    let elf_bytes = [0u8; 512];

    // need an owned buffer so we can zero the address space taken by s2
    let s1 = new_section(0, 10);
    let s2 = new_section(10, 10);
    let s3 = new_section(20, 10);

    let sections: [(Option<&[u8]>, &Elf64Shdr); 3] = [
        (Some(b".text"), &s1),
        (Some(b".dynamic"), &s2),
        (Some(b".rodata"), &s3),
    ];
    let ro_section = ElfExecutable::parse_ro_sections(&config, sections, &elf_bytes).unwrap();
    let ro_region = get_ro_region(&ro_section, &elf_bytes);
    let memory_mapping =
        unsafe { MemoryMapping::new(vec![ro_region], &config, SBPFVersion::V0) }.unwrap();
    let owned_section = match &ro_section {
        Section::Owned(_offset, data) => data.as_slice(),
        _ => panic!(),
    };

    // [0..s3.sh_addr + s3.sh_size] is the valid ro memory area
    assert_eq!(
        memory_mapping
            .map(
                AccessType::Load,
                ebpf::MM_REGION_SIZE,
                s3.sh_addr + s3.sh_size
            )
            .unwrap()
            .ptr()
            .addr(),
        owned_section.as_ptr().addr(),
    );

    // one byte past the ro section is not mappable
    memory_mapping
        .map(
            AccessType::Load,
            ebpf::MM_REGION_SIZE + s3.sh_addr + s3.sh_size,
            1,
        )
        .unwrap_err();
}

#[test]
fn test_owned_ro_region_initial_gap_mappable() {
    let config = Config {
        optimize_rodata: false,
        ..Config::default()
    };
    let elf_bytes = [0u8; 512];

    // the first section starts at a non-zero offset
    let s1 = new_section(10, 10);
    let s2 = new_section(20, 10);
    let s3 = new_section(30, 10);

    let sections: [(Option<&[u8]>, &Elf64Shdr); 3] = [
        (Some(b".text"), &s1),
        (Some(b".dynamic"), &s2),
        (Some(b".rodata"), &s3),
    ];
    // V2 requires optimize_rodata=true
    let ro_section = ElfExecutable::parse_ro_sections(&config, sections, &elf_bytes).unwrap();
    let ro_region = get_ro_region(&ro_section, &elf_bytes);
    let memory_mapping =
        unsafe { MemoryMapping::new(vec![ro_region], &config, SBPFVersion::V0).unwrap() };
    let owned_section = match &ro_section {
        Section::Owned(_offset, data) => data.as_slice(),
        _ => panic!(),
    };

    // [s1.sh_addr..s3.sh_addr + s3.sh_size] is where the readonly data is.
    // But for backwards compatibility (config.optimize_rodata=false)
    // [0..s1.sh_addr] is mappable too (and zeroed).
    assert_eq!(
        memory_mapping
            .map(
                AccessType::Load,
                ebpf::MM_REGION_SIZE,
                s3.sh_addr + s3.sh_size
            )
            .unwrap()
            .ptr()
            .addr(),
        owned_section.as_ptr().addr(),
    );

    // one byte past the ro section is not mappable
    memory_mapping
        .map(
            AccessType::Load,
            ebpf::MM_REGION_SIZE + s3.sh_addr + s3.sh_size,
            1,
        )
        .unwrap_err();
}

#[test]
fn test_owned_ro_region_initial_gap_map_error() {
    let config = Config::default();
    let elf_bytes = [0u8; 512];

    // the first section starts at a non-zero offset
    let s1 = new_section(10, 10);
    let s2 = new_section(20, 10);
    let s3 = new_section(30, 10);

    let sections: [(Option<&[u8]>, &Elf64Shdr); 3] = [
        (Some(b".text"), &s1),
        (Some(b".dynamic"), &s2),
        (Some(b".rodata"), &s3),
    ];
    let ro_section = ElfExecutable::parse_ro_sections(&config, sections, &elf_bytes).unwrap();
    let owned_section = match &ro_section {
        Section::Owned(_offset, data) => data.as_slice(),
        _ => panic!(),
    };
    let ro_region = get_ro_region(&ro_section, &elf_bytes);
    let memory_mapping =
        unsafe { MemoryMapping::new(vec![ro_region], &config, SBPFVersion::V0).unwrap() };

    // s1 starts at sh_addr=10 so [MM_REGION_SIZE..MM_REGION_SIZE + 10] is not mappable

    // the low bound of the initial gap is not mappable
    memory_mapping
        .map(AccessType::Load, ebpf::MM_REGION_SIZE, 1)
        .unwrap_err();

    // the hi bound of the initial gap is not mappable
    memory_mapping
        .map(AccessType::Load, ebpf::MM_REGION_SIZE + s1.sh_addr - 1, 1)
        .unwrap_err();

    // [s1.sh_addr..s3.sh_addr + s3.sh_size] is the valid ro memory area
    assert_eq!(
        memory_mapping
            .map(
                AccessType::Load,
                ebpf::MM_REGION_SIZE + s1.sh_addr,
                s3.sh_addr + s3.sh_size - s1.sh_addr
            )
            .unwrap()
            .ptr()
            .addr(),
        owned_section.as_ptr().addr(),
    );

    // one byte past the ro section is not mappable
    memory_mapping
        .map(
            AccessType::Load,
            ebpf::MM_REGION_SIZE + s3.sh_addr + s3.sh_size,
            1,
        )
        .unwrap_err();
}

#[test]
fn test_borrowed_ro_sections_disabled() {
    let config = Config {
        optimize_rodata: false,
        ..Config::default()
    };
    let elf_bytes = [0u8; 512];

    // s1 and s2 are contiguous, the rodata section can be borrowed from the
    // original elf input but config.borrow_rodata=false
    let s1 = new_section(0, 10);
    let s2 = new_section(10, 10);

    let sections: [(Option<&[u8]>, &Elf64Shdr); 2] =
        [(Some(b".text"), &s1), (Some(b".rodata"), &s2)];
    assert!(matches!(
        ElfExecutable::parse_ro_sections(
            &config,
            sections,
            &elf_bytes,
        ),
        Ok(Section::Owned(offset, data)) if offset == ebpf::MM_REGION_SIZE as usize && data.len() == 20
    ));
}

#[test]
fn test_borrowed_ro_sections() {
    let config = Config::default();
    let elf_bytes = [0u8; 512];
    let s1 = new_section(0, 10);
    let s2 = new_section(20, 10);
    let s3 = new_section(40, 10);
    let s4 = new_section(50, 10);
    let sections: [(Option<&[u8]>, &Elf64Shdr); 4] = [
        (Some(b".dynsym"), &s1),
        (Some(b".text"), &s2),
        (Some(b".rodata"), &s3),
        (Some(b".dynamic"), &s4),
    ];
    assert_eq!(
        ElfExecutable::parse_ro_sections(&config, sections, &elf_bytes),
        Ok(Section::Borrowed(
            ebpf::MM_REGION_SIZE as usize + 20,
            20..50
        ))
    );
}

#[test]
fn test_borrowed_ro_region_no_initial_gap() {
    let config = Config::default();
    let elf_bytes = [0u8; 512];
    let s1 = new_section(0, 10);
    let s2 = new_section(10, 10);
    let s3 = new_section(20, 10);
    let sections: [(Option<&[u8]>, &Elf64Shdr); 3] = [
        (Some(b".text"), &s1),
        (Some(b".rodata"), &s2),
        (Some(b".dynamic"), &s3),
    ];
    let ro_section = ElfExecutable::parse_ro_sections(&config, sections, &elf_bytes).unwrap();
    let ro_region = get_ro_region(&ro_section, &elf_bytes);
    let memory_mapping =
        unsafe { MemoryMapping::new(vec![ro_region], &config, SBPFVersion::V0).unwrap() };

    // s1 starts at sh_offset=0 so [0..s2.sh_offset + s2.sh_size]
    // is the valid ro memory area
    assert_eq!(
        memory_mapping
            .map(
                AccessType::Load,
                ebpf::MM_REGION_SIZE + s1.sh_offset,
                s2.sh_offset + s2.sh_size
            )
            .unwrap()
            .ptr()
            .addr(),
        elf_bytes.as_ptr().addr(),
    );

    // one byte past the ro section is not mappable
    memory_mapping
        .map(AccessType::Load, ebpf::MM_REGION_SIZE + s3.sh_offset, 1)
        .unwrap_err();
}

#[test]
fn test_borrowed_ro_region_initial_gap() {
    let config = Config::default();
    let elf_bytes = [0u8; 512];
    let s1 = new_section(0, 10);
    let s2 = new_section(10, 10);
    let s3 = new_section(20, 10);
    let sections: [(Option<&[u8]>, &Elf64Shdr); 3] = [
        (Some(b".dynamic"), &s1),
        (Some(b".text"), &s2),
        (Some(b".rodata"), &s3),
    ];
    let ro_section = ElfExecutable::parse_ro_sections(&config, sections, &elf_bytes).unwrap();
    let ro_region = get_ro_region(&ro_section, &elf_bytes);
    let memory_mapping =
        unsafe { MemoryMapping::new(vec![ro_region], &config, SBPFVersion::V0).unwrap() };

    // s2 starts at sh_addr=10 so [0..10] is not mappable

    // the low bound of the initial gap is not mappable
    memory_mapping
        .map(AccessType::Load, ebpf::MM_REGION_SIZE + s1.sh_offset, 1)
        .unwrap_err();

    // the hi bound of the initial gap is not mappable
    memory_mapping
        .map(AccessType::Load, ebpf::MM_REGION_SIZE + s2.sh_offset - 1, 1)
        .unwrap_err();

    // [s2.sh_offset..s3.sh_offset + s3.sh_size] is the valid ro memory area
    assert_eq!(
        memory_mapping
            .map(
                AccessType::Load,
                ebpf::MM_REGION_SIZE + s2.sh_offset,
                s3.sh_offset + s3.sh_size - s2.sh_offset
            )
            .unwrap()
            .ptr()
            .addr(),
        elf_bytes[s2.sh_offset as usize..].as_ptr().addr(),
    );

    // one byte past the ro section is not mappable
    memory_mapping
        .map(
            AccessType::Load,
            ebpf::MM_REGION_SIZE + s3.sh_offset + s3.sh_size,
            1,
        )
        .unwrap_err();
}

#[test]
#[should_panic(expected = r#"validation failed: WritableSectionNotSupported(".data")"#)]
fn test_writable_data_section() {
    let elf_bytes =
        std::fs::read("tests/elfs/data_section_sbpfv0.so").expect("failed to read elf file");
    ElfExecutable::load(&elf_bytes, loader()).expect("validation failed");
}

#[test]
#[should_panic(expected = r#"validation failed: WritableSectionNotSupported(".bss")"#)]
fn test_bss_section() {
    let elf_bytes =
        std::fs::read("tests/elfs/bss_section_sbpfv0.so").expect("failed to read elf file");
    ElfExecutable::load(&elf_bytes, loader()).expect("validation failed");
}

#[test]
#[should_panic(expected = "validation failed: InvalidProgramHeader")]
fn test_program_headers_overflow() {
    let elf_bytes =
        std::fs::read("tests/elfs/program_headers_overflow.so").expect("failed to read elf file");
    ElfExecutable::load(&elf_bytes, loader()).expect("validation failed");
}

#[test]
#[should_panic(expected = "validation failed: RelativeJumpOutOfBounds(8)")]
fn test_relative_call_oob_backward() {
    let mut elf_bytes =
        std::fs::read("tests/elfs/relative_call_sbpfv0.so").expect("failed to read elf file");
    LittleEndian::write_i32(&mut elf_bytes[0x164..0x168], -11i32);
    ElfExecutable::load(&elf_bytes, loader()).expect("validation failed");
}

#[test]
#[should_panic(expected = "validation failed: RelativeJumpOutOfBounds(11)")]
fn test_relative_call_oob_forward() {
    let mut elf_bytes =
        std::fs::read("tests/elfs/relative_call_sbpfv0.so").expect("failed to read elf file");
    LittleEndian::write_i32(&mut elf_bytes[0x17c..0x180], 5);
    ElfExecutable::load(&elf_bytes, loader()).expect("validation failed");
}

#[test]
#[should_panic(expected = "validation failed: UnresolvedSymbol(\"log\", 39, 312)")]
fn test_err_unresolved_syscall_reloc_64_32() {
    let loader = BuiltinProgram::new_loader(Config {
        enabled_sbpf_versions: SBPFVersion::V0..=SBPFVersion::V0,
        reject_broken_elfs: true,
        ..Config::default()
    });
    let elf_bytes =
        std::fs::read("tests/elfs/syscall_reloc_64_32_sbpfv0.so").expect("failed to read elf file");
    ElfExecutable::load(&elf_bytes, Arc::new(loader)).expect("validation failed");
}

#[test]
fn test_long_section_name() {
    let elf_bytes = std::fs::read("tests/elfs/long_section_name.so").unwrap();
    assert_error!(
        Elf64::parse(&elf_bytes),
        "StringTooLong({:?}, {})",
        ".bss.__rust_no_alloc_shim_is_unstable"
            .get(0..SECTION_NAME_LENGTH_MAXIMUM)
            .unwrap(),
        SECTION_NAME_LENGTH_MAXIMUM
    );
}

fn loader_with_labels() -> Arc<BuiltinProgram<TestContextObject>> {
    let mut loader = BuiltinProgram::new_loader(Config {
        enable_symbol_and_section_labels: true,
        ..Config::default()
    });
    syscalls::SyscallString::register(&mut loader, "log").unwrap();
    syscalls::SyscallU64::register(&mut loader, "log_64").unwrap();
    Arc::new(loader)
}

/// Asserts that the label over `SYMBOL_NAME_LENGTH_MAXIMUM` is kept and the one
/// over `DEBUG_SYMBOL_NAME_LENGTH_MAXIMUM` is skipped.
fn assert_label_lengths(executable: &ElfExecutable) {
    let lengths: Vec<usize> = executable
        .get_function_registry()
        .iter()
        .map(|(_key, (name, _pc))| name.len())
        .collect();
    assert!(lengths.iter().any(|length| *length > 64));
    assert!(lengths
        .iter()
        .all(|length| *length <= DEBUG_SYMBOL_NAME_LENGTH_MAXIMUM));
}

#[test]
fn test_long_symbol_name_lenient() {
    let elf_bytes = std::fs::read("tests/elfs/long_symbol_name_sbpfv0.so").unwrap();
    let executable = ElfExecutable::load(&elf_bytes, loader_with_labels()).unwrap();
    assert!(executable
        .get_function_registry()
        .lookup_by_name(b"entrypoint")
        .is_some());
    assert_label_lengths(&executable);
}

#[test]
fn test_long_symbol_name_strict() {
    let elf_bytes = std::fs::read("tests/elfs/long_symbol_name.so").unwrap();
    let executable = ElfExecutable::load(&elf_bytes, loader_with_labels()).unwrap();
    assert!(executable
        .get_function_registry()
        .lookup_by_name(b"entrypoint")
        .is_some());
    assert_label_lengths(&executable);
}

#[test]
fn test_stripped_elf_labels() {
    // elfs.sh strips this one, which leaves an empty .strtab without a .symtab.
    let elf_bytes = std::fs::read("tests/elfs/relative_call.so").unwrap();
    ElfExecutable::load(&elf_bytes, loader_with_labels()).unwrap();
}

#[test]
fn test_long_dynamic_symbol_name() {
    // Relocation resolves symbols by name, so its limit is consensus relevant
    // and stays where it is.
    let elf_bytes = std::fs::read("tests/elfs/long_dynamic_symbol_name_sbpfv0.so").unwrap();
    assert_error!(ElfExecutable::load(&elf_bytes, loader()), "UnknownSymbol");
    assert_error!(
        ElfExecutable::load(&elf_bytes, loader_with_labels()),
        "UnknownSymbol"
    );
}

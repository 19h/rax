#![allow(clippy::literal_string_with_formatting_args)]

// Copyright 2017 Jan-Erik Rediger <badboy@archlinux.us>
//
// Adopted from tests in `tests/assembler.rs`
//
// Licensed under the Apache License, Version 2.0 <http://www.apache.org/licenses/LICENSE-2.0> or
// the MIT license <http://opensource.org/licenses/MIT>, at your option. This file may not be
// copied, modified, or distributed except according to those terms.

extern crate solana_sbpf;
use solana_sbpf::disassembler::disassemble_instruction;
use solana_sbpf::ebpf::{self, Insn};
use solana_sbpf::program::{FunctionRegistry, SBPFVersion};
use solana_sbpf::{
    assembler::assemble, program::BuiltinProgram, static_analysis::Analysis, vm::Config,
};
use std::collections::BTreeMap;
use std::sync::Arc;
use test_utils::TestContextObject;

// Using a macro to keep actual line numbers in failure output
macro_rules! disasm {
    ($src:expr) => {{
        let config = Config {
            enable_symbol_and_section_labels: true,
            ..Config::default()
        };
        disasm!($src, config);
    }};
    ($src:expr, $config:expr) => {{
        let src = $src;
        let loader = BuiltinProgram::new_loader($config);
        let executable = assemble::<TestContextObject>(src, Arc::new(loader)).unwrap();
        let analysis = Analysis::from_executable(&executable).unwrap();
        let mut reasm = Vec::new();
        analysis.disassemble(&mut reasm).unwrap();
        assert_eq!(src, String::from_utf8(reasm).unwrap());
    }};
}

fn disassemble_insn(insn: &Insn, sbpf_version: SBPFVersion) -> String {
    disassemble_instruction(
        insn,
        0,
        &BTreeMap::new(),
        &FunctionRegistry::default(),
        &BuiltinProgram::<TestContextObject>::new_mock(),
        sbpf_version,
    )
}

#[test]
fn test_empty() {
    disasm!("");
}

// Example for InstructionType::NoOperand.
#[test]
fn test_exit() {
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V0..=SBPFVersion::V0,
        ..Config::default()
    };
    disasm!("entrypoint:\n    exit\n", config);
}

#[test]
fn test_static_syscall() {
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V3..=SBPFVersion::V3,
        ..Config::default()
    };
    disasm!("entrypoint:\n    syscall 5\n", config);
}

#[test]
fn test_internal_call() {
    for version in [
        SBPFVersion::V0,
        SBPFVersion::V1,
        SBPFVersion::V2,
        SBPFVersion::V3,
        SBPFVersion::V4,
    ] {
        let config = Config {
            enabled_sbpf_versions: version..=version,
            enable_symbol_and_section_labels: true,
            ..Config::default()
        };
        disasm!(
            "entrypoint:\n    call function_1\n\nfunction_1:\n    exit\n",
            config
        );
    }
}

#[test]
fn test_internal_call_after_lddw() {
    // V2 has no lddw
    for version in [
        SBPFVersion::V0,
        SBPFVersion::V1,
        SBPFVersion::V3,
        SBPFVersion::V4,
    ] {
        let config = Config {
            enabled_sbpf_versions: version..=version,
            enable_symbol_and_section_labels: true,
            ..Config::default()
        };
        disasm!(
            "entrypoint:
    lddw r1, 0x1
    call function_5
    exit

function_4:
    exit

function_5:
    exit
",
            config
        );
    }
}

// Example for InstructionType::AluBinary.
#[test]
fn test_add64() {
    disasm!("entrypoint:\n    add64 r1, r3\n");
    disasm!("entrypoint:\n    add64 r1, 5\n");
}

// Example for InstructionType::LoadReg.
#[test]
fn test_ldxw() {
    disasm!("entrypoint:\n    ldxw r1, [r2+0x5]\n");
    disasm!("entrypoint:\n    ldxw r1, [r2-0x5]\n");
}

// Example for InstructionType::StoreImm.
#[test]
fn test_stw() {
    disasm!("entrypoint:\n    stw [r2+0x5], 7\n");
    disasm!("entrypoint:\n    stw [r2-0x5], 7\n");
}

// Example for InstructionType::StoreReg.
#[test]
fn test_stxw() {
    disasm!("entrypoint:\n    stxw [r2+0x5], r8\n");
    disasm!("entrypoint:\n    stxw [r2-0x5], r8\n");
}

// Example for InstructionType::JumpUnconditional.
#[test]
fn test_ja() {
    disasm!(
        "entrypoint:
    ja lbb_1
lbb_1:
    exit
"
    );
}

// Example for InstructionType::Call.
#[test]
fn test_call() {
    disasm!(
        "entrypoint:
    call function_1

function_1:
    exit
"
    );
}

// Example for InstructionType::Endian.
#[test]
fn test_be32() {
    disasm!("entrypoint:\n    be32 r1\n");
}

// Example for InstructionType::LoadImm.
#[test]
fn test_lddw() {
    disasm!("entrypoint:\n    lddw r1, 0x1234abcd5678eeff\n");
    disasm!("entrypoint:\n    lddw r1, 0xff11ee22dd33cc44\n");
}

// Example for InstructionType::LoadReg.
#[test]
fn test_ldxdw() {
    disasm!("entrypoint:\n    ldxdw r1, [r2+0x7999]\n");
    disasm!("entrypoint:\n    ldxdw r1, [r2-0x8000]\n");
}

// Example for InstructionType::StoreImm.
#[test]
fn test_sth() {
    disasm!("entrypoint:\n    sth [r1+0x7999], 3\n");
    disasm!("entrypoint:\n    sth [r1-0x8000], 3\n");
}

// Example for InstructionType::StoreReg.
#[test]
fn test_stxh() {
    disasm!("entrypoint:\n    stxh [r1+0x7999], r3\n");
    disasm!("entrypoint:\n    stxh [r1-0x8000], r3\n");
}

// Test all supported AluBinary mnemonics.
#[test]
fn test_alu_binary() {
    disasm!(
        "entrypoint:
    add64 r1, r2
    sub64 r1, r2
    or64 r1, r2
    and64 r1, r2
    lsh64 r1, r2
    rsh64 r1, r2
    xor64 r1, r2
    mov64 r1, r2
    arsh64 r1, r2
"
    );

    disasm!(
        "entrypoint:
    add64 r1, 2
    sub64 r1, 2
    or64 r1, 2
    and64 r1, 2
    lsh64 r1, 2
    rsh64 r1, 2
    xor64 r1, 2
    mov64 r1, 2
    arsh64 r1, 2
"
    );

    disasm!(
        "entrypoint:
    add32 r1, r2
    sub32 r1, r2
    or32 r1, r2
    and32 r1, r2
    lsh32 r1, r2
    rsh32 r1, r2
    xor32 r1, r2
    mov32 r1, r2
    arsh32 r1, r2
"
    );

    disasm!(
        "entrypoint:
    add32 r1, 2
    sub32 r1, 2
    or32 r1, 2
    and32 r1, 2
    lsh32 r1, 2
    rsh32 r1, 2
    xor32 r1, 2
    mov32 r1, 2
    arsh32 r1, 2
"
    );
}

// Test PQR AluBinary mnemonics.
#[test]
fn test_pqr() {
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V2..=SBPFVersion::V2,
        ..Config::default()
    };

    disasm!(
        "entrypoint:
    lmul64 r1, r2
    lmul32 r1, r2
    uhmul64 r1, r2
    shmul64 r1, r2
    udiv64 r1, r2
    udiv32 r1, r2
    urem64 r1, r2
    urem32 r1, r2
    sdiv64 r1, r2
    sdiv32 r1, r2
    srem64 r1, r2
    srem32 r1, r2
",
        config.clone()
    );

    disasm!(
        "entrypoint:
    lmul64 r1, 2
    lmul32 r1, 2
    uhmul64 r1, 2
    shmul64 r1, 2
    udiv64 r1, 2
    udiv32 r1, 2
    urem64 r1, 2
    urem32 r1, 2
    sdiv64 r1, 2
    sdiv32 r1, 2
    srem64 r1, 2
    srem32 r1, 2
",
        config
    );
}

// Test all supported LoadReg mnemonics.
#[test]
fn test_load_reg() {
    disasm!(
        r"entrypoint:
    ldxw r1, [r2+0x3]
    ldxh r1, [r2+0x3]
    ldxb r1, [r2+0x3]
    ldxdw r1, [r2+0x3]
"
    );
}

// Test all supported StoreImm mnemonics.
#[test]
fn test_store_imm() {
    disasm!(
        "entrypoint:
    stw [r1+0x2], 3
    sth [r1+0x2], 3
    stb [r1+0x2], 3
    stdw [r1+0x2], 3
"
    );
}

// Test all supported StoreReg mnemonics.
#[test]
fn test_store_reg() {
    disasm!(
        "entrypoint:
    stxw [r1+0x2], r3
    stxh [r1+0x2], r3
    stxb [r1+0x2], r3
    stxdw [r1+0x2], r3
"
    );
}

// Test all supported JumpConditional mnemonics.
#[test]
fn test_jump_conditional() {
    disasm!(
        "entrypoint:
    jeq r1, r2, lbb_11
    jgt r1, r2, lbb_11
    jge r1, r2, lbb_11
    jlt r1, r2, lbb_11
    jle r1, r2, lbb_11
    jset r1, r2, lbb_11
    jne r1, r2, lbb_11
    jsgt r1, r2, lbb_11
    jsge r1, r2, lbb_11
    jslt r1, r2, lbb_11
    jsle r1, r2, lbb_11
lbb_11:
    exit
"
    );

    disasm!(
        "entrypoint:
    jeq r1, 2, lbb_11
    jgt r1, 2, lbb_11
    jge r1, 2, lbb_11
    jlt r1, 2, lbb_11
    jle r1, 2, lbb_11
    jset r1, 2, lbb_11
    jne r1, 2, lbb_11
    jsgt r1, 2, lbb_11
    jsge r1, 2, lbb_11
    jslt r1, 2, lbb_11
    jsle r1, 2, lbb_11
lbb_11:
    exit
"
    );

    disasm!(
        "entrypoint:
    jeq32 r1, r2, lbb_11
    jgt32 r1, r2, lbb_11
    jge32 r1, r2, lbb_11
    jlt32 r1, r2, lbb_11
    jle32 r1, r2, lbb_11
    jset32 r1, r2, lbb_11
    jne32 r1, r2, lbb_11
    jsgt32 r1, r2, lbb_11
    jsge32 r1, r2, lbb_11
    jslt32 r1, r2, lbb_11
    jsle32 r1, r2, lbb_11
lbb_11:
    exit
"
    );

    disasm!(
        "entrypoint:
    jeq32 r1, 2, lbb_11
    jgt32 r1, 2, lbb_11
    jge32 r1, 2, lbb_11
    jlt32 r1, 2, lbb_11
    jle32 r1, 2, lbb_11
    jset32 r1, 2, lbb_11
    jne32 r1, 2, lbb_11
    jsgt32 r1, 2, lbb_11
    jsge32 r1, 2, lbb_11
    jslt32 r1, 2, lbb_11
    jsle32 r1, 2, lbb_11
lbb_11:
    exit
"
    );
}

// Test all supported Endian mnemonics.
#[test]
fn test_endian() {
    disasm!(
        "entrypoint:
    be16 r1
    be32 r1
    be64 r1
    le16 r1
    le32 r1
    le64 r1
"
    );
}

#[test]
fn test_large_immediate() {
    disasm!("entrypoint:\n    add64 r1, -1\n");
    disasm!("entrypoint:\n    add64 r1, -1\n");
}

#[test]
fn test_callx() {
    for version in [
        SBPFVersion::V0,
        SBPFVersion::V2,
        SBPFVersion::V3,
        SBPFVersion::V4,
    ] {
        let config = Config {
            enabled_sbpf_versions: version..=version,
            ..Config::default()
        };
        disasm!("entrypoint:\n    callx r8\n", config);
    }
}

#[test]
fn test_disable_lddw() {
    let insn = Insn {
        opc: ebpf::LD_DW_IMM,
        ptr: 0,
        dst: 1,
        src: 0,
        off: 0,
        imm: 0x2a,
    };
    const LDDW: &str = "lddw r1, 0x2a";
    const UNKNOWN: &str = "unknown opcode=0x18";
    for (version, expected) in [
        (SBPFVersion::V0, LDDW),
        (SBPFVersion::V1, LDDW),
        (SBPFVersion::V2, UNKNOWN),
        (SBPFVersion::V3, LDDW),
        (SBPFVersion::V4, LDDW),
    ] {
        assert_eq!(
            disassemble_insn(&insn, version),
            expected,
            "SBPF {version:?}"
        );
    }
}

#[test]
fn test_disable_le() {
    let insn = Insn {
        opc: ebpf::LE,
        ptr: 0,
        dst: 1,
        src: 0,
        off: 0,
        imm: 16,
    };
    const LE: &str = "le16 r1";
    const UNKNOWN: &str = "unknown opcode=0xd4";
    for (version, expected) in [
        (SBPFVersion::V0, LE),
        (SBPFVersion::V1, LE),
        (SBPFVersion::V2, UNKNOWN),
        (SBPFVersion::V3, LE),
        (SBPFVersion::V4, LE),
    ] {
        assert_eq!(
            disassemble_insn(&insn, version),
            expected,
            "SBPF {version:?}"
        );
    }
}

#[test]
fn test_hor64() {
    let insn = Insn {
        opc: ebpf::HOR64_IMM,
        ptr: 0,
        dst: 1,
        src: 0,
        off: 0,
        imm: 42,
    };
    const HOR: &str = "hor64 r1, 42";
    const UNKNOWN: &str = "unknown opcode=0xf7";
    for (version, expected) in [
        (SBPFVersion::V0, UNKNOWN),
        (SBPFVersion::V1, UNKNOWN),
        (SBPFVersion::V2, HOR),
        (SBPFVersion::V3, UNKNOWN),
        (SBPFVersion::V4, UNKNOWN),
    ] {
        assert_eq!(
            disassemble_insn(&insn, version),
            expected,
            "SBPF {version:?}"
        );
    }
}

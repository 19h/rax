#![allow(clippy::literal_string_with_formatting_args)]
#![allow(clippy::arithmetic_side_effects)]
#![cfg(all(feature = "jit", not(target_os = "windows"), target_arch = "x86_64"))]

// Copyright 2020 Solana Maintainers <maintainers@solana.com>
//
// Licensed under the Apache License, Version 2.0 <http://www.apache.org/licenses/LICENSE-2.0> or
// the MIT license <http://opensource.org/licenses/MIT>, at your option. This file may not be
// copied, modified, or distributed except according to those terms.

extern crate byteorder;
extern crate libc;
extern crate solana_sbpf;
extern crate test_utils;
extern crate thiserror;

use byteorder::{ByteOrder, LittleEndian};
#[cfg(all(not(windows), target_arch = "x86_64"))]
use rand::{rngs::SmallRng, RngCore, SeedableRng};
use solana_sbpf::{
    assembler::assemble,
    declare_builtin_function, ebpf,
    elf::Executable,
    error::{EbpfError, ProgramResult},
    memory_region::{AccessType, MemoryRegion},
    program::{BuiltinFunctionDefinition, BuiltinProgram, FunctionRegistry, SBPFVersion},
    static_analysis::Analysis,
    verifier::RequisiteVerifier,
    vm::{Config, ContextObject},
};
use std::{fs::File, io::Read, sync::Arc};
use test_utils::{
    assert_error, compare_register_trace, create_vm, syscalls, test_interpreter_and_jit,
    test_interpreter_and_jit_asm, test_interpreter_and_jit_elf, test_syscall_asm,
    TestContextObject, NO_INPUT, PROG_TCP_PORT_80, TCP_SACK_ASM, TCP_SACK_MATCH, TCP_SACK_NOMATCH,
};

// BPF_ALU32_LOAD : Arithmetic and Logic

#[test]
fn test_mov32_imm() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov32 r0, 1
        exit",
        NO_INPUT,
        TestContextObject::new(3),
        ProgramResult::Ok(1),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov32 r0, -1
        exit",
        NO_INPUT,
        TestContextObject::new(3),
        ProgramResult::Ok(0xffffffff),
    );
}

#[test]
fn test_mov32_reg() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov32 r1, 1
        mov32 r0, r1
        exit",
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Ok(0x1),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov32 r1, -1
        mov32 r0, r1
        exit",
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Ok(0xffffffff),
    );
}

#[test]
fn test_mov64_imm() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov64 r0, 1
        exit",
        NO_INPUT,
        TestContextObject::new(3),
        ProgramResult::Ok(1),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov64 r0, -1
        exit",
        NO_INPUT,
        TestContextObject::new(3),
        ProgramResult::Ok(0xffffffffffffffff),
    );
}

#[test]
fn test_mov64_reg() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov64 r1, 1
        mov64 r0, r1
        exit",
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Ok(0x1),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov64 r1, -1
        mov64 r0, r1
        exit",
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Ok(0xffffffffffffffff),
    );
}

#[test]
fn test_bounce() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r0, 1
        mov r6, r0
        mov r7, r6
        mov r8, r7
        mov r9, r8
        mov r0, r9
        exit",
        NO_INPUT,
        TestContextObject::new(8),
        ProgramResult::Ok(0x1),
    );
}

#[test]
fn test_add32_sub32() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov32 r0, 1
        add32 r0, 2
        mov32 r1, 5
        add32 r0, r1
        mov32 r1, 3
        sub32 r0, r1
        exit",
        NO_INPUT,
        TestContextObject::new(8),
        ProgramResult::Ok(5),
    );
}

#[test]
fn test_add64_sub64() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov32 r0, 1
        add64 r0, 2
        mov32 r1, 5
        add64 r0, r1
        mov32 r1, 3
        sub64 r0, r1
        exit",
        NO_INPUT,
        TestContextObject::new(8),
        ProgramResult::Ok(5),
    );
}

#[test]
fn test_lmul128() {
    let mut input = [0; 16];
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r0, r1
        mov r2, 30
        mov r3, 0
        mov r4, 20
        mov r5, 0
        mul64 r3, r4
        mul64 r5, r2
        add64 r5, r3
        mov64 r0, r2
        rsh64 r0, 0x20
        mov64 r3, r4
        rsh64 r3, 0x20
        mov64 r6, r3
        mul64 r6, r0
        add64 r5, r6
        lsh64 r4, 0x20
        rsh64 r4, 0x20
        mov64 r6, r4
        mul64 r6, r0
        lsh64 r2, 0x20
        rsh64 r2, 0x20
        mul64 r4, r2
        mov64 r0, r4
        rsh64 r0, 0x20
        add64 r0, r6
        mov64 r6, r0
        rsh64 r6, 0x20
        add64 r5, r6
        mul64 r3, r2
        lsh64 r0, 0x20
        rsh64 r0, 0x20
        add64 r0, r3
        mov64 r2, r0
        rsh64 r2, 0x20
        add64 r5, r2
        stxdw [r1+0x8], r5
        lsh64 r0, 0x20
        lsh64 r4, 0x20
        rsh64 r4, 0x20
        or64 r0, r4
        stxdw [r1+0x0], r0
        exit",
        &raw mut input,
        TestContextObject::new(43),
        ProgramResult::Ok(600),
    );
}

#[test]
fn test_alu32_logic() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov32 r0, 0
        mov32 r1, 1
        mov32 r2, 2
        mov32 r3, 3
        mov32 r4, 4
        mov32 r5, 5
        mov32 r6, 6
        mov32 r7, 7
        mov32 r8, 8
        or32 r0, r5
        or32 r0, 0xa0
        and32 r0, 0xa3
        mov32 r9, 0x91
        and32 r0, r9
        lsh32 r0, 22
        lsh32 r0, r8
        rsh32 r0, 19
        rsh32 r0, r7
        xor32 r0, 0x03
        xor32 r0, r2
        exit",
        NO_INPUT,
        TestContextObject::new(22),
        ProgramResult::Ok(0x11),
    );
}

#[test]
fn test_alu64_logic() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r0, 0
        mov r1, 1
        mov r2, 2
        mov r3, 3
        mov r4, 4
        mov r5, 5
        mov r6, 6
        mov r7, 7
        mov r8, 8
        or r0, r5
        or r0, 0xa0
        and r0, 0xa3
        mov r9, 0x91
        and r0, r9
        lsh r0, 32
        lsh r0, 22
        lsh r0, r8
        rsh r0, 32
        rsh r0, 19
        rsh r0, r7
        xor r0, 0x03
        xor r0, r2
        exit",
        NO_INPUT,
        TestContextObject::new(24),
        ProgramResult::Ok(0x11),
    );
}

#[test]
fn test_arsh32_high_shift() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r0, 8
        lddw r1, 0x100000001
        arsh32 r0, r1
        exit",
        NO_INPUT,
        TestContextObject::new(5),
        ProgramResult::Ok(0x4),
    );
}

#[test]
fn test_arsh32_imm() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov32 r0, 0xf8
        lsh32 r0, 28
        arsh32 r0, 16
        exit",
        NO_INPUT,
        TestContextObject::new(5),
        ProgramResult::Ok(0xffff8000),
    );
}

#[test]
fn test_arsh32_reg() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov32 r0, 0xf8
        mov32 r1, 16
        lsh32 r0, 28
        arsh32 r0, r1
        exit",
        NO_INPUT,
        TestContextObject::new(6),
        ProgramResult::Ok(0xffff8000),
    );
}

#[test]
fn test_arsh64() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov32 r0, 1
        lsh r0, 63
        arsh r0, 55
        mov32 r1, 5
        arsh r0, r1
        exit",
        NO_INPUT,
        TestContextObject::new(7),
        ProgramResult::Ok(0xfffffffffffffff8),
    );
}

#[test]
fn test_lsh64_reg() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r0, 0x1
        mov r7, 4
        lsh r0, r7
        exit",
        NO_INPUT,
        TestContextObject::new(5),
        ProgramResult::Ok(0x10),
    );
}

#[test]
fn test_rhs32_imm() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        xor r0, r0
        add r0, -1
        rsh32 r0, 8
        exit",
        NO_INPUT,
        TestContextObject::new(5),
        ProgramResult::Ok(0x00ffffff),
    );
}

#[test]
fn test_rsh64_reg() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r0, 0x10
        mov r7, 4
        rsh r0, r7
        exit",
        NO_INPUT,
        TestContextObject::new(5),
        ProgramResult::Ok(0x1),
    );
}

#[test]
fn test_le16() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        lddw r0, 0x2211
        le16 r0
        exit",
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Ok(0x2211),
    );
}

#[test]
fn test_le16_high() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        lddw r0, 0x8877665544332211
        le16 r0
        exit",
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Ok(0x2211),
    );
}

#[test]
fn test_le32() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        lddw r0, 0x44332211
        le32 r0
        exit",
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Ok(0x44332211),
    );
}

#[test]
fn test_le32_high() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        lddw r0, 0x8877665544332211
        le32 r0
        exit",
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Ok(0x44332211),
    );
}

#[test]
fn test_le64() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        lddw r0, 0x8877665544332211
        le64 r0
        exit",
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Ok(0x8877665544332211),
    );
}

#[test]
fn test_be16() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        lddw r0, 0x2211
        be16 r0
        exit",
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Ok(0x1122),
    );
}

#[test]
fn test_be16_high() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        lddw r0, 0x8877665544332211
        be16 r0
        exit",
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Ok(0x1122),
    );
}

#[test]
fn test_be32() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        lddw r0, 0x44332211
        be32 r0
        exit",
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Ok(0x11223344),
    );
}

#[test]
fn test_be32_high() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        lddw r0, 0x8877665544332211
        be32 r0
        exit",
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Ok(0x11223344),
    );
}

#[test]
fn test_be64() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        lddw r0, 0x8877665544332211
        be64 r0
        exit",
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Ok(0x1122334455667788),
    );
}

// BPF_PQR : Product / Quotient / Remainder

#[test]
fn test_pqr_v0() {
    let mut prog = [0; 48];
    prog[0] = ebpf::LD_DW_IMM;
    prog[16] = ebpf::LD_DW_IMM;
    prog[17] = 1; // dst = R1
    prog[33] = 16; // src = R1
    prog[40] = ebpf::EXIT;
    let loader = Arc::new(BuiltinProgram::new_loader(Config::default()));
    for (opc, dst, src, expected_result) in [
        (ebpf::DIV32_IMM, 13u64, 4u64, 3u64),
        (ebpf::DIV64_IMM, 13u64, 4u64, 3u64),
        (ebpf::MOD32_IMM, 13u64, 4u64, 1u64),
        (ebpf::MOD64_IMM, 13u64, 4u64, 1u64),
        (ebpf::DIV32_IMM, 13u64, u32::MAX as u64, 0u64),
        (ebpf::DIV64_IMM, 13u64, u32::MAX as u64, 0u64),
        (ebpf::MOD32_IMM, 13u64, u32::MAX as u64, 13u64),
        (ebpf::MOD64_IMM, 13u64, u32::MAX as u64, 13u64),
        (ebpf::DIV32_IMM, u64::MAX, 4u64, (u32::MAX / 4) as u64),
        (ebpf::DIV64_IMM, u64::MAX, 4u64, u64::MAX / 4),
        (ebpf::MOD32_IMM, u64::MAX, 4u64, 3u64),
        (ebpf::MOD64_IMM, u64::MAX, 4u64, 3u64),
        (ebpf::DIV32_IMM, u64::MAX, u32::MAX as u64, 1u64),
        /* Sign extension is messed up in V0: REG and IMM are different
        (
            ebpf::DIV64_IMM,
            u64::MAX,
            u32::MAX as u64,
            u32::MAX as u64 + 2,
        ),*/
        (ebpf::MOD32_IMM, u64::MAX, u32::MAX as u64, 0u64),
        (ebpf::MOD64_IMM, u64::MAX, u32::MAX as u64, 0u64),
        (
            ebpf::MUL32_IMM,
            13i64 as u64,
            4i32 as u32 as u64,
            52i32 as u32 as u64,
        ),
        (ebpf::MUL64_IMM, 13i64 as u64, 4i64 as u64, 52i64 as u64),
        (
            ebpf::MUL32_IMM,
            13i64 as u64,
            -4i32 as u32 as u64,
            -52i32 as i64 as u64,
            // Sign extension is messed up in V0 as the result should be: -52i32 as u32 as u64,
        ),
        (ebpf::MUL64_IMM, 13i64 as u64, -4i64 as u64, -52i64 as u64),
        (ebpf::MUL64_IMM, -13i64 as u64, 4i64 as u64, -52i64 as u64),
        (ebpf::MUL64_IMM, -13i64 as u64, -4i64 as u64, 52i64 as u64),
    ] {
        LittleEndian::write_u32(&mut prog[4..], dst as u32);
        LittleEndian::write_u32(&mut prog[12..], (dst >> 32) as u32);
        LittleEndian::write_u32(&mut prog[20..], src as u32);
        LittleEndian::write_u32(&mut prog[28..], (src >> 32) as u32);
        LittleEndian::write_u32(&mut prog[36..], src as u32);
        prog[32] = opc;
        #[allow(unused_mut)]
        let mut executable = Executable::<TestContextObject>::from_text_bytes(
            &prog,
            loader.clone(),
            SBPFVersion::V0,
            FunctionRegistry::default(),
        )
        .unwrap();
        test_interpreter_and_jit!(
            executable,
            NO_INPUT,
            TestContextObject::new(4),
            ProgramResult::Ok(expected_result),
        );
        prog[32] |= ebpf::BPF_X;
        #[allow(unused_mut)]
        let mut executable = Executable::<TestContextObject>::from_text_bytes(
            &prog,
            loader.clone(),
            SBPFVersion::V0,
            FunctionRegistry::default(),
        )
        .unwrap();
        test_interpreter_and_jit!(
            executable,
            NO_INPUT,
            TestContextObject::new(4),
            ProgramResult::Ok(expected_result),
        );
    }
}

#[test]
fn test_pqr_v2() {
    let mut prog = [0; 56];
    prog[0] = ebpf::ADD64_IMM;
    prog[1] = 10;
    prog[8] = ebpf::MOV32_IMM;
    prog[16] = ebpf::HOR64_IMM;
    prog[24] = ebpf::MOV32_IMM;
    prog[25] = 1; // dst = R1
    prog[32] = ebpf::HOR64_IMM;
    prog[33] = 1; // dst = R1
    prog[41] = 16; // src = R1
    prog[48] = ebpf::EXIT;
    let loader = Arc::new(BuiltinProgram::new_loader(Config::default()));
    for (opc, dst, src, expected_result) in [
        (ebpf::UHMUL64_IMM, 13u64, 4u64, 0u64),
        (ebpf::UDIV32_IMM, 13u64, 4u64, 3u64),
        (ebpf::UDIV64_IMM, 13u64, 4u64, 3u64),
        (ebpf::UREM32_IMM, 13u64, 4u64, 1u64),
        (ebpf::UREM64_IMM, 13u64, 4u64, 1u64),
        (ebpf::UHMUL64_IMM, 13u64, u32::MAX as u64, 0u64),
        (ebpf::UDIV32_IMM, 13u64, u32::MAX as u64, 0u64),
        (ebpf::UDIV64_IMM, 13u64, u32::MAX as u64, 0u64),
        (ebpf::UREM32_IMM, 13u64, u32::MAX as u64, 13u64),
        (ebpf::UREM64_IMM, 13u64, u32::MAX as u64, 13u64),
        (ebpf::UHMUL64_IMM, u64::MAX, 4u64, 3u64),
        (ebpf::UDIV32_IMM, u64::MAX, 4u64, (u32::MAX / 4) as u64),
        (ebpf::UDIV64_IMM, u64::MAX, 4u64, u64::MAX / 4),
        (ebpf::UREM32_IMM, u64::MAX, 4u64, 3u64),
        (ebpf::UREM64_IMM, u64::MAX, 4u64, 3u64),
        (
            ebpf::UHMUL64_IMM,
            u64::MAX,
            u32::MAX as u64,
            u32::MAX as u64 - 1,
        ),
        (ebpf::UDIV32_IMM, u64::MAX, u32::MAX as u64, 1u64),
        (
            ebpf::UDIV64_IMM,
            u64::MAX,
            u32::MAX as u64,
            u32::MAX as u64 + 2,
        ),
        (ebpf::UREM32_IMM, u64::MAX, u32::MAX as u64, 0u64),
        (ebpf::UREM64_IMM, u64::MAX, u32::MAX as u64, 0u64),
        (
            ebpf::LMUL32_IMM,
            13i64 as u64,
            4i32 as u32 as u64,
            52i32 as u32 as u64,
        ),
        (ebpf::LMUL64_IMM, 13i64 as u64, 4i64 as u64, 52i64 as u64),
        (ebpf::SHMUL64_IMM, 13i64 as u64, 4i64 as u64, 0i64 as u64),
        (
            ebpf::SDIV32_IMM,
            13i64 as u64,
            4i32 as u32 as u64,
            3i32 as u32 as u64,
        ),
        (ebpf::SDIV64_IMM, 13i64 as u64, 4i64 as u64, 3i64 as u64),
        (
            ebpf::SREM32_IMM,
            13i64 as u64,
            4i32 as u32 as u64,
            1i64 as u64,
        ),
        (ebpf::SREM64_IMM, 13i64 as u64, 4i64 as u64, 1i64 as u64),
        (
            ebpf::LMUL32_IMM,
            13i64 as u64,
            -4i32 as u32 as u64,
            -52i32 as u32 as u64,
        ),
        (ebpf::LMUL64_IMM, 13i64 as u64, -4i64 as u64, -52i64 as u64),
        (ebpf::SHMUL64_IMM, 13i64 as u64, -4i64 as u64, -1i64 as u64),
        (
            ebpf::SDIV32_IMM,
            13i64 as u64,
            -4i32 as u32 as u64,
            -3i32 as u32 as u64,
        ),
        (ebpf::SDIV64_IMM, 13i64 as u64, -4i64 as u64, -3i64 as u64),
        (
            ebpf::SREM32_IMM,
            13i64 as u64,
            -4i32 as u32 as u64,
            1i64 as u64,
        ),
        (ebpf::SREM64_IMM, 13i64 as u64, -4i64 as u64, 1i64 as u64),
        (
            ebpf::LMUL32_IMM,
            -13i64 as u64,
            4i32 as u32 as u64,
            -52i32 as u32 as u64,
        ),
        (ebpf::LMUL64_IMM, -13i64 as u64, 4i64 as u64, -52i64 as u64),
        (ebpf::SHMUL64_IMM, -13i64 as u64, 4i64 as u64, -1i64 as u64),
        (
            ebpf::SDIV32_IMM,
            -13i64 as u64,
            4i32 as u32 as u64,
            -3i32 as u32 as u64,
        ),
        (ebpf::SDIV64_IMM, -13i64 as u64, 4i64 as u64, -3i64 as u64),
        (
            ebpf::SREM32_IMM,
            -13i64 as u64,
            4i32 as u32 as u64,
            -1i32 as u32 as u64,
        ),
        (ebpf::SREM64_IMM, -13i64 as u64, 4i64 as u64, -1i64 as u64),
        (
            ebpf::LMUL32_IMM,
            -13i64 as u64,
            -4i32 as u32 as u64,
            52i32 as u32 as u64,
        ),
        (ebpf::LMUL64_IMM, -13i64 as u64, -4i64 as u64, 52i64 as u64),
        (ebpf::SHMUL64_IMM, -13i64 as u64, -4i64 as u64, 0i64 as u64),
        (
            ebpf::SDIV32_IMM,
            -13i64 as u64,
            -4i32 as u32 as u64,
            3i32 as u32 as u64,
        ),
        (ebpf::SDIV64_IMM, -13i64 as u64, -4i64 as u64, 3i64 as u64),
        (
            ebpf::SREM32_IMM,
            -13i64 as u64,
            -4i32 as u32 as u64,
            -1i32 as u32 as u64,
        ),
        (ebpf::SREM64_IMM, -13i64 as u64, -4i64 as u64, -1i64 as u64),
    ] {
        LittleEndian::write_u32(&mut prog[12..], dst as u32);
        LittleEndian::write_u32(&mut prog[20..], (dst >> 32) as u32);
        LittleEndian::write_u32(&mut prog[28..], src as u32);
        LittleEndian::write_u32(&mut prog[36..], (src >> 32) as u32);
        LittleEndian::write_u32(&mut prog[44..], src as u32);
        prog[40] = opc;
        #[allow(unused_mut)]
        let mut executable = Executable::<TestContextObject>::from_text_bytes(
            &prog,
            loader.clone(),
            SBPFVersion::V2,
            FunctionRegistry::default(),
        )
        .unwrap();
        test_interpreter_and_jit!(
            executable,
            NO_INPUT,
            TestContextObject::new(7),
            ProgramResult::Ok(expected_result),
        );
        prog[40] |= ebpf::BPF_X;
        #[allow(unused_mut)]
        let mut executable = Executable::<TestContextObject>::from_text_bytes(
            &prog,
            loader.clone(),
            SBPFVersion::V2,
            FunctionRegistry::default(),
        )
        .unwrap();
        test_interpreter_and_jit!(
            executable,
            NO_INPUT,
            TestContextObject::new(7),
            ProgramResult::Ok(expected_result),
        );
    }
}

#[test]
fn test_err_pqr_divide_by_zero() {
    let mut prog = [0; 32];
    prog[0] = ebpf::ADD64_IMM;
    prog[1] = 10;
    prog[8] = ebpf::MOV32_IMM;
    prog[24] = ebpf::EXIT;
    let loader = Arc::new(BuiltinProgram::new_loader(Config::default()));
    for opc in [
        ebpf::UDIV32_REG,
        ebpf::UDIV64_REG,
        ebpf::UREM32_REG,
        ebpf::UREM64_REG,
        ebpf::SDIV32_REG,
        ebpf::SDIV64_REG,
        ebpf::SREM32_REG,
        ebpf::SREM64_REG,
    ] {
        prog[16] = opc;
        #[allow(unused_mut)]
        let mut executable = Executable::<TestContextObject>::from_text_bytes(
            &prog,
            loader.clone(),
            SBPFVersion::V2,
            FunctionRegistry::default(),
        )
        .unwrap();
        test_interpreter_and_jit!(
            executable,
            NO_INPUT,
            TestContextObject::new(3),
            ProgramResult::Err(EbpfError::DivideByZero),
        );
    }
}

#[test]
fn test_err_pqr_divide_overflow() {
    let mut prog = [0; 48];
    prog[0] = ebpf::ADD64_IMM;
    prog[1] = 10;
    prog[8] = ebpf::MOV64_IMM;
    LittleEndian::write_i32(&mut prog[12..], 1);
    prog[16] = ebpf::LSH64_IMM;
    prog[24] = ebpf::MOV64_IMM;
    prog[25] = 1; // dst = R1
    LittleEndian::write_i32(&mut prog[28..], -1);
    prog[33] = 16; // src = R1
    LittleEndian::write_i32(&mut prog[36..], -1);
    prog[40] = ebpf::EXIT;
    let loader = Arc::new(BuiltinProgram::new_mock());
    for opc in [
        ebpf::SDIV32_IMM,
        ebpf::SDIV64_IMM,
        ebpf::SREM32_IMM,
        ebpf::SREM64_IMM,
        ebpf::SDIV32_REG,
        ebpf::SDIV64_REG,
        ebpf::SREM32_REG,
        ebpf::SREM64_REG,
    ] {
        prog[20] = if opc & ebpf::BPF_B != 0 { 63 } else { 31 };
        prog[32] = opc;
        #[allow(unused_mut)]
        let mut executable = Executable::<TestContextObject>::from_text_bytes(
            &prog,
            loader.clone(),
            SBPFVersion::V2,
            FunctionRegistry::default(),
        )
        .unwrap();
        test_interpreter_and_jit!(
            executable,
            NO_INPUT,
            TestContextObject::new(5),
            ProgramResult::Err(EbpfError::DivideOverflow),
        );
    }
}

// Loads and stores

#[test]
fn test_memory_instructions() {
    for sbpf_version in [SBPFVersion::V0, SBPFVersion::V4] {
        let config = Config {
            enabled_sbpf_versions: sbpf_version..=sbpf_version,
            ..Config::default()
        };

        let input = [0xaa, 0xbb, 0x11, 0xcc, 0xdd];
        test_interpreter_and_jit_asm!(
            "
            add64 r10, 0
            ldxb r0, [r1+2]
            exit",
            config.clone(),
            &raw const input,
            TestContextObject::new(3),
            ProgramResult::Ok(0x11),
        );
        let input = [0xaa, 0xbb, 0x11, 0x22, 0xcc, 0xdd];
        test_interpreter_and_jit_asm!(
            "
            add64 r10, 0
            ldxh r0, [r1+2]
            exit",
            config.clone(),
            &raw const input,
            TestContextObject::new(3),
            ProgramResult::Ok(0x2211),
        );
        let input = [0xaa, 0xbb, 0x11, 0x22, 0x33, 0x44, 0xcc, 0xdd];
        test_interpreter_and_jit_asm!(
            "
            add64 r10, 0
            ldxw r0, [r1+2]
            exit",
            config.clone(),
            &raw const input,
            TestContextObject::new(3),
            ProgramResult::Ok(0x44332211),
        );
        let input = [
            0xaa, 0xbb, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0xcc, 0xdd,
        ];
        test_interpreter_and_jit_asm!(
            "
            add64 r10, 0
            ldxdw r0, [r1+2]
            exit",
            config.clone(),
            &raw const input,
            TestContextObject::new(3),
            ProgramResult::Ok(0x8877665544332211),
        );
        let mut input = [
            0xaa, 0xbb, 0xff, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0xcc, 0xdd,
        ];
        test_interpreter_and_jit_asm!(
            "
            add64 r10, 0
            stb [r1+2], 0x11
            ldxdw r0, [r1+2]
            exit",
            config.clone(),
            &raw mut input,
            TestContextObject::new(4),
            ProgramResult::Ok(0x8877665544332211),
        );
        let mut input = [
            0xaa, 0xbb, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0xcc, 0xdd,
        ];
        test_interpreter_and_jit_asm!(
            "
            add64 r10, 0
            stb [r1+2], -1
            ldxdw r0, [r1+2]
            exit",
            config.clone(),
            &raw mut input,
            TestContextObject::new(4),
            ProgramResult::Ok(0x88776655443322FF),
        );
        let mut input = [
            0xaa, 0xbb, 0xff, 0xff, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0xcc, 0xdd,
        ];
        test_interpreter_and_jit_asm!(
            "
            add64 r10, 0
            sth [r1+2], 0x2211
            ldxdw r0, [r1+2]
            exit",
            config.clone(),
            &raw mut input,
            TestContextObject::new(4),
            ProgramResult::Ok(0x8877665544332211),
        );
        let mut input = [
            0xaa, 0xbb, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0xcc, 0xdd,
        ];
        test_interpreter_and_jit_asm!(
            "
            add64 r10, 0
            sth [r1+2], -1
            ldxdw r0, [r1+2]
            exit",
            config.clone(),
            &raw mut input,
            TestContextObject::new(4),
            ProgramResult::Ok(0x887766554433FFFF),
        );
        let mut input = [
            0xaa, 0xbb, 0xff, 0xff, 0xff, 0xff, 0x55, 0x66, 0x77, 0x88, 0xcc, 0xdd,
        ];
        test_interpreter_and_jit_asm!(
            "
            add64 r10, 0
            stw [r1+2], 0x44332211
            ldxdw r0, [r1+2]
            exit",
            config.clone(),
            &raw mut input,
            TestContextObject::new(4),
            ProgramResult::Ok(0x8877665544332211),
        );
        let mut input = [
            0xaa, 0xbb, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0xcc, 0xdd,
        ];
        test_interpreter_and_jit_asm!(
            "
            add64 r10, 0
            stw [r1+2], -1
            ldxdw r0, [r1+2]
            exit",
            config.clone(),
            &raw mut input,
            TestContextObject::new(4),
            ProgramResult::Ok(0x88776655FFFFFFFF),
        );
        let mut input = [
            0xaa, 0xbb, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xcc, 0xdd,
        ];
        test_interpreter_and_jit_asm!(
            "
            add64 r10, 0
            stdw [r1+2], 0x44332211
            ldxdw r0, [r1+2]
            exit",
            config.clone(),
            &raw mut input,
            TestContextObject::new(4),
            ProgramResult::Ok(0x44332211),
        );
        let mut input = [
            0xaa, 0xbb, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0xcc, 0xdd,
        ];
        test_interpreter_and_jit_asm!(
            "
            add64 r10, 0
            stdw [r1+2], -1
            ldxdw r0, [r1+2]
            exit",
            config.clone(),
            &raw mut input,
            TestContextObject::new(4),
            ProgramResult::Ok(0xFFFFFFFFFFFFFFFF),
        );

        let mut input = [0xaa, 0xbb, 0xff, 0xcc, 0xdd];
        test_interpreter_and_jit_asm!(
            "
            add64 r10, 0
            mov32 r2, 0x11
            stxb [r1+2], r2
            ldxb r0, [r1+2]
            exit",
            config.clone(),
            &raw mut input,
            TestContextObject::new(5),
            ProgramResult::Ok(0x11),
        );
        let mut input = [0xaa, 0xbb, 0xff, 0xff, 0xcc, 0xdd];
        test_interpreter_and_jit_asm!(
            "
            add64 r10, 0
            mov32 r2, 0x2211
            stxh [r1+2], r2
            ldxh r0, [r1+2]
            exit",
            config.clone(),
            &raw mut input,
            TestContextObject::new(5),
            ProgramResult::Ok(0x2211),
        );
        let mut input = [0xaa, 0xbb, 0xff, 0xff, 0xff, 0xff, 0xcc, 0xdd];
        test_interpreter_and_jit_asm!(
            "
            add64 r10, 0
            mov32 r2, 0x44332211
            stxw [r1+2], r2
            ldxw r0, [r1+2]
            exit",
            config.clone(),
            &raw mut input,
            TestContextObject::new(5),
            ProgramResult::Ok(0x44332211),
        );
        let mut input = [
            0xaa, 0xbb, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xcc, 0xdd,
        ];
        test_interpreter_and_jit_asm!(
            "
            add64 r10, 0
            mov r2, -2005440939
            lsh r2, 32
            or r2, 0x44332211
            stxdw [r1+2], r2
            ldxdw r0, [r1+2]
            exit",
            config.clone(),
            &raw mut input,
            TestContextObject::new(7),
            ProgramResult::Ok(0x8877665544332211),
        );
    }
}

#[test]
fn test_hor64() {
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V2..=SBPFVersion::V2,
        ..Config::default()
    };
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        hor64 r0, 0x10203040
        hor64 r0, 0x01020304
        exit",
        config,
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Ok(0x1122334400000000),
    );
}

#[test]
fn test_ldxh_same_reg() {
    let mut input = [0xff, 0xff];
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r0, r1
        sth [r0], 0x1234
        ldxh r0, [r0]
        exit",
        &raw mut input,
        TestContextObject::new(5),
        ProgramResult::Ok(0x1234),
    );
}

#[test]
fn test_err_ldxdw_oob() {
    let input = [
        0xaa, 0xbb, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, //
        0x77, 0x88, 0xcc, 0xdd, //
    ];
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        ldxdw r0, [r1+6]
        exit",
        &raw const input,
        TestContextObject::new(2),
        ProgramResult::Err(EbpfError::AccessViolation(
            AccessType::Load,
            0x400000006,
            8,
            "input"
        )),
    );
}

#[test]
fn test_err_ldxdw_nomem() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        ldxdw r0, [r1+6]
        exit",
        NO_INPUT,
        TestContextObject::new(2),
        ProgramResult::Err(EbpfError::AccessViolation(
            AccessType::Load,
            0x400000006,
            8,
            "unallocated"
        )),
    );
}

#[test]
fn test_err_ldxdw_nomem_capped() {
    // The access violation would only be detected after running out of budget.
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        ldxdw r0, [r1+6]
        exit",
        NO_INPUT,
        TestContextObject::new(1),
        ProgramResult::Err(EbpfError::ExceededMaxInstructions),
    );
}

#[test]
fn test_memory_access_preserves_registers() {
    test_interpreter_and_jit_asm!(
        "
        mov64 r0, 0x1
        mov64 r1, 0x2
        mov64 r2, 0x4
        mov64 r3, 0x8
        mov64 r4, 0x10
        mov64 r5, 0x20
        mov64 r6, 0x40
        mov64 r7, 0x80
        mov64 r8, 0x100
        mov64 r9, 0x200
        stxdw [r10-8], r9
        stdw [r10-16], 0x400
        ldxdw r9, [r10-8]
        ldxdw r9, [r10-16]
        add64 r0, r1
        add64 r0, r2
        add64 r0, r3
        add64 r0, r4
        add64 r0, r5
        add64 r0, r6
        add64 r0, r7
        add64 r0, r8
        add64 r0, r9
        exit",
        NO_INPUT,
        TestContextObject::new(24),
        ProgramResult::Ok(0x5ff),
    );
}

#[test]
fn test_ldxb_all() {
    let input = [
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, //
        0x08, 0x09, //
    ];
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r0, r1
        ldxb r9, [r0+0]
        lsh r9, 0
        ldxb r8, [r0+1]
        lsh r8, 4
        ldxb r7, [r0+2]
        lsh r7, 8
        ldxb r6, [r0+3]
        lsh r6, 12
        ldxb r5, [r0+4]
        lsh r5, 16
        ldxb r4, [r0+5]
        lsh r4, 20
        ldxb r3, [r0+6]
        lsh r3, 24
        ldxb r2, [r0+7]
        lsh r2, 28
        ldxb r1, [r0+8]
        lsh r1, 32
        ldxb r0, [r0+9]
        lsh r0, 36
        or r0, r1
        or r0, r2
        or r0, r3
        or r0, r4
        or r0, r5
        or r0, r6
        or r0, r7
        or r0, r8
        or r0, r9
        exit",
        &raw const input,
        TestContextObject::new(32),
        ProgramResult::Ok(0x9876543210),
    );
}

#[test]
fn test_ldxh_all() {
    let input = [
        0x00, 0x00, 0x00, 0x01, 0x00, 0x02, 0x00, 0x03, //
        0x00, 0x04, 0x00, 0x05, 0x00, 0x06, 0x00, 0x07, //
        0x00, 0x08, 0x00, 0x09, //
    ];
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r0, r1
        ldxh r9, [r0+0]
        be16 r9
        lsh r9, 0
        ldxh r8, [r0+2]
        be16 r8
        lsh r8, 4
        ldxh r7, [r0+4]
        be16 r7
        lsh r7, 8
        ldxh r6, [r0+6]
        be16 r6
        lsh r6, 12
        ldxh r5, [r0+8]
        be16 r5
        lsh r5, 16
        ldxh r4, [r0+10]
        be16 r4
        lsh r4, 20
        ldxh r3, [r0+12]
        be16 r3
        lsh r3, 24
        ldxh r2, [r0+14]
        be16 r2
        lsh r2, 28
        ldxh r1, [r0+16]
        be16 r1
        lsh r1, 32
        ldxh r0, [r0+18]
        be16 r0
        lsh r0, 36
        or r0, r1
        or r0, r2
        or r0, r3
        or r0, r4
        or r0, r5
        or r0, r6
        or r0, r7
        or r0, r8
        or r0, r9
        exit",
        &raw const input,
        TestContextObject::new(42),
        ProgramResult::Ok(0x9876543210),
    );
}

#[test]
fn test_ldxh_all2() {
    let input = [
        0x00, 0x01, 0x00, 0x02, 0x00, 0x04, 0x00, 0x08, //
        0x00, 0x10, 0x00, 0x20, 0x00, 0x40, 0x00, 0x80, //
        0x01, 0x00, 0x02, 0x00, //
    ];
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r0, r1
        ldxh r9, [r0+0]
        be16 r9
        ldxh r8, [r0+2]
        be16 r8
        ldxh r7, [r0+4]
        be16 r7
        ldxh r6, [r0+6]
        be16 r6
        ldxh r5, [r0+8]
        be16 r5
        ldxh r4, [r0+10]
        be16 r4
        ldxh r3, [r0+12]
        be16 r3
        ldxh r2, [r0+14]
        be16 r2
        ldxh r1, [r0+16]
        be16 r1
        ldxh r0, [r0+18]
        be16 r0
        or r0, r1
        or r0, r2
        or r0, r3
        or r0, r4
        or r0, r5
        or r0, r6
        or r0, r7
        or r0, r8
        or r0, r9
        exit",
        &raw const input,
        TestContextObject::new(32),
        ProgramResult::Ok(0x3ff),
    );
}

#[test]
fn test_ldxw_all() {
    let input = [
        0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x02, //
        0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x08, //
        0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x02, 0x00, //
        0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x08, 0x00, //
        0x00, 0x01, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, //
    ];
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r0, r1
        ldxw r9, [r0+0]
        be32 r9
        ldxw r8, [r0+4]
        be32 r8
        ldxw r7, [r0+8]
        be32 r7
        ldxw r6, [r0+12]
        be32 r6
        ldxw r5, [r0+16]
        be32 r5
        ldxw r4, [r0+20]
        be32 r4
        ldxw r3, [r0+24]
        be32 r3
        ldxw r2, [r0+28]
        be32 r2
        ldxw r1, [r0+32]
        be32 r1
        ldxw r0, [r0+36]
        be32 r0
        or r0, r1
        or r0, r2
        or r0, r3
        or r0, r4
        or r0, r5
        or r0, r6
        or r0, r7
        or r0, r8
        or r0, r9
        exit",
        &raw const input,
        TestContextObject::new(32),
        ProgramResult::Ok(0x030f0f),
    );
}

#[test]
fn test_stxb_all() {
    let mut input = [
        0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, //
    ];
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r0, 0xf0
        mov r2, 0xf2
        mov r3, 0xf3
        mov r4, 0xf4
        mov r5, 0xf5
        mov r6, 0xf6
        mov r7, 0xf7
        mov r8, 0xf8
        stxb [r1], r0
        stxb [r1+1], r2
        stxb [r1+2], r3
        stxb [r1+3], r4
        stxb [r1+4], r5
        stxb [r1+5], r6
        stxb [r1+6], r7
        stxb [r1+7], r8
        ldxdw r0, [r1]
        be64 r0
        exit",
        &raw mut input,
        TestContextObject::new(20),
        ProgramResult::Ok(0xf0f2f3f4f5f6f7f8),
    );
}

#[test]
fn test_stxb_all2() {
    let mut input = [0xff, 0xff];
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r0, r1
        mov r1, 0xf1
        mov r9, 0xf9
        stxb [r0], r1
        stxb [r0+1], r9
        ldxh r0, [r0]
        be16 r0
        exit",
        &raw mut input,
        TestContextObject::new(9),
        ProgramResult::Ok(0xf1f9),
    );
}

#[test]
fn test_stxb_chain() {
    let mut input = [
        0x2a, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, //
        0x00, 0x00, //
    ];
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r0, r1
        ldxb r9, [r0+0]
        stxb [r0+1], r9
        ldxb r8, [r0+1]
        stxb [r0+2], r8
        ldxb r7, [r0+2]
        stxb [r0+3], r7
        ldxb r6, [r0+3]
        stxb [r0+4], r6
        ldxb r5, [r0+4]
        stxb [r0+5], r5
        ldxb r4, [r0+5]
        stxb [r0+6], r4
        ldxb r3, [r0+6]
        stxb [r0+7], r3
        ldxb r2, [r0+7]
        stxb [r0+8], r2
        ldxb r1, [r0+8]
        stxb [r0+9], r1
        ldxb r0, [r0+9]
        exit",
        &raw mut input,
        TestContextObject::new(22),
        ProgramResult::Ok(0x2a),
    );
}

// BPF_JMP : Branches

#[test]
fn test_exit_capped() {
    for sbpf_version in [SBPFVersion::V0, SBPFVersion::V4] {
        let config = Config {
            enabled_sbpf_versions: sbpf_version..=sbpf_version,
            ..Config::default()
        };

        test_interpreter_and_jit_asm!(
            "
            add64 r10, 0
            exit",
            config,
            NO_INPUT,
            TestContextObject::new(1),
            ProgramResult::Err(EbpfError::ExceededMaxInstructions),
        );
    }
}

#[test]
fn test_exit_without_value() {
    for sbpf_version in [SBPFVersion::V0, SBPFVersion::V4] {
        let config = Config {
            enabled_sbpf_versions: sbpf_version..=sbpf_version,
            ..Config::default()
        };

        test_interpreter_and_jit_asm!(
            "
            add64 r10, 0
            exit",
            config,
            NO_INPUT,
            TestContextObject::new(2),
            ProgramResult::Ok(0x0),
        );
    }
}

#[test]
fn test_exit() {
    for sbpf_version in [SBPFVersion::V0, SBPFVersion::V4] {
        let config = Config {
            enabled_sbpf_versions: sbpf_version..=sbpf_version,
            ..Config::default()
        };

        test_interpreter_and_jit_asm!(
            "
            add64 r10, 0
            mov r0, 0
            exit",
            config,
            NO_INPUT,
            TestContextObject::new(3),
            ProgramResult::Ok(0x0),
        );
    }
}

#[test]
fn test_early_exit() {
    for sbpf_version in [SBPFVersion::V0, SBPFVersion::V4] {
        let config = Config {
            enabled_sbpf_versions: sbpf_version..=sbpf_version,
            ..Config::default()
        };

        test_interpreter_and_jit_asm!(
            "
            add64 r10, 0
            mov r0, 3
            exit
            mov r0, 4
            exit",
            config,
            NO_INPUT,
            TestContextObject::new(3),
            ProgramResult::Ok(0x3),
        );
    }
}

#[test]
fn test_exit_to_nothing_is_capped() {
    test_interpreter_and_jit_asm!(
        r##"
        a:
            exit
        entrypoint:
            call -2
        "##,
        Config::default(),
        NO_INPUT,
        TestContextObject::new(3),
        ProgramResult::Err(EbpfError::ExecutionOverrun),
    );
}

#[test]
fn test_ja() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r0, 1
        ja +1
        mov r0, 2
        exit",
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Ok(0x1),
    );
}

#[test]
fn test_alu64_imm_sign_extension() {
    test_interpreter_and_jit_asm!(
        "
        mov64 r0, 0
        or64 r0, -1
        mov64 r1, -1
        and64 r1, -2
        mov64 r2, 0
        xor64 r2, -4
        add64 r0, r1
        add64 r0, r2
        exit",
        NO_INPUT,
        TestContextObject::new(9),
        ProgramResult::Ok(-7i64 as u64),
    );
}

#[test]
fn test_instruction_meter_checkpoint() {
    // Without checkpoints, all of the stores would be executed before the meter is checked at the
    // `exit`.
    let config = Config {
        instruction_meter_checkpoint_distance: 1,
        ..Config::default()
    };
    let mut input = [0u8; 4];
    test_interpreter_and_jit_asm!(
        "
        mov64 r0, 0
        stb [r1+0], 1
        stb [r1+1], 2
        stb [r1+2], 3
        stb [r1+3], 4
        exit",
        config,
        &raw mut input,
        TestContextObject::new(3),
        ProgramResult::Err(EbpfError::ExceededMaxInstructions),
    );
}

#[test]
fn test_noop_insertion() {
    let config = Config {
        noop_instruction_rate: 1,
        ..Config::default()
    };
    // The no-ops are inserted at random.
    for _ in 0..16 {
        test_interpreter_and_jit_asm!(
            "
            mov64 r0, 0
            mov64 r1, 0
            lddw r2, 0x100000000
            add64 r1, 1
            call function_foo
            jlt r1, 10, -3
            exit
            function_foo:
            add64 r0, r2
            exit",
            config.clone(),
            NO_INPUT,
            TestContextObject::new(54),
            ProgramResult::Ok(0xa00000000),
        );
    }
}

#[test]
fn test_conditional_jumps() {
    const THEN: u32 = 0x5448454E;
    const ELSE: u32 = 0x454C5345;
    let mut prog = [0; 80];
    prog[0] = ebpf::ADD64_IMM;
    prog[1] = 0;
    prog[8] = ebpf::LD_DW_IMM;
    prog[9] = 1; // dst = R1
    prog[17] = 1; // dst = R1
    prog[24] = ebpf::LD_DW_IMM;
    prog[41] = 16; // src = R1
    prog[42] = 2; // offset = +2
    prog[48] = ebpf::MOV32_IMM;
    LittleEndian::write_u32(&mut prog[52..], ELSE);
    prog[56] = ebpf::EXIT;
    prog[64] = ebpf::MOV32_IMM;
    LittleEndian::write_u32(&mut prog[68..], THEN);
    prog[72] = ebpf::EXIT;
    let loader = Arc::new(BuiltinProgram::new_loader(Config::default()));
    for (opc, dst, src, expected_result) in [
        (ebpf::BPF_JEQ, 3, 3, THEN),
        (ebpf::BPF_JEQ, 3, 7, ELSE),
        (ebpf::BPF_JGT, 7, 3, THEN),
        (ebpf::BPF_JGT, 3, 7, ELSE),
        (ebpf::BPF_JGE, 3, 3, THEN),
        (ebpf::BPF_JGE, 7, 3, THEN),
        (ebpf::BPF_JGE, 3, 7, ELSE),
        (ebpf::BPF_JLT, 3, 7, THEN),
        (ebpf::BPF_JLT, 7, 3, ELSE),
        (ebpf::BPF_JLE, 3, 3, THEN),
        (ebpf::BPF_JLE, 3, 7, THEN),
        (ebpf::BPF_JLE, 7, 3, ELSE),
        (ebpf::BPF_JSET, 3, 7, THEN),
        (ebpf::BPF_JSET, 2, 4, ELSE),
        (ebpf::BPF_JSET, -8, 7, ELSE),
        (ebpf::BPF_JNE, 3, 7, THEN),
        (ebpf::BPF_JNE, 3, 3, ELSE),
        (ebpf::BPF_JSGT, -3, -7, THEN),
        (ebpf::BPF_JSGT, -7, -3, ELSE),
        (ebpf::BPF_JSGE, -3, -3, THEN),
        (ebpf::BPF_JSGE, -3, -7, THEN),
        (ebpf::BPF_JSGE, -7, -3, ELSE),
        (ebpf::BPF_JSLT, -7, -3, THEN),
        (ebpf::BPF_JSLT, -3, -7, ELSE),
        (ebpf::BPF_JSLE, -3, -3, THEN),
        (ebpf::BPF_JSLE, -7, -3, THEN),
        (ebpf::BPF_JSLE, -3, -7, ELSE),
    ] {
        LittleEndian::write_u32(&mut prog[12..], src as u32);
        LittleEndian::write_u32(&mut prog[20..], (src as i64 >> 32) as u32);
        LittleEndian::write_u32(&mut prog[28..], dst as u32);
        LittleEndian::write_u32(&mut prog[36..], (dst as i64 >> 32) as u32);
        LittleEndian::write_u32(&mut prog[44..], src as u32);
        for op_class in [
            ebpf::BPF_JMP32 | ebpf::BPF_K,
            ebpf::BPF_JMP32 | ebpf::BPF_X,
            ebpf::BPF_JMP64 | ebpf::BPF_K,
            ebpf::BPF_JMP64 | ebpf::BPF_X,
        ] {
            prog[40] = op_class | opc;
            #[allow(unused_mut)]
            let mut executable = Executable::<TestContextObject>::from_text_bytes(
                &prog,
                loader.clone(),
                SBPFVersion::V3,
                FunctionRegistry::default(),
            )
            .unwrap();
            test_interpreter_and_jit!(
                executable,
                NO_INPUT,
                TestContextObject::new(6),
                ProgramResult::Ok(expected_result as u64),
            );
        }
    }
}

#[test]
fn test_conditional_jumps_same_register() {
    // Zero in the lower half only, for `jset32`.
    for value in [0, 3, -3, 1 << 32] {
        for condition in [
            "jeq", "jgt", "jge", "jlt", "jle", "jset", "jne", "jsgt", "jsge", "jslt", "jsle",
        ] {
            for (suffix, compared) in [("32", value as u32 as i64), ("", value)] {
                let taken = match condition {
                    "jeq" | "jge" | "jle" | "jsge" | "jsle" => true,
                    "jset" => compared != 0,
                    _ => false,
                };
                test_interpreter_and_jit_asm!(
                    &format!(
                        "
                        lddw r1, {value}
                        {condition}{suffix} r1, r1, +2
                        mov64 r0, 0
                        exit
                        mov64 r0, 1
                        exit"
                    ),
                    NO_INPUT,
                    TestContextObject::new(4),
                    ProgramResult::Ok(taken as u64),
                );
            }
        }
    }
}

#[test]
fn test_jset_upper_half() {
    // The only bit in common is in the upper half.
    test_interpreter_and_jit_asm!(
        "
        lddw r1, 0x100000000
        mov64 r0, 0
        jset r1, -1, +1
        mov64 r0, 1
        exit",
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Ok(0),
    );
    test_interpreter_and_jit_asm!(
        "
        lddw r1, 0x100000000
        mov64 r2, -1
        mov64 r0, 0
        jset r1, r2, +1
        mov64 r0, 1
        exit",
        NO_INPUT,
        TestContextObject::new(5),
        ProgramResult::Ok(0),
    );
}

// Call Stack

#[test]
fn test_stack1() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 64
        mov r1, 51
        stdw [r10-16], 0xab
        stdw [r10-8], 0xcd
        and r1, 1
        lsh r1, 3
        mov r2, r10
        add r2, r1
        ldxdw r0, [r2-16]
        exit",
        NO_INPUT,
        TestContextObject::new(10),
        ProgramResult::Ok(0xcd),
    );
}

#[test]
fn test_stack2() {
    test_syscall_asm!(
        "
        add64 r10, 64
        stb [r10-4], 0x01
        stb [r10-3], 0x02
        stb [r10-2], 0x03
        stb [r10-1], 0x04
        mov r1, r10
        mov r2, 0x4
        sub r1, r2
        syscall bpf_mem_frob
        mov r1, 0
        ldxb r2, [r10-4]
        ldxb r3, [r10-3]
        ldxb r4, [r10-2]
        ldxb r5, [r10-1]
        syscall bpf_gather_bytes
        xor r0, 0x2a2a2a2a
        exit",
        NO_INPUT,
        (
            "bpf_mem_frob" => syscalls::SyscallMemFrob,
            "bpf_gather_bytes" => syscalls::SyscallGatherBytes,
        ),
        TestContextObject::new(17),
        ProgramResult::Ok(0x01020304),
    );
}

#[test]
fn test_string_stack() {
    test_syscall_asm!(
        "
        add64 r10, 64
        mov r1, 0x78636261
        stxw [r10-8], r1
        mov r6, 0x0
        stxb [r10-4], r6
        stxb [r10-12], r6
        mov r1, 0x79636261
        stxw [r10-16], r1
        mov r1, r10
        add r1, -8
        mov r2, r1
        syscall bpf_str_cmp
        mov r1, r0
        mov r0, 0x1
        lsh r1, 0x20
        rsh r1, 0x20
        jne r1, 0x0, +11
        mov r1, r10
        add r1, -8
        mov r2, r10
        add r2, -16
        syscall bpf_str_cmp
        mov r1, r0
        lsh r1, 0x20
        rsh r1, 0x20
        mov r0, 0x1
        jeq r1, r6, +1
        mov r0, 0x0
        exit",
        NO_INPUT,
        (
            "bpf_str_cmp" => syscalls::SyscallStrCmp,
        ),
        TestContextObject::new(29),
        ProgramResult::Ok(0x0),
    );
}

#[test]
fn test_err_stack_out_of_bound() {
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V0..=SBPFVersion::V4,
        enable_stack_frame_gaps: false,
        max_call_depth: 64,
        ..Config::default()
    };

    // The stack goes from MM_STACK_START to MM_STACK_START + config.stack_size()

    // Check that accessing MM_STACK_START - 1 fails
    test_interpreter_and_jit_asm!(
        "
        stb [r10-0x1001], 0
        exit",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(1),
        ProgramResult::Err(EbpfError::StackAccessViolation(
            AccessType::Store,
            ebpf::MM_STACK_START - 1,
            1,
            0
        )),
    );

    // Check that accessing MM_STACK_START + expected_stack_len fails
    test_interpreter_and_jit_asm!(
        "
        mov r0, r10
        mov r1, 63
        lsh r1, 12
        add r0, r1
        stb [r0], 0
        exit",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(5),
        ProgramResult::Err(EbpfError::StackAccessViolation(
            AccessType::Store,
            ebpf::MM_STACK_START + config.stack_size() as u64,
            1,
            config.max_call_depth as i64
        )),
    );
}

#[test]
fn test_dynamic_stack_frames_sbpfv1() {
    // In SBPFv1 the stack starts at the top and does not grow automatically
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V1..=SBPFVersion::V1,
        ..Config::default()
    };
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        call function_foo
        exit
        function_foo:
        add64 r10, 0
        mov r0, r10
        exit",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(6),
        ProgramResult::Ok(ebpf::MM_STACK_START + config.stack_size() as u64),
    );

    // See the comment in CallFrames::resize_stack() for the reason why it's
    // safe to let the stack pointer overflow
    test_interpreter_and_jit_asm!(
        "
        add r10, -0x7FFFFF00
        call function_stage1
        exit
        function_stage1:
        add r10, -0x7FFFFF00
        call function_stage2
        exit
        function_stage2:
        add r10, -0x7FFFFF00
        call function_stage3
        exit
        function_stage3:
        add r10, -0x7FFFFF00
        call function_stage4
        exit
        function_stage4:
        add r10, -0x1440
        call function_final
        exit
        function_final:
        add r10, 0
        stb [r10], 0
        exit",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(12),
        ProgramResult::Err(EbpfError::AccessViolation(
            AccessType::Store,
            0x3F000 - 64,
            1,
            "unallocated"
        )),
    );

    // Check that changes to r10 are immediately visible
    test_interpreter_and_jit_asm!(
        "
        add r10, -64
        stxdw [r10-8], r10
        call function_foo
        ldxdw r0, [r10-8]
        exit
        function_foo:
        add r10, 0
        exit",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(7),
        ProgramResult::Ok(ebpf::MM_STACK_START + config.stack_size() as u64 - 64),
    );

    // Check that changes to r10 continue to be visible in a callee
    test_interpreter_and_jit_asm!(
        "
        add r10, -64
        call function_foo
        exit
        function_foo:
        add r10, 0
        mov r0, r10
        exit",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(6),
        ProgramResult::Ok(ebpf::MM_STACK_START + config.stack_size() as u64 - 64),
    );

    // And check that changes to r10 are undone after returning
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        call function_foo
        mov r0, r10
        exit
        function_foo:
        add r10, -64
        exit
        ",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(6),
        ProgramResult::Ok(ebpf::MM_STACK_START + config.stack_size() as u64),
    );
}

#[test]
fn test_entrypoint_exit() {
    // With fixed frames we used to exit the entrypoint when we reached an exit
    // instruction and the stack size was 1 * config.stack_frame_size, which
    // meant that we were in the entrypoint's frame.  With dynamic frames we
    // can't infer anything from the stack size so we track call depth
    // explicitly. Make sure exit still works with both fixed and dynamic
    // frames.
    for highest_sbpf_version in [SBPFVersion::V0, SBPFVersion::V4] {
        let config = Config {
            enabled_sbpf_versions: SBPFVersion::V0..=highest_sbpf_version,
            ..Config::default()
        };

        // This checks that when foo exits we don't stop execution even if the
        // stack is empty (stack size and call depth are decoupled)
        test_interpreter_and_jit_asm!(
            "
            entrypoint:
            add64 r10, 0
            call function_foo
            mov r0, 42
            exit
            function_foo:
            add64 r10, 0
            mov r0, 12
            exit",
            config,
            NO_INPUT,
            TestContextObject::new(7),
            ProgramResult::Ok(42),
        );
    }
}

#[test]
fn test_stack_call_depth_tracking() {
    for highest_sbpf_version in [SBPFVersion::V0, SBPFVersion::V4] {
        let config = Config {
            enabled_sbpf_versions: SBPFVersion::V0..=highest_sbpf_version,
            max_call_depth: 2,
            ..Config::default()
        };

        // Given max_call_depth=2, make sure that two sibling calls don't
        // trigger CallDepthExceeded. In other words ensure that we correctly
        // pop frames in the interpreter and decrement
        // EnvironmentStackSlotDepth on ebpf::EXIT in the jit.
        test_interpreter_and_jit_asm!(
            "
            add64 r10, 0
            call function_foo
            call function_foo
            exit
            function_foo:
            add64 r10, 0
            exit
            ",
            config.clone(),
            NO_INPUT,
            TestContextObject::new(8),
            ProgramResult::Ok(0),
        );

        // two nested calls should trigger CallDepthExceeded instead
        test_interpreter_and_jit_asm!(
            "
            entrypoint:
            add64 r10, 0
            call function_foo
            exit
            function_foo:
            add64 r10, 0
            call function_bar
            exit
            function_bar:
            add64 r10, 0
            exit
            ",
            config,
            NO_INPUT,
            TestContextObject::new(4),
            ProgramResult::Err(EbpfError::CallDepthExceeded),
        );
    }
}

#[test]
fn test_err_mem_access_out_of_bound() {
    let mut mem = [0; 512];
    let mut prog = [0; 40];
    prog[0] = ebpf::ADD64_IMM;
    prog[1] = 0;
    prog[8] = ebpf::LD_DW_IMM;
    prog[24] = ebpf::ST_B_IMM;
    prog[32] = ebpf::EXIT;
    let loader = Arc::new(BuiltinProgram::new_loader(Config::default()));
    for (address, k) in [
        (0x2u64, "allocated"),
        (0x8002u64, "unallocated"),
        (0x80000002u64, "unallocated"),
        (0x8000000000000002u64, "unallocated"),
    ] {
        LittleEndian::write_u32(&mut prog[12..], address as u32);
        LittleEndian::write_u32(&mut prog[20..], (address >> 32) as u32);
        #[allow(unused_mut)]
        let mut executable = Executable::<TestContextObject>::from_text_bytes(
            &prog,
            loader.clone(),
            SBPFVersion::V4,
            FunctionRegistry::default(),
        )
        .unwrap();
        test_interpreter_and_jit!(
            executable,
            &raw mut mem,
            TestContextObject::new(3),
            ProgramResult::Err(EbpfError::AccessViolation(AccessType::Store, address, 1, k)),
        );
    }
}

// CALL_IMM & CALL_REG : Procedure Calls

#[test]
fn test_relative_call_sbpfv0() {
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V0..=SBPFVersion::V0,
        ..Config::default()
    };
    let input = [1];
    test_interpreter_and_jit_elf!(
        "tests/elfs/relative_call_sbpfv0.so",
        config,
        &raw const input,
        (),
        TestContextObject::new(16),
        ProgramResult::Ok(3),
    );
}

#[test]
fn test_relative_call_sbpfv3() {
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V3..=SBPFVersion::V4,
        ..Config::default()
    };
    let input = [1];
    test_interpreter_and_jit_elf!(
        "tests/elfs/relative_call.so",
        config,
        &raw const input,
        (),
        TestContextObject::new(16),
        ProgramResult::Ok(3),
    );
}

#[test]
fn test_bpf_to_bpf_scratch_registers() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov64 r6, 0x11
        mov64 r7, 0x22
        mov64 r8, 0x44
        mov64 r9, 0x88
        call function_foo
        mov64 r0, r6
        add64 r0, r7
        add64 r0, r8
        add64 r0, r9
        exit
        function_foo:
        add64 r10, 0
        mov64 r6, 0x00
        mov64 r7, 0x00
        mov64 r8, 0x00
        mov64 r9, 0x00
        exit",
        NO_INPUT,
        TestContextObject::new(17),
        ProgramResult::Ok(0xFF),
    );
}

#[test]
fn test_syscall_parameter_on_stack() {
    test_syscall_asm!(
        "
        add64 r10, 0x100
        mov64 r1, r10
        add64 r1, -0x100
        mov64 r2, 0x1
        syscall bpf_syscall_string
        mov64 r0, 0x0
        exit",
        NO_INPUT,
        (
            "bpf_syscall_string" => syscalls::SyscallString,
        ),
        TestContextObject::new(7),
        ProgramResult::Ok(0),
    );
}

#[test]
fn test_callx() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov64 r0, 0x0
        mov64 r8, 0x1
        lsh64 r8, 0x20
        or64 r8, 0x38
        callx r8
        exit
        function_foo:
        add64 r10, 0
        mov64 r0, 0x2A
        exit",
        NO_INPUT,
        TestContextObject::new(10),
        ProgramResult::Ok(42),
    );
}

#[test]
fn test_callx_unaligned_target() {
    // The target is truncated to the instruction containing it.
    test_interpreter_and_jit_asm!(
        "
        mov64 r0, 0x0
        mov64 r8, 0x1
        lsh64 r8, 0x20
        or64 r8, 0x33
        callx r8
        exit
        function_foo:
        mov64 r0, 0x2A
        exit",
        NO_INPUT,
        TestContextObject::new(8),
        ProgramResult::Ok(42),
    );
}

#[test]
fn test_err_callx_oob_computed() {
    // Just past the end of the program.
    test_interpreter_and_jit_asm!(
        "
        mov64 r8, 0x1
        lsh64 r8, 0x20
        or64 r8, 0x28
        callx r8
        exit",
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Err(EbpfError::CallOutsideTextSegment),
    );
    // Just before the start of the program.
    test_interpreter_and_jit_asm!(
        "
        mov64 r8, 0x1
        lsh64 r8, 0x20
        sub64 r8, 0x1
        callx r8
        exit",
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Err(EbpfError::CallOutsideTextSegment),
    );
}

#[test]
fn test_err_callx_oob_low() {
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V0..=SBPFVersion::V0,
        ..Config::default()
    };
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov64 r0, 0x3
        callx r0
        exit",
        config,
        NO_INPUT,
        TestContextObject::new(3),
        ProgramResult::Err(EbpfError::CallOutsideTextSegment),
    );
}

#[test]
fn test_err_callx_oob_high() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        lddw r0, 0x200000000
        callx r0
        exit",
        NO_INPUT,
        TestContextObject::new(3),
        ProgramResult::Err(EbpfError::CallOutsideTextSegment),
    );
}

#[test]
fn test_err_callx_oob_max() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        lddw r0, 0xFFFFFFFFFFFFFFF8
        callx r0
        exit",
        NO_INPUT,
        TestContextObject::new(3),
        ProgramResult::Err(EbpfError::CallOutsideTextSegment),
    );
}

#[test]
fn test_callx_unaligned_text_section() {
    test_interpreter_and_jit_elf!(
        "tests/elfs/callx_unaligned.so",
        NO_INPUT,
        (),
        TestContextObject::new(129),
        ProgramResult::Err(EbpfError::CallDepthExceeded),
    );
}

#[test]
fn test_bpf_to_bpf_depth() {
    for max_call_depth in [20usize, Config::default().max_call_depth] {
        let config = Config {
            max_call_depth,
            ..Config::default()
        };
        let input = [max_call_depth as u8];
        test_interpreter_and_jit_asm!(
            "
            add64 r10, 0
            ldxb r1, [r1]
            add64 r1, -2
            call function_foo
            exit
            function_foo:
            add64 r10, 0
            jeq r1, 0, +2
            add64 r1, -1
            call function_foo
            exit",
            config.clone(),
            &raw const input,
            TestContextObject::new(max_call_depth as u64 * 5 - 2),
            ProgramResult::Ok(0),
        );
        // The instruction count is lower here because all the `exit`s never run
        let input = [max_call_depth as u8 + 1];
        test_interpreter_and_jit_asm!(
            "
            add64 r10, 0
            ldxb r1, [r1]
            add64 r1, -2
            call function_foo
            exit
            function_foo:
            add64 r10, 0
            jeq r1, 0, +2
            add64 r1, -1
            call function_foo
            exit",
            config,
            &raw const input,
            TestContextObject::new(max_call_depth as u64 * 4),
            ProgramResult::Err(EbpfError::CallDepthExceeded),
        );
    }
}

#[test]
fn test_err_reg_stack_depth() {
    for max_call_depth in [20usize, Config::default().max_call_depth] {
        let config = Config {
            max_call_depth,
            ..Config::default()
        };
        test_interpreter_and_jit_asm!(
            "
            add64 r10, 0
            mov64 r0, 0x1
            lsh64 r0, 0x20
            callx r0
            exit",
            config.clone(),
            NO_INPUT,
            TestContextObject::new(4 * max_call_depth as u64),
            ProgramResult::Err(EbpfError::CallDepthExceeded),
        );
        // One instruction short of detecting the depth being exceeded.
        test_interpreter_and_jit_asm!(
            "
            add64 r10, 0
            mov64 r0, 0x1
            lsh64 r0, 0x20
            callx r0
            exit",
            config,
            NO_INPUT,
            TestContextObject::new(4 * max_call_depth as u64 - 1),
            ProgramResult::Err(EbpfError::ExceededMaxInstructions),
        );
    }
}

// CALL_IMM : Syscalls

/* TODO: syscalls::trash_registers needs asm!().
// https://github.com/rust-lang/rust/issues/72016
#[test]
fn test_call_save() {
    test_interpreter_and_jit_asm!(
        "
        mov64 r6, 0x1
        mov64 r7, 0x20
        mov64 r8, 0x300
        mov64 r9, 0x4000
        call 0
        mov64 r0, 0x0
        or64 r0, r6
        or64 r0, r7
        or64 r0, r8
        or64 r0, r9
        exit",
        NO_INPUT,
        (
            0 => syscalls::trash_registers,
        ),
        { |_vm, res: ProgramResult| { res.unwrap() == 0 } }
    );
}*/

#[test]
fn test_err_syscall_string() {
    let input = [72, 101, 108, 108, 111];
    test_syscall_asm!(
        "
        add64 r10, 0
        mov64 r1, 0x0
        syscall bpf_syscall_string
        mov64 r0, 0x0
        exit",
        &raw const input,
        (
            "bpf_syscall_string" => syscalls::SyscallString,
        ),
        TestContextObject::new(5),
        ProgramResult::Ok(0),
    );
}

#[test]
fn test_syscall_string() {
    let input = [72, 101, 108, 108, 111];
    test_syscall_asm!(
        "
        add64 r10, 0
        mov64 r2, 0x5
        syscall bpf_syscall_string
        mov64 r0, 0x0
        exit",
        &raw const input,
        (
            "bpf_syscall_string" => syscalls::SyscallString,
        ),
        TestContextObject::new(5),
        ProgramResult::Ok(0),
    );
}

#[test]
fn test_syscall() {
    test_syscall_asm!(
        "
        add64 r10, 0
        mov64 r1, 0xAA
        mov64 r2, 0xBB
        mov64 r3, 0xCC
        mov64 r4, 0xDD
        mov64 r5, 0xEE
        syscall bpf_syscall_u64
        mov64 r0, 0x0
        exit",
        NO_INPUT,
        (
            "bpf_syscall_u64" => syscalls::SyscallU64,
        ),
        TestContextObject::new(9),
        ProgramResult::Ok(0),
    );
}

struct SyscallErr;

impl BuiltinFunctionDefinition<TestContextObject> for SyscallErr {
    type Error = Box<dyn std::error::Error>;

    fn rust(
        _: &mut TestContextObject,
        _: u64,
        _: u64,
        _: u64,
        _: u64,
        _: u64,
    ) -> Result<u64, Self::Error> {
        Err(Box::new(EbpfError::DivideByZero))
    }
}

/// Expects the arguments `1, 2, 4, 8, 16`, overwrites every register a host function is allowed to
/// clobber and returns `0x400`.
struct SyscallClobber;

impl BuiltinFunctionDefinition<TestContextObject> for SyscallClobber {
    type Error = Box<dyn std::error::Error>;

    fn rust(
        _: &mut TestContextObject,
        a: u64,
        b: u64,
        c: u64,
        d: u64,
        e: u64,
    ) -> Result<u64, Self::Error> {
        if (a, b, c, d, e) != (1, 2, 4, 8, 16) {
            return Err(format!("unexpected arguments {:?}", (a, b, c, d, e)).into());
        }
        #[cfg(target_arch = "x86_64")]
        unsafe {
            std::arch::asm!(
                "mov rax, -1",
                "mov rcx, -1",
                "mov rdx, -1",
                "mov rsi, -1",
                "mov rdi, -1",
                "mov r8, -1",
                "mov r9, -1",
                "mov r10, -1",
                "mov r11, -1",
                "mov r12, -1",
                "mov r13, -1",
                "mov r14, -1",
                "mov r15, -1",
                out("rax") _,
                out("rcx") _,
                out("rdx") _,
                out("rsi") _,
                out("rdi") _,
                out("r8") _,
                out("r9") _,
                out("r10") _,
                out("r11") _,
                out("r12") _,
                out("r13") _,
                out("r14") _,
                out("r15") _,
            );
        }
        Ok(0x400)
    }
}

#[test]
fn test_err_syscall_error() {
    test_syscall_asm!(
        "
        mov64 r0, 0x7
        syscall bpf_syscall_err
        mov64 r0, 0x0
        exit",
        NO_INPUT,
        (
            "bpf_syscall_err" => SyscallErr,
        ),
        TestContextObject::new(2),
        ProgramResult::Err(EbpfError::SyscallError(Box::new(EbpfError::DivideByZero))),
    );
}

#[test]
fn test_syscall_preserves_registers() {
    test_syscall_asm!(
        "
        mov64 r1, 0x1
        mov64 r2, 0x2
        mov64 r3, 0x4
        mov64 r4, 0x8
        mov64 r5, 0x10
        mov64 r6, 0x20
        mov64 r7, 0x40
        mov64 r8, 0x80
        mov64 r9, 0x100
        mov64 r0, 0x200
        syscall bpf_syscall_clobber
        add64 r0, r1
        add64 r0, r2
        add64 r0, r3
        add64 r0, r4
        add64 r0, r5
        add64 r0, r6
        add64 r0, r7
        add64 r0, r8
        add64 r0, r9
        add64 r0, r10
        exit",
        NO_INPUT,
        (
            "bpf_syscall_clobber" => SyscallClobber,
        ),
        TestContextObject::new(22),
        ProgramResult::Ok(0x5ff + ebpf::MM_STACK_START + 0x1000),
    );
}

#[test]
fn test_syscall_in_internal_call() {
    test_syscall_asm!(
        "
        mov r1, 1
        call function_foo
        add64 r0, 1
        exit
        function_foo:
        mov r2, 2
        mov r3, 3
        mov r4, 4
        mov r5, 5
        syscall bpf_gather_bytes
        exit",
        NO_INPUT,
        (
            "bpf_gather_bytes" => syscalls::SyscallGatherBytes,
        ),
        TestContextObject::new(10),
        ProgramResult::Ok(0x0102030406),
    );
}

#[test]
fn test_err_syscall_error_capped() {
    // The meter is checked before the syscall.
    test_syscall_asm!(
        "
        mov64 r0, 0x7
        mov64 r0, 0x7
        syscall bpf_syscall_err
        exit",
        NO_INPUT,
        (
            "bpf_syscall_err" => SyscallErr,
        ),
        TestContextObject::new(2),
        ProgramResult::Err(EbpfError::ExceededMaxInstructions),
    );
}

#[test]
fn test_call_gather_bytes() {
    test_syscall_asm!(
        "
        add64 r10, 0
        mov r1, 1
        mov r2, 2
        mov r3, 3
        mov r4, 4
        mov r5, 5
        syscall bpf_gather_bytes
        exit",
        NO_INPUT,
        (
            "bpf_gather_bytes" => syscalls::SyscallGatherBytes,
        ),
        TestContextObject::new(8),
        ProgramResult::Ok(0x0102030405),
    );
}

#[test]
fn test_call_memfrob() {
    let mut input = [0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08];
    test_syscall_asm!(
        "
        add64 r10, 0
        mov r6, r1
        add r1, 2
        mov r2, 4
        syscall bpf_mem_frob
        ldxdw r0, [r6]
        be64 r0
        exit",
        &raw mut input,
        (
            "bpf_mem_frob" => syscalls::SyscallMemFrob,
        ),
        TestContextObject::new(8),
        ProgramResult::Ok(0x102292e2f2c0708),
    );
}

declare_builtin_function!(
    /// For test_nested_vm_syscall()
    SyscallNestedVm,
    fn rust(
        _context_object: &mut TestContextObject,
        depth: u64,
        throw: u64,
        version: u64,
        _arg4: u64,
        _arg5: u64,
    ) -> Result<u64, Box<dyn std::error::Error>> {
        let (result, expected_result): (Result<u64, Box<dyn std::error::Error>>, ProgramResult) =
            if throw == 0 {
                (Result::Ok(42), ProgramResult::Ok(42))
            } else {
                (
                    Result::Err(Box::new(EbpfError::CallDepthExceeded)),
                    ProgramResult::Err(EbpfError::SyscallError(Box::new(
                        EbpfError::CallDepthExceeded,
                    ))),
                )
            };
        #[allow(unused_mut)]
        if depth > 0 {
            let mut config = Config::default();
            if version == 0 {
                config.enabled_sbpf_versions = SBPFVersion::V0..=SBPFVersion::V0;
            } else {
                config.enabled_sbpf_versions = SBPFVersion::V3..=SBPFVersion::V4;
            };
            let mut loader = BuiltinProgram::new_loader(config);
            SyscallNestedVm::register(&mut loader, "nested_vm_syscall").unwrap();
            let mut executable = assemble::<TestContextObject>(
                "
                add64 r10, 0
                ldxb r2, [r1+1]
                ldxb r1, [r1]
                syscall nested_vm_syscall
                exit",
                Arc::new(loader),
            )
            .unwrap();
            let input = [depth as u8 - 1, throw as u8];
            test_interpreter_and_jit!(
                executable,
                &raw const input,
                TestContextObject::new(if throw == 0 { 5 } else { 4 }),
                expected_result,
            );
        }
        result
    }
);

#[test]
fn test_nested_vm_syscall() {
    let mut context_object = TestContextObject::default();

    // SBPFv0
    let result = SyscallNestedVm::rust(&mut context_object, 1, 0, 0, 0, 0);
    assert_eq!(result.unwrap(), 42);
    let result = SyscallNestedVm::rust(&mut context_object, 1, 1, 0, 0, 0);
    assert_error!(result, "CallDepthExceeded");

    // SBPFv4
    let result = SyscallNestedVm::rust(&mut context_object, 1, 0, 3, 0, 0);
    assert_eq!(result.unwrap(), 42);
    let result = SyscallNestedVm::rust(&mut context_object, 1, 1, 3, 0, 0);
    assert_error!(result, "CallDepthExceeded");
}

// Instruction Meter Limit

#[test]
fn test_tight_infinite_loop_conditional() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        jsge r0, r0, -1
        exit",
        NO_INPUT,
        TestContextObject::new(5),
        ProgramResult::Err(EbpfError::ExceededMaxInstructions),
    );
}

#[test]
fn test_tight_infinite_loop_unconditional() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        ja -1
        exit",
        NO_INPUT,
        TestContextObject::new(5),
        ProgramResult::Err(EbpfError::ExceededMaxInstructions),
    );
}

#[test]
fn test_tight_infinite_recursion() {
    let max_call_depth = Config::default().max_call_depth as u64;
    for (budget, expected) in [
        (6, EbpfError::ExceededMaxInstructions),
        (3 * max_call_depth - 1, EbpfError::ExceededMaxInstructions),
        (3 * max_call_depth, EbpfError::CallDepthExceeded),
    ] {
        test_interpreter_and_jit_asm!(
            "
            entrypoint:
            add64 r10, 0
            mov64 r3, 0x41414141
            call entrypoint
            exit",
            NO_INPUT,
            TestContextObject::new(budget),
            ProgramResult::Err(expected),
        );
    }
}

#[test]
fn test_entrypoint_not_first() {
    test_interpreter_and_jit_asm!(
        "
        function_foo:
        mov64 r0, 3
        exit
        entrypoint:
        call function_foo
        add64 r0, 4
        exit",
        NO_INPUT,
        TestContextObject::new(5),
        ProgramResult::Ok(7),
    );
}

#[test]
fn test_nested_calls_return() {
    // Calls return to the right place and leave the meter and the call depth as they were. There
    // are more nested calls than the depth allows, were it not for the returns.
    test_interpreter_and_jit_asm!(
        "
        mov64 r6, 40
        loop:
        call function_foo
        sub64 r6, 1
        jne r6, 0, loop
        mov64 r0, 7
        exit
        function_foo:
        call function_bar
        exit
        function_bar:
        exit",
        NO_INPUT,
        TestContextObject::new(243),
        ProgramResult::Ok(7),
    );
}

#[test]
fn test_tight_infinite_recursion_callx() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov64 r8, 0x1
        lsh64 r8, 0x20
        or64 r8, 0x30
        call function_foo
        exit
        function_foo:
        add64 r10, 0
        callx r8
        exit",
        NO_INPUT,
        TestContextObject::new(9),
        ProgramResult::Err(EbpfError::ExceededMaxInstructions),
    );
}

#[test]
fn test_instruction_count_syscall() {
    let input = [72, 101, 108, 108, 111];
    test_syscall_asm!(
        "
        add64 r10, 0
        mov64 r2, 0x5
        syscall bpf_syscall_string
        mov64 r0, 0x0
        exit",
        &raw const input,
        (
            "bpf_syscall_string" => syscalls::SyscallString,
        ),
        TestContextObject::new(5),
        ProgramResult::Ok(0),
    );
}

#[test]
fn test_err_instruction_count_syscall_capped() {
    let input = [72, 101, 108, 108, 111];
    test_syscall_asm!(
        "
        add64 r10, 0
        mov64 r2, 0x5
        syscall bpf_syscall_string
        mov64 r0, 0x0
        exit",
        &raw const input,
        (
            "bpf_syscall_string" => syscalls::SyscallString,
        ),
        TestContextObject::new(4),
        ProgramResult::Err(EbpfError::ExceededMaxInstructions),
    );
}

#[test]
fn test_err_non_terminate_capped() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov64 r6, 0x0
        mov64 r1, 0x0
        mov64 r2, 0x0
        mov64 r3, 0x0
        mov64 r4, 0x0
        mov64 r5, r6
        add64 r6, 0x1
        ja -0x8
        exit",
        NO_INPUT,
        TestContextObject::new(8),
        ProgramResult::Err(EbpfError::ExceededMaxInstructions),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov64 r6, 0x0
        mov64 r1, 0x0
        mov64 r2, 0x0
        mov64 r3, 0x0
        mov64 r4, 0x0
        mov64 r5, r6
        add64 r6, 0x1
        ja -0x8
        exit",
        NO_INPUT,
        TestContextObject::new(1001),
        ProgramResult::Err(EbpfError::ExceededMaxInstructions),
    );
}

#[test]
fn test_err_capped_before_exception() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov64 r1, 0x0
        mov64 r2, 0x0
        div64 r1, r2
        mov64 r0, 0x0
        exit",
        NO_INPUT,
        TestContextObject::new(3),
        ProgramResult::Err(EbpfError::ExceededMaxInstructions),
    );

    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov64 r1, 0x0
        mov64 r2, 0x0
        callx r2
        mov64 r0, 0x0
        exit",
        NO_INPUT,
        TestContextObject::new(3),
        ProgramResult::Err(EbpfError::ExceededMaxInstructions),
    );
}

#[test]
fn test_err_exit_capped() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov64 r0, 0x1
        lsh64 r0, 0x20
        or64 r0, 0x30
        callx r0
        exit
        function_foo:
        add64 r10, 0
        exit
        ",
        NO_INPUT,
        TestContextObject::new(7),
        ProgramResult::Err(EbpfError::ExceededMaxInstructions),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov64 r0, 0x1
        lsh64 r0, 0x20
        or64 r0, 0x30
        callx r0
        exit
        function_foo:
        add64 r10, 0
        mov r0, r0
        exit
        ",
        NO_INPUT,
        TestContextObject::new(8),
        ProgramResult::Err(EbpfError::ExceededMaxInstructions),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        call function_foo
        exit
        function_foo:
        add64 r10, 0
        mov r0, r0
        exit
        ",
        NO_INPUT,
        TestContextObject::new(5),
        ProgramResult::Err(EbpfError::ExceededMaxInstructions),
    );
}

#[test]
fn test_far_jumps() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        call function_c
        exit
        function_a:
        add64 r10, 0
        exit
        function_b:
        .fill 1024, 0x0F
        exit
        function_c:
        add64 r10, 0
        mov64 r8, 0x1
        lsh64 r8, 0x20
        or64 r8, 0x18
        callx r8
        exit",
        NO_INPUT,
        TestContextObject::new(11),
        ProgramResult::Ok(0),
    );
}

// Symbols and Relocation

#[test]
fn test_err_call_unresolved() {
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V0..=SBPFVersion::V0,
        ..Config::default()
    };
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r1, 1
        mov r2, 2
        mov r3, 3
        mov r4, 4
        mov r5, 5
        syscall Unresolved
        mov64 r0, 0x0
        exit",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(7),
        ProgramResult::Err(EbpfError::UnsupportedInstruction),
    );
}

#[test]
fn test_err_call_imm_outside_text() {
    let loader = Arc::new(BuiltinProgram::new_loader(Config {
        enabled_sbpf_versions: SBPFVersion::V3..=SBPFVersion::V4,
        // Not resolving the call takes precedence over the call depth.
        max_call_depth: 1,
        ..Config::default()
    }));
    for sbpf_version in [SBPFVersion::V3, SBPFVersion::V4] {
        for imm in [2i32, -3] {
            let mut prog = [
                [0xb7, 0x00, 0, 0, 0, 0, 0, 0], // mov64 r0, 0
                [0x85, 0x10, 0, 0, 0, 0, 0, 0], // call imm
                [0x95, 0, 0, 0, 0, 0, 0, 0],    // exit
            ]
            .concat();
            LittleEndian::write_i32(&mut prog[12..], imm);
            #[allow(unused_mut)]
            let mut executable = Executable::<TestContextObject>::from_text_bytes(
                &prog,
                loader.clone(),
                sbpf_version,
                FunctionRegistry::default(),
            )
            .unwrap();
            test_interpreter_and_jit!(
                executable,
                NO_INPUT,
                TestContextObject::new(2),
                ProgramResult::Err(EbpfError::UnsupportedInstruction),
            );
        }
    }
}

#[test]
fn test_syscall_static() {
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V3..=SBPFVersion::V4,
        ..Config::default()
    };
    test_interpreter_and_jit_elf!(
        "tests/elfs/syscall_static.so",
        config,
        NO_INPUT,
        (
            "log" => syscalls::SyscallString,
        ),
        TestContextObject::new(5),
        ProgramResult::Ok(0),
    );
}

#[test]
fn test_syscall_reloc_64_32() {
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V0..=SBPFVersion::V0,
        ..Config::default()
    };
    test_interpreter_and_jit_elf!(
        "tests/elfs/syscall_reloc_64_32_sbpfv0.so",
        config,
        NO_INPUT,
        (
            "log" => syscalls::SyscallString,
        ),
        TestContextObject::new(5),
        ProgramResult::Ok(0),
    );
}

#[test]
fn test_reloc_64_64_sbpfv0() {
    // Tests the correctness of R_BPF_64_64 relocations. The program returns the
    // address of the entrypoint.
    //   [ 1] .text             PROGBITS        0000000000000120 000120 000018 00  AX  0   0  8
    test_interpreter_and_jit_elf!(
        "tests/elfs/reloc_64_64_sbpfv0.so",
        NO_INPUT,
        (),
        TestContextObject::new(2),
        ProgramResult::Ok(ebpf::MM_BYTECODE_START + 0x120),
    );
}

#[test]
fn test_reloc_64_64() {
    // Tests the correctness of link-time R_BPF_64_64 relocations. The program returns the
    // address of the entrypoint.
    test_interpreter_and_jit_elf!(
        "tests/elfs/reloc_64_64.so",
        NO_INPUT,
        (),
        TestContextObject::new(2),
        ProgramResult::Ok(ebpf::MM_BYTECODE_START),
    );
}

#[test]
fn test_reloc_64_relative_sbpfv0() {
    // Tests the correctness of R_BPF_64_RELATIVE relocations. The program
    // returns the address of the first .rodata byte.
    //   [ 1] .text             PROGBITS        0000000000000120 000120 000018 00  AX  0   0  8
    //   [ 2] .rodata           PROGBITS        0000000000000138 000138 00000a 01 AMS  0   0  1
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V0..=SBPFVersion::V0,
        ..Config::default()
    };
    test_interpreter_and_jit_elf!(
        "tests/elfs/reloc_64_relative_sbpfv0.so",
        config,
        NO_INPUT,
        (),
        TestContextObject::new(2),
        ProgramResult::Ok(ebpf::MM_BYTECODE_START + 0x138),
    );
}

#[test]
fn test_reloc_64_relative() {
    // Tests the correctness of link-time R_BPF_64_RELATIVE relocations. The program
    // returns the address of the first .rodata byte.
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V3..=SBPFVersion::V4,
        ..Config::default()
    };
    test_interpreter_and_jit_elf!(
        "tests/elfs/reloc_64_relative.so",
        config,
        NO_INPUT,
        (),
        TestContextObject::new(2),
        ProgramResult::Ok(ebpf::MM_RODATA_START),
    );
}

#[test]
fn test_reloc_64_relative_data() {
    //  Tests the correctness of link-time R_BPF_64_RELATIVE relocations in sections other
    // than .text. The program returns the address of the first .rodata byte.
    // [ 1] .text             PROGBITS        0000000000000000 000190 000020 00  AX  0   0  8
    // [ 2] .rodata           PROGBITS        0000000100000000 0001b0 000030 00 WAMS 0   0  8
    //
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V3..=SBPFVersion::V4,
        ..Config::default()
    };
    test_interpreter_and_jit_elf!(
        "tests/elfs/reloc_64_relative_data.so",
        config,
        NO_INPUT,
        (),
        TestContextObject::new(3),
        ProgramResult::Ok(ebpf::MM_RODATA_START),
    );
}

#[test]
fn test_reloc_64_relative_data_sbpfv0() {
    // Before https://github.com/solana-labs/llvm-project/pull/35, we used to
    // generate invalid R_BPF_64_RELATIVE relocations in sections other than
    // .text.
    //
    // This test checks that the old behaviour is maintained for backwards
    // compatibility when dealing with non-sbpfv3 files. See also Elf::relocate().
    //
    // The program returns the address of the first .rodata byte.
    // [ 1] .text             PROGBITS        0000000000000120 000120 000020 00  AX  0   0  8
    // [ 2] .rodata           PROGBITS        0000000000000140 000140 000019 01 AMS  0   0  1
    //
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V0..=SBPFVersion::V0,
        ..Config::default()
    };
    test_interpreter_and_jit_elf!(
        "tests/elfs/reloc_64_relative_data_sbpfv0.so",
        config,
        NO_INPUT,
        (),
        TestContextObject::new(3),
        ProgramResult::Ok(ebpf::MM_BYTECODE_START + 0x140),
    );
}

#[test]
fn test_load_elf_rodata_sbpfv0() {
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V0..=SBPFVersion::V0,
        optimize_rodata: false,
        ..Config::default()
    };
    test_interpreter_and_jit_elf!(
        "tests/elfs/rodata_section_sbpfv0.so",
        config,
        NO_INPUT,
        (),
        TestContextObject::new(3),
        ProgramResult::Ok(42),
    );
}

#[test]
fn test_load_elf_rodata() {
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V3..=SBPFVersion::V4,
        optimize_rodata: false,
        ..Config::default()
    };
    test_interpreter_and_jit_elf!(
        "tests/elfs/rodata_section.so",
        config,
        NO_INPUT,
        (),
        TestContextObject::new(3),
        ProgramResult::Ok(42),
    );
}

#[test]
fn test_struct_func_pointer_sbpfv0() {
    // This tests checks that a struct field adjacent to another field
    // which is a relocatable function pointer is not overwritten when
    // the function pointer is relocated at load time.
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V0..=SBPFVersion::V0,
        ..Config::default()
    };
    test_interpreter_and_jit_elf!(
        "tests/elfs/struct_func_pointer_sbpfv0.so",
        config,
        NO_INPUT,
        (),
        TestContextObject::new(2),
        ProgramResult::Ok(0x102030405060708),
    );
}

#[test]
fn test_strict_header() {
    test_interpreter_and_jit_elf!(
        "tests/elfs/strict_header.so",
        NO_INPUT,
        (),
        TestContextObject::new(5),
        ProgramResult::Ok(42),
    );
}

#[test]
fn test_struct_func_pointer() {
    // This tests checks that a struct field adjacent to another field
    // which is a relocatable function pointer is not overwritten when
    // the function pointer is relocated at load time.
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V3..=SBPFVersion::V4,
        ..Config::default()
    };
    test_interpreter_and_jit_elf!(
        "tests/elfs/struct_func_pointer.so",
        config,
        NO_INPUT,
        (),
        TestContextObject::new(2),
        ProgramResult::Ok(0x102030405060708),
    );
}

// Programs

#[test]
fn test_lmul_loop() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r0, 0x7
        add r1, 0xa
        lsh r1, 0x20
        rsh r1, 0x20
        jeq r1, 0x0, +4
        mov r0, 0x7
        mul r0, 0x7
        add r1, -1
        jne r1, 0x0, -3
        exit",
        NO_INPUT,
        TestContextObject::new(38),
        ProgramResult::Ok(0x75db9c97),
    );
}

#[test]
fn test_prime() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r1, 67
        mov r0, 0x1
        mov r2, 0x2
        jgt r1, 0x2, +4
        ja +10
        add r2, 0x1
        mov r0, 0x1
        jge r2, r1, +7
        mov r3, r1
        div r3, r2
        mul r3, r2
        mov r4, r1
        sub r4, r3
        mov r0, 0x0
        jne r4, 0x0, -10
        exit",
        NO_INPUT,
        TestContextObject::new(656),
        ProgramResult::Ok(0x1),
    );
}

#[test]
fn test_subnet() {
    let input = [
        0x00, 0x00, 0xc0, 0x9f, 0xa0, 0x97, 0x00, 0xa0, //
        0xcc, 0x3b, 0xbf, 0xfa, 0x08, 0x00, 0x45, 0x10, //
        0x00, 0x3c, 0x46, 0x3c, 0x40, 0x00, 0x40, 0x06, //
        0x73, 0x1c, 0xc0, 0xa8, 0x01, 0x02, 0xc0, 0xa8, //
        0x01, 0x01, 0x06, 0x0e, 0x00, 0x17, 0x99, 0xc5, //
        0xa0, 0xec, 0x00, 0x00, 0x00, 0x00, 0xa0, 0x02, //
        0x7d, 0x78, 0xe0, 0xa3, 0x00, 0x00, 0x02, 0x04, //
        0x05, 0xb4, 0x04, 0x02, 0x08, 0x0a, 0x00, 0x9c, //
        0x27, 0x24, 0x00, 0x00, 0x00, 0x00, 0x01, 0x03, //
        0x03, 0x00, //
    ];
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r2, 0xe
        ldxh r3, [r1+12]
        jne r3, 0x81, +2
        mov r2, 0x12
        ldxh r3, [r1+16]
        and r3, 0xffff
        jne r3, 0x8, +5
        add r1, r2
        mov r0, 0x1
        ldxw r1, [r1+16]
        and r1, 0xffffff
        jeq r1, 0x1a8c0, +1
        mov r0, 0x0
        exit",
        &raw const input,
        TestContextObject::new(12),
        ProgramResult::Ok(0x1),
    );
}

#[test]
fn test_tcp_port80_match() {
    let input = [
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x00, 0x06, //
        0x07, 0x08, 0x09, 0x0a, 0x08, 0x00, 0x45, 0x00, //
        0x00, 0x56, 0x00, 0x01, 0x00, 0x00, 0x40, 0x06, //
        0xf9, 0x4d, 0xc0, 0xa8, 0x00, 0x01, 0xc0, 0xa8, //
        0x00, 0x02, 0x27, 0x10, 0x00, 0x50, 0x00, 0x00, //
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x50, 0x02, //
        0x20, 0x00, 0xc5, 0x18, 0x00, 0x00, 0x44, 0x44, //
        0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, //
        0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, //
        0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, //
        0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, //
        0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, //
        0x44, 0x44, 0x44, 0x44, //
    ];
    test_interpreter_and_jit_asm!(
        PROG_TCP_PORT_80,
        &raw const input,
        TestContextObject::new(18),
        ProgramResult::Ok(0x1),
    );
}

#[test]
fn test_tcp_port80_nomatch() {
    let input = [
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x00, 0x06, //
        0x07, 0x08, 0x09, 0x0a, 0x08, 0x00, 0x45, 0x00, //
        0x00, 0x56, 0x00, 0x01, 0x00, 0x00, 0x40, 0x06, //
        0xf9, 0x4d, 0xc0, 0xa8, 0x00, 0x01, 0xc0, 0xa8, //
        0x00, 0x02, 0x00, 0x16, 0x27, 0x10, 0x00, 0x00, //
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x51, 0x02, //
        0x20, 0x00, 0xc5, 0x18, 0x00, 0x00, 0x44, 0x44, //
        0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, //
        0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, //
        0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, //
        0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, //
        0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, //
        0x44, 0x44, 0x44, 0x44, //
    ];
    test_interpreter_and_jit_asm!(
        PROG_TCP_PORT_80,
        &raw const input,
        TestContextObject::new(19),
        ProgramResult::Ok(0x0),
    );
}

#[test]
fn test_tcp_port80_nomatch_ethertype() {
    let input = [
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x00, 0x06, //
        0x07, 0x08, 0x09, 0x0a, 0x08, 0x01, 0x45, 0x00, //
        0x00, 0x56, 0x00, 0x01, 0x00, 0x00, 0x40, 0x06, //
        0xf9, 0x4d, 0xc0, 0xa8, 0x00, 0x01, 0xc0, 0xa8, //
        0x00, 0x02, 0x27, 0x10, 0x00, 0x50, 0x00, 0x00, //
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x50, 0x02, //
        0x20, 0x00, 0xc5, 0x18, 0x00, 0x00, 0x44, 0x44, //
        0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, //
        0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, //
        0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, //
        0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, //
        0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, //
        0x44, 0x44, 0x44, 0x44, //
    ];
    test_interpreter_and_jit_asm!(
        PROG_TCP_PORT_80,
        &raw const input,
        TestContextObject::new(8),
        ProgramResult::Ok(0x0),
    );
}

#[test]
fn test_tcp_port80_nomatch_proto() {
    let input = [
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x00, 0x06, //
        0x07, 0x08, 0x09, 0x0a, 0x08, 0x00, 0x45, 0x00, //
        0x00, 0x56, 0x00, 0x01, 0x00, 0x00, 0x40, 0x11, //
        0xf9, 0x4d, 0xc0, 0xa8, 0x00, 0x01, 0xc0, 0xa8, //
        0x00, 0x02, 0x27, 0x10, 0x00, 0x50, 0x00, 0x00, //
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x50, 0x02, //
        0x20, 0x00, 0xc5, 0x18, 0x00, 0x00, 0x44, 0x44, //
        0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, //
        0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, //
        0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, //
        0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, //
        0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, 0x44, //
        0x44, 0x44, 0x44, 0x44, //
    ];
    test_interpreter_and_jit_asm!(
        PROG_TCP_PORT_80,
        &raw const input,
        TestContextObject::new(10),
        ProgramResult::Ok(0x0),
    );
}

#[test]
fn test_tcp_sack_match() {
    test_interpreter_and_jit_asm!(
        TCP_SACK_ASM,
        &raw const TCP_SACK_MATCH,
        TestContextObject::new(80),
        ProgramResult::Ok(0x1),
    );
}

#[test]
fn test_tcp_sack_nomatch() {
    test_interpreter_and_jit_asm!(
        TCP_SACK_ASM,
        &raw const TCP_SACK_NOMATCH,
        TestContextObject::new(56),
        ProgramResult::Ok(0x0),
    );
}

// Fuzzy

#[cfg(all(feature = "jit", not(target_os = "windows"), target_arch = "x86_64"))]
fn execute_generated_program(prog: &[u8]) -> bool {
    use solana_sbpf::vm::{CallFrame, ExecutionMode};

    let max_instruction_count = 1024;
    let mem_size = 1024 * 1024;
    let executable = Executable::<TestContextObject>::from_text_bytes(
        prog,
        Arc::new(BuiltinProgram::new_loader(Config::default())),
        SBPFVersion::V4,
        FunctionRegistry::default(),
    );
    let Ok(executable) = executable else {
        return false;
    };
    if executable.verify::<RequisiteVerifier>().is_err() || executable.jit_compile().is_err() {
        return false;
    }
    let (instruction_count_interpreter, trace_interpreter, result_interpreter) = {
        let mut mem = vec![0u8; mem_size];
        let mut context_object = TestContextObject::new(max_instruction_count);
        let mem_region = MemoryRegion::new(&raw mut mem[..], ebpf::MM_INPUT_START);
        let mut call_frames = vec![CallFrame::default(); Config::default().max_call_depth];
        create_vm!(
            vm,
            &executable,
            &mut context_object,
            stack,
            heap,
            vec![mem_region],
            None
        );
        let (instruction_count_interpreter, result_interpreter) = vm.execute_program(
            &executable,
            &mut ExecutionMode::Interpreted,
            &mut call_frames,
        );
        let trace_interpreter = vm.register_trace.clone();
        (
            instruction_count_interpreter,
            trace_interpreter,
            result_interpreter,
        )
    };
    let mut mem = vec![0u8; mem_size];
    let mut context_object = TestContextObject::new(max_instruction_count);
    let mem_region = MemoryRegion::new(&raw mut mem[..], ebpf::MM_INPUT_START);
    create_vm!(
        vm,
        &executable,
        &mut context_object,
        stack,
        heap,
        vec![mem_region],
        None
    );
    let (instruction_count_jit, result_jit) =
        vm.execute_program(&executable, &mut ExecutionMode::Jit, &mut []);
    let trace_jit = &vm.register_trace;
    if format!("{result_interpreter:?}") != format!("{result_jit:?}")
        || !compare_register_trace(&trace_interpreter, trace_jit)
    {
        let analysis =
            solana_sbpf::static_analysis::Analysis::from_executable(&executable).unwrap();
        println!("result_interpreter={result_interpreter:?}");
        println!("result_jit={result_jit:?}");
        let stdout = std::io::stdout();
        analysis
            .disassemble_register_trace(&mut stdout.lock(), &trace_interpreter)
            .unwrap();
        analysis
            .disassemble_register_trace(&mut stdout.lock(), trace_jit)
            .unwrap();
        panic!();
    }
    if executable.get_config().enable_instruction_meter {
        assert_eq!(instruction_count_interpreter, instruction_count_jit);
    }
    true
}

#[cfg(all(not(windows), target_arch = "x86_64"))]
#[test]
fn test_total_chaos() {
    let instruction_count = 6;
    let iteration_count = 1000000;
    let mut program = vec![0; instruction_count * ebpf::INSN_SIZE];
    program[ebpf::INSN_SIZE * (instruction_count - 1)..ebpf::INSN_SIZE * instruction_count]
        .copy_from_slice(&[ebpf::EXIT, 0, 0, 0, 0, 0, 0, 0]);
    let seed = 0xC2DB2F8F282284A0;
    let mut prng = SmallRng::seed_from_u64(seed);
    for _ in 0..iteration_count {
        prng.fill_bytes(&mut program[0..ebpf::INSN_SIZE * (instruction_count - 1)]);
        execute_generated_program(&program);
    }
    for _ in 0..iteration_count {
        prng.fill_bytes(&mut program[0..ebpf::INSN_SIZE * (instruction_count - 1)]);
        for index in (0..program.len()).step_by(ebpf::INSN_SIZE) {
            program[index + 0x1] &= 0x77;
            program[index + 0x2] &= 0x00;
            program[index + 0x3] &= 0x77;
            program[index + 0x4] &= 0x00;
            program[index + 0x5] &= 0x77;
            program[index + 0x6] &= 0x77;
            program[index + 0x7] &= 0x77;
        }
        execute_generated_program(&program);
    }
}

#[test]
fn test_call_imm_does_not_dispatch_syscalls() {
    test_syscall_asm!(
        "
        add64 r10, 0
        call function_foo
        exit
        syscall bpf_syscall_string
        exit
        function_foo:
        add64 r10, 0
        mov r0, 42
        exit",
        NO_INPUT,
        (
            "bpf_syscall_string" => syscalls::SyscallString,
        ),
        TestContextObject::new(6),
        ProgramResult::Ok(42),
    );
}

#[test]
fn test_callx_unsupported_instruction_and_exceeded_max_instructions() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        sub32 r7, r1
        add64 r5, -8
        add64 r7, 0
        callx r5
        exit",
        NO_INPUT,
        TestContextObject::new(5),
        ProgramResult::Err(EbpfError::CallOutsideTextSegment),
    );
}

#[test]
fn test_capped_after_callx() {
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov64 r0, 0x0
        mov64 r8, 0x1
        lsh64 r8, 0x20
        or64 r8, 0x38
        callx r8
        exit
        function_foo:
        add64 r10, 0
        mov64 r0, 0x2A
        exit",
        NO_INPUT,
        TestContextObject::new(6),
        ProgramResult::Err(EbpfError::ExceededMaxInstructions),
    );
}

// SBPFv0 only [DEPRECATED]

#[test]
fn test_err_fixed_stack_out_of_bound() {
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V0..=SBPFVersion::V0,
        max_call_depth: 3,
        ..Config::default()
    };
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        stb [r10-0x4000], 0
        exit",
        config,
        NO_INPUT,
        TestContextObject::new(2),
        ProgramResult::Err(EbpfError::AccessViolation(
            AccessType::Store,
            0x1FFFFD000,
            1,
            "unallocated"
        )),
    );
}

#[test]
fn test_execution_overrun() {
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V0..=SBPFVersion::V0,
        ..Config::default()
    };
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        add r1, 0",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(3),
        ProgramResult::Err(EbpfError::ExecutionOverrun),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        add r1, 0",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(2),
        ProgramResult::Err(EbpfError::ExceededMaxInstructions),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        add r1, 0",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(1),
        ProgramResult::Err(EbpfError::ExceededMaxInstructions),
    );
}

#[test]
fn test_mov32_reg_truncating() {
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V0..=SBPFVersion::V0,
        ..Config::default()
    };
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov64 r1, -1
        mov32 r0, r1
        exit",
        config,
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Ok(0xffffffff),
    );
}

#[test]
fn test_err_call_imm_unknown_src() {
    // The verifier accepts any source register up to 10. The meter is checked before the error.
    let mut prog = [0; 32];
    prog[0] = ebpf::MOV64_IMM;
    prog[8] = ebpf::MOV64_IMM;
    prog[16] = ebpf::CALL_IMM;
    prog[17] = 5 << 4;
    LittleEndian::write_u32(&mut prog[20..], 100);
    prog[24] = ebpf::EXIT;
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V3..=SBPFVersion::V3,
        ..Config::default()
    };
    let loader = Arc::new(BuiltinProgram::new_loader(config));
    for (budget, expected) in [
        (2, EbpfError::ExceededMaxInstructions),
        (3, EbpfError::UnsupportedInstruction),
    ] {
        #[allow(unused_mut)]
        let mut executable = Executable::<TestContextObject>::from_text_bytes(
            &prog,
            loader.clone(),
            SBPFVersion::V3,
            FunctionRegistry::default(),
        )
        .unwrap();
        test_interpreter_and_jit!(
            executable,
            NO_INPUT,
            TestContextObject::new(budget),
            ProgramResult::Err(expected),
        );
    }
}

#[test]
fn test_lddw() {
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V0..=SBPFVersion::V0,
        ..Config::default()
    };
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        lddw r0, 0x1122334455667788",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(3),
        ProgramResult::Err(EbpfError::ExecutionOverrun),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        lddw r0, 0x1122334455667788
        exit",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(3),
        ProgramResult::Ok(0x1122334455667788),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        lddw r0, 0x0000000080000000
        exit",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(3),
        ProgramResult::Ok(0x80000000),
    );
    // Neither half is sign extended.
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        lddw r0, 0x80000000ffffffff
        exit",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(3),
        ProgramResult::Ok(0x80000000ffffffff),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r0, 0
        mov r1, 0
        mov r2, 0
        lddw r0, 0x1
        ja +2
        lddw r1, 0x1
        lddw r2, 0x1
        add r1, r2
        add r0, r1
        exit
        ",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(10),
        ProgramResult::Ok(0x2),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov64 r8, 0x1
        lsh64 r8, 0x20
        or64 r8, 0x30
        callx r8
        lddw r0, 0x1122334455667788
        exit",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(5),
        ProgramResult::Err(EbpfError::ExceededMaxInstructions),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov64 r8, 0x1
        lsh64 r8, 0x20
        or64 r8, 0x30
        callx r8
        lddw r0, 0x1122334455667788
        exit",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(6),
        ProgramResult::Err(EbpfError::UnsupportedInstruction),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov64 r1, 0x1
        lsh64 r1, 0x20
        or64 r1, 0x40
        callx r1
        mov r0, r0
        mov r0, r0
        lddw r0, 0x1122334455667788
        exit
        ",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(6),
        ProgramResult::Err(EbpfError::UnsupportedInstruction),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        lddw r1, 0x100000040
        callx r1
        mov r0, r0
        mov r0, r0
        exit
        lddw r0, 0x1122334455667788
        exit
        ",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Err(EbpfError::UnsupportedInstruction),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r0, 0
        lddw r1, 0x1
        mov r2, 0
        exit
        ",
        config,
        NO_INPUT,
        TestContextObject::new(3),
        ProgramResult::Err(EbpfError::ExceededMaxInstructions),
    );
}

#[test]
fn test_lddw_call_target() {
    test_interpreter_and_jit_asm!(
        "
        call function_foo
        exit
        function_foo:
        lddw r0, 0x100000002
        exit",
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Ok(0x100000002),
    );
}

#[test]
fn test_err_callx_into_lddw() {
    // The second half of `lddw` is at pc 5.
    test_interpreter_and_jit_asm!(
        "
        mov64 r8, 0x1
        lsh64 r8, 0x20
        or64 r8, 0x28
        callx r8
        lddw r0, 0x1
        exit",
        NO_INPUT,
        TestContextObject::new(5),
        ProgramResult::Err(EbpfError::UnsupportedInstruction),
    );
}

#[test]
fn test_neg() {
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V0..=SBPFVersion::V0,
        ..Config::default()
    };
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov32 r0, 2
        neg32 r0
        exit",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Ok(0xfffffffe),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r0, 2
        neg r0
        exit",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Ok(0xfffffffffffffffe),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov32 r0, 3
        sub32 r0, 1
        exit",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Ok(2),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r0, 3
        sub r0, 1
        exit",
        config,
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Ok(2),
    );
}

#[test]
fn test_callx_imm() {
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V0..=SBPFVersion::V0,
        ..Config::default()
    };
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov64 r0, 0x0
        mov64 r8, 0x1
        lsh64 r8, 0x20
        or64 r8, 0x38
        callx r8
        exit
        function_foo:
        mov64 r0, 0x2A
        exit",
        config,
        NO_INPUT,
        TestContextObject::new(9),
        ProgramResult::Ok(42),
    );
}

#[test]
fn test_mul() {
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V0..=SBPFVersion::V0,
        ..Config::default()
    };
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r0, 3
        mul32 r0, 4
        exit",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Ok(0xc),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r0, 3
        mov r1, 4
        mul32 r0, r1
        exit",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(5),
        ProgramResult::Ok(0xc),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r0, 0x40000001
        mov r1, 4
        mul32 r0, r1
        exit",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(5),
        ProgramResult::Ok(0x4),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r0, 0x40000001
        mul r0, 4
        exit",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Ok(0x100000004),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r0, 0x40000001
        mov r1, 4
        mul r0, r1
        exit",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(5),
        ProgramResult::Ok(0x100000004),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r0, -1
        mul32 r0, 4
        exit",
        config,
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Ok(0xFFFFFFFFFFFFFFFC),
    );
}

#[test]
fn test_div() {
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V0..=SBPFVersion::V0,
        ..Config::default()
    };
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r0, 12
        lddw r1, 0x100000004
        div32 r0, r1
        exit",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(5),
        ProgramResult::Ok(0x3),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        lddw r0, 0x10000000c
        div32 r0, 4
        exit",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Ok(0x3),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        lddw r0, 0x10000000c
        mov r1, 4
        div32 r0, r1
        exit",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(5),
        ProgramResult::Ok(0x3),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r0, 0xc
        lsh r0, 32
        div r0, 4
        exit",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(5),
        ProgramResult::Ok(0x300000000),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov r0, 0xc
        lsh r0, 32
        mov r1, 4
        div r0, r1
        exit",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(6),
        ProgramResult::Ok(0x300000000),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov32 r0, 1
        mov32 r1, 0
        div r0, r1
        exit",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Err(EbpfError::DivideByZero),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov32 r0, 1
        mov32 r1, 0
        div32 r0, r1
        exit",
        config,
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Err(EbpfError::DivideByZero),
    );
}

#[test]
fn test_mod() {
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V0..=SBPFVersion::V0,
        ..Config::default()
    };
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov32 r0, 5748
        mod32 r0, 92
        mov32 r1, 13
        mod32 r0, r1
        exit",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(6),
        ProgramResult::Ok(0x5),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        lddw r0, 0x100000003
        mod32 r0, 3
        exit",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Ok(0x0),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov32 r0, -1316649930
        lsh r0, 32
        or r0, 0x100dc5c8
        mov32 r1, 0xdde263e
        lsh r1, 32
        or r1, 0x3cbef7f3
        mod r0, r1
        mod r0, 0x658f1778
        exit",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(10),
        ProgramResult::Ok(0x30ba5a04),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov32 r0, 1
        mov32 r1, 0
        mod r0, r1
        exit",
        config.clone(),
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Err(EbpfError::DivideByZero),
    );
    test_interpreter_and_jit_asm!(
        "
        add64 r10, 0
        mov32 r0, 1
        mov32 r1, 0
        mod32 r0, r1
        exit",
        config,
        NO_INPUT,
        TestContextObject::new(4),
        ProgramResult::Err(EbpfError::DivideByZero),
    );
}

#[test]
fn test_div_mod_full_width() {
    // Both operands need all 64 bits: the divisor's low 32 bits are zero.
    test_interpreter_and_jit_asm!(
        "
        mov64 r0, 1
        lsh64 r0, 40
        mov64 r1, 1
        lsh64 r1, 33
        div64 r0, r1
        exit",
        NO_INPUT,
        TestContextObject::new(6),
        ProgramResult::Ok(128),
    );
    test_interpreter_and_jit_asm!(
        "
        mov64 r0, 1
        lsh64 r0, 40
        add64 r0, 5
        mov64 r1, 1
        lsh64 r1, 33
        mod64 r0, r1
        exit",
        NO_INPUT,
        TestContextObject::new(7),
        ProgramResult::Ok(5),
    );
}

#[test]
fn test_div_imm_extension() {
    // The immediate is sign extended for 64-bit and truncated for 32-bit division.
    test_interpreter_and_jit_asm!(
        "
        mov64 r0, -1
        div64 r0, -1
        mov64 r1, -1
        div32 r1, -1
        add64 r0, r1
        exit",
        NO_INPUT,
        TestContextObject::new(6),
        ProgramResult::Ok(2),
    );
    // Remainders, and a destination other than the registers `div` uses.
    test_interpreter_and_jit_asm!(
        "
        mov64 r0, -1
        mod64 r0, -2
        mov64 r1, -1
        mod32 r1, -2
        mov64 r2, 7
        div64 r2, 2
        add64 r0, r1
        add64 r0, r2
        exit",
        NO_INPUT,
        TestContextObject::new(9),
        ProgramResult::Ok(5),
    );
}

#[test]
fn test_err_div_mod_by_zero_reg() {
    // Only the low 32 bits of the divisor are zero.
    for op in ["div32", "mod32"] {
        test_interpreter_and_jit_asm!(
            &format!(
                "
                mov64 r0, 5
                mov64 r1, 1
                lsh64 r1, 32
                {} r0, r1
                exit",
                op
            ),
            NO_INPUT,
            TestContextObject::new(4),
            ProgramResult::Err(EbpfError::DivideByZero),
        );
    }
}

#[test]
fn test_symbol_relocation() {
    // No relocation is necessary in SBFPv3
    let input = [72, 101, 108, 108, 111];
    test_syscall_asm!(
        "
        add64 r10, 64
        mov64 r1, r10
        add64 r1, -0x1
        mov64 r2, 0x1
        syscall bpf_syscall_string
        mov64 r0, 0x0
        exit",
        &raw const input,
        (
            "bpf_syscall_string" => syscalls::SyscallString,
        ),
        TestContextObject::new(7),
        ProgramResult::Ok(0),
    );
}

#[test]
fn test_stack_gaps() {
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V0..=SBPFVersion::V0,
        ..Config::default()
    };
    // V0 has stack gaps, so storing to [r10 + 8] should raise an error.
    test_interpreter_and_jit_asm!(
        "
        stw [r10 + 8], 77
        call function_foo
        exit
        function_foo:
        ldxdw r0, [r10 - 4088]
        exit",
        config,
        NO_INPUT,
        TestContextObject::new(1),
        ProgramResult::Err(EbpfError::StackAccessViolation(
            AccessType::Store,
            0x200001008,
            4,
            1
        )),
    );

    // The frame of the callee is a frame and a gap past the frame of the caller, so the stack of
    // the caller is not where it would be without the gaps.
    for (enable_stack_frame_gaps, budget, expected) in [
        (
            true,
            3,
            ProgramResult::Err(EbpfError::StackAccessViolation(
                AccessType::Load,
                0x200001ff8,
                8,
                1,
            )),
        ),
        (false, 5, ProgramResult::Ok(77)),
    ] {
        let config = Config {
            enabled_sbpf_versions: SBPFVersion::V0..=SBPFVersion::V0,
            enable_stack_frame_gaps,
            ..Config::default()
        };
        test_interpreter_and_jit_asm!(
            "
            stw [r10 - 8], 77
            call function_foo
            exit
            function_foo:
            ldxdw r0, [r10 - 4104]
            exit",
            config,
            NO_INPUT,
            TestContextObject::new(budget),
            expected,
        );
    }

    // V3 and V4 do not have stack gaps, so we should see 77 as the return.
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V3..=SBPFVersion::V4,
        ..Config::default()
    };
    test_interpreter_and_jit_asm!(
        "
        stw [r10 + 8], 77
        call function_foo
        exit
        function_foo:
        ldxdw r0, [r10 - 4088]
        exit",
        config,
        NO_INPUT,
        TestContextObject::new(5),
        ProgramResult::Ok(77),
    );
}

#[test]
fn test_direct_stores() {
    for enable_address_translation in [false, true] {
        let config = Config {
            enable_address_translation,
            ..Config::default()
        };
        let mut input = [0; 16];
        println!("address translation enabled: {enable_address_translation}");
        test_interpreter_and_jit_asm!(
            "
            stb [r1], 0x11
            sth [r1 + 1], 0x3322
            stw [r1 + 3], 0x77665544
            stdw [r1 + 7], -1146447480
            ldxdw r0, [r1]
            ldxw r5, [r1+8]
            ldxh r6, [r1+12]
            ldxb r7, [r1+14]
            add64 r0, r5
            add64 r0, r6
            add64 r0, r7
            exit
            ",
            config,
            &raw mut input,
            TestContextObject::new(12),
            ProgramResult::Ok(0x8877665643efcda8),
        );
    }
}

#[test]
fn test_lddw_exceeding_budget() {
    use solana_sbpf::vm::{CallFrame, ExecutionMode};
    // `lddw` counts as one instruction over two slots, which the meter must not count until the
    // instruction is within the budget: the pc of `ExceededMaxInstructions` is that of the first
    // instruction past it.
    for sbpf_version in [SBPFVersion::V0, SBPFVersion::V3] {
        let config = Config {
            enabled_sbpf_versions: sbpf_version..=sbpf_version,
            ..Config::default()
        };
        for source in [
            r#"
            lddw r0, 1
            exit
            "#,
            r#"
            mov r0, 0
            mov r1, 0
            lddw r2, 1
            exit
            "#,
            r#"
            mov r0, 0
            lddw r1, 1
            lddw r2, 2
            exit
            "#,
        ] {
            let executable = assemble::<TestContextObject>(
                source,
                Arc::new(BuiltinProgram::new_loader(config.clone())),
            )
            .unwrap();
            executable.verify::<RequisiteVerifier>().unwrap();
            executable.jit_compile().unwrap();
            for budget in 0..5 {
                let mut results = Vec::new();
                for (name, mode) in [
                    ("interpreter", ExecutionMode::Interpreted),
                    ("jit", ExecutionMode::Jit),
                ] {
                    let mut context_object = TestContextObject::new(budget);
                    create_vm!(
                        vm,
                        &executable,
                        &mut context_object,
                        stack,
                        heap,
                        vec![],
                        None
                    );
                    let mut mode = mode;
                    let mut call_frames =
                        vec![CallFrame::default(); Config::default().max_call_depth];
                    let (count, result) =
                        vm.execute_program(&executable, &mut mode, &mut call_frames);
                    results.push((count, format!("{result:?}"), vm.registers[11]));
                    assert_eq!(
                        results[0],
                        results[results.len() - 1],
                        "{name}, {sbpf_version:?}, budget {budget}:{source}"
                    );
                }
            }
        }
    }
}

#[test]
fn test_entrypoint_in_lddw() {
    use solana_sbpf::vm::{CallFrame, ExecutionMode};
    // Nothing stops an entrypoint from pointing at the second half of an `lddw`, which the JITs
    // treat as an invalid jump target. Execution has to fail there as in the interpreter.
    let config = Config {
        enabled_sbpf_versions: SBPFVersion::V0..=SBPFVersion::V4,
        ..Config::default()
    };
    let program = [
        [0x18, 0x00, 0, 0, 1, 0, 0, 0], // lddw r0, 1
        [0x00, 0x00, 0, 0, 0, 0, 0, 0],
        [0x95, 0, 0, 0, 0, 0, 0, 0], // exit
    ]
    .concat();
    let mut function_registry = FunctionRegistry::default();
    function_registry
        .register_function(ebpf::hash_symbol_name(b"entrypoint"), *b"entrypoint", 1)
        .unwrap();
    let executable = Executable::<TestContextObject>::from_text_bytes(
        &program,
        Arc::new(BuiltinProgram::new_loader(config)),
        SBPFVersion::V0,
        function_registry,
    )
    .unwrap();
    assert_eq!(executable.get_entrypoint_instruction_offset(), 1);
    executable.verify::<RequisiteVerifier>().unwrap();
    executable.jit_compile().unwrap();
    let mut results = Vec::new();
    for (name, mode) in [
        ("interpreter", ExecutionMode::Interpreted),
        ("jit", ExecutionMode::Jit),
    ] {
        let mut context_object = TestContextObject::new(10);
        create_vm!(
            vm,
            &executable,
            &mut context_object,
            stack,
            heap,
            vec![],
            None
        );
        let mut mode = mode;
        let mut call_frames = vec![CallFrame::default(); Config::default().max_call_depth];
        let (count, result) = vm.execute_program(&executable, &mut mode, &mut call_frames);
        results.push((count, format!("{result:?}"), vm.registers[11]));
        assert_eq!(results[0], results[results.len() - 1], "{name}");
    }
}

#[cfg(all(feature = "jit", not(target_os = "windows"), target_arch = "x86_64"))]
#[test]
fn test_max_call_depth_zero() {
    use solana_sbpf::vm::{CallFrame, ExecutionMode};
    // FIXME: The interpreter panics.
    let config = Config {
        max_call_depth: 0,
        ..Config::default()
    };
    let executable = assemble::<TestContextObject>(
        "
        call function_foo
        exit
        function_foo:
        exit",
        Arc::new(BuiltinProgram::new_loader(config)),
    )
    .unwrap();
    executable.jit_compile().unwrap();
    {
        let mut context_object = TestContextObject::new(10);
        create_vm!(
            vm,
            &executable,
            &mut context_object,
            stack,
            heap,
            vec![],
            None
        );
        let mut call_frames = vec![CallFrame::default(); 1];
        let (_, result) =
            vm.execute_program(&executable, &mut ExecutionMode::Jit, &mut call_frames);
        let expected = ProgramResult::Err(EbpfError::CallDepthExceeded);
        assert_eq!(format!("{result:?}"), format!("{expected:?}"));
        assert_eq!(vm.registers[11], 0);
    }
}

// Copyright (c) Microsoft Corporation
// SPDX-License-Identifier: MIT

// Core conformance testing logic with executor callback interface.
// This file does NOT depend on Boost.Process.

#include <bpf_conformance_core/bpf_conformance.h>
#include <bpf_conformance_core/bpf_disassembler.h>
#include <bpf_conformance_core/bpf_test_parser.h>
#include <bpf_conformance_core/bpf_writer.h>
#include <bpf_conformance_core/opcode_names.h>

#include <iomanip>
#include <iostream>
#include <regex>
#include <set>
#include <sstream>
#include <string>
#include <vector>

// Section/function name constants
const std::string bpf_conformance_xdp_section_name = "xdp";
const std::string bpf_conformance_default_section_name = ".text";
const std::string bpf_conformance_default_function_name = "main";

/**
 * @brief Convert a vector of bytes to a string of hex bytes.
 */
static std::string
_base_16_encode(const std::vector<uint8_t>& data)
{
    std::stringstream result;
    for (auto byte : data) {
        result << std::hex << std::setw(2) << std::setfill('0') << (int)byte << " ";
        result << " ";
    }
    return result.str();
}

/**
 * @brief Convert a vector of ebpf instructions to a vector of bytes.
 */
static std::vector<uint8_t>
_ebpf_inst_to_byte_vector(const std::vector<ebpf_inst>& instructions)
{
    std::vector<uint8_t> result;
    for (auto instruction : instructions) {
        uint8_t* instruction_bytes = reinterpret_cast<uint8_t*>(&instruction);
        for (size_t i = 0; i < sizeof(ebpf_inst); i++) {
            result.push_back(instruction_bytes[i]);
        }
    }
    return result;
}

/**
 * @brief Convert a vector of ebpf instructions to an ELF file.
 */
static std::vector<uint8_t>
_ebpf_inst_to_elf_file(
    const std::string& section_name,
    const std::string& function_name,
    const std::vector<ebpf_inst>& instructions,
    const std::vector<std::tuple<std::string, ebpf_map_definition_in_file_t>>& maps,
    const std::map<size_t, std::string>& map_relocations)
{
    std::stringstream elf_file;
    bpf_writer_classic(elf_file, section_name, function_name, instructions, maps, map_relocations);
    std::string elf_file_string = elf_file.str();
    std::vector<uint8_t> result(elf_file_string.size());
    std::copy(elf_file_string.begin(), elf_file_string.end(), result.begin());
    return result;
}

static void
_log_debug_result(
    std::map<std::filesystem::path, std::tuple<bpf_conformance_test_result_t, std::string>> test_results,
    const std::filesystem::path& test)
{
    auto [result, message] = test_results[test];
    switch (result) {
    case bpf_conformance_test_result_t::TEST_RESULT_PASS:
        std::cout << "Test " << test << " succeeded" << std::endl;
        break;
    case bpf_conformance_test_result_t::TEST_RESULT_FAIL:
        std::cout << "Test " << test << " failed: " << message << std::endl;
        break;
    case bpf_conformance_test_result_t::TEST_RESULT_SKIP:
        std::cout << "Test " << test << " skipped: " << message << std::endl;
        break;
    case bpf_conformance_test_result_t::TEST_RESULT_ERROR:
        std::cout << "Test " << test << " error: " << message << std::endl;
        break;
    case bpf_conformance_test_result_t::TEST_RESULT_UNKNOWN:
        std::cout << "Test " << test << " result unknown: " << message << std::endl;
        break;
    }
}

/**
 * @brief Create a prolog that loads the packet memory into %R1 and the length into %R2.
 */
static std::vector<ebpf_inst>
_generate_xdp_prolog(size_t size)
{
    if (size > INT32_MAX) {
        throw std::runtime_error("Packet size too large");
    }
    return {
        {0xb7, 0x0, 0x0, 0x0, -1},
        {0xbf, 0x6, 0x1, 0x0, 0x0},
        {0x61, 0x1, 0x6, 0x0, 0x0},
        {0x61, 0x2, 0x6, 0x4, 0x0},
        {0xbf, 0x3, 0x1, 0x0, 0x0},
        {0x7, 0x3, 0x0, 0x0, static_cast<int>(size)},
        {0xbd, 0x3, 0x2, 0x1, 0x0},
        {0x95, 0x0, 0x0, 0x0, 0x0},
        {0xb7, 0x2, 0x0, 0x0, static_cast<int>(size)},
    };
}

std::optional<bpf_conformance_instruction_t>
get_instruction_conformance_info(ebpf_inst inst)
{
    auto instruction = std::find_if(instructions_from_spec.begin(), instructions_from_spec.end(), [&](const auto &instruction) {
        return (instruction.opcode == inst.opcode) &&
               (!needs_src(inst.opcode) || instruction.src == inst.src) &&
               (!needs_imm(inst.opcode) || instruction.imm == inst.imm) &&
               (!needs_offset(inst.opcode) || instruction.offset == inst.offset);
         });
    if (instruction == instructions_from_spec.end()) {
        return {};
    }
    return *instruction;
}

std::map<std::filesystem::path, std::tuple<bpf_conformance_test_result_t, std::string>>
bpf_conformance_run(
    const std::vector<std::filesystem::path>& test_files,
    bpf_conformance_executor_t executor,
    const bpf_conformance_options_t& options)
{
    std::set<bpf_conformance_instruction_t, InstCmp> instructions_used;
    std::set<bpf_conformance_instruction_t, InstCmp> instructions_not_used;
    std::map<std::filesystem::path, std::tuple<bpf_conformance_test_result_t, std::string>> test_results;

    for (auto& test : test_files) {
        // Check include/exclude regex BEFORE parsing to avoid exceptions from unrelated test files.
        if (options.include_test_regex.has_value()) {
            std::regex include_regex(options.include_test_regex.value_or(""));
            if (!std::regex_search(test.filename().string(), include_regex)) {
                test_results[test] = {bpf_conformance_test_result_t::TEST_RESULT_SKIP, "Skipped by include regex."};
                continue;
            }
        }

        if (options.exclude_test_regex.has_value()) {
            std::regex exclude_regex(options.exclude_test_regex.value_or(""));
            if (std::regex_search(test.filename().string(), exclude_regex)) {
                test_results[test] = {bpf_conformance_test_result_t::TEST_RESULT_SKIP, "Skipped by exclude regex."};
                continue;
            }
        }

        // Parse the test file and extract:
        // Input memory contents - Memory to pass to the BPF program.
        // Expected return value - Expected return value from the BPF program.
        // Expected error string - String returned by BPF runtime if the program fails.
        // BPF instructions - Instructions to pass to the BPF program.
        auto [input_memory, expected_return_value, expected_error_string, byte_code] = parse_test_file(test);

        // It the test file has no BPF instructions, then skip it.
        if (byte_code.size() == 0) {
            test_results[test] = {
                bpf_conformance_test_result_t::TEST_RESULT_SKIP, "Test file has no BPF instructions."};
            _log_debug_result(test_results, test);
            continue;
        }

        bpf_conformance_test_cpu_version_t required_cpu_version = bpf_conformance_test_cpu_version_t::v1;
        bpf_conformance_groups_t required_conformance_groups{};

        // Determine the required CPU version for the test.
        for (size_t i = 0; i < byte_code.size(); i++) {
            auto inst = byte_code[i];
            if (auto instruction = get_instruction_conformance_info(inst)) {
                bpf_conformance_test_cpu_version_t cpu_version = instruction->cpu_version;
                required_cpu_version = std::max(required_cpu_version, cpu_version);
                required_conformance_groups |= instruction->groups;
            }
            if (inst.opcode == EBPF_OP_LDDW) {
                // Instruction has a 64-bit immediate and takes two instructions slots.
                i++;
            }
        }

        // If the test requires a CPU version that is not supported by the current CPU version,
        // or an unsupported conformance group, then skip the test.
        if (required_cpu_version > options.cpu_version || (required_conformance_groups & ~options.groups) != bpf_conformance_groups_t::none) {
            test_results[test] = {
                bpf_conformance_test_result_t::TEST_RESULT_SKIP, "Test file contains unsupported instructions."};
            _log_debug_result(test_results, test);
            continue;
        }

        for (const auto& inst : byte_code) {
            instructions_used.insert(
                bpf_conformance_instruction_t(required_cpu_version, required_conformance_groups, inst));
        }

        // If the caller requires this as an XDP program, then add the prolog instructions.
        if (options.xdp_prolog && input_memory.size() > 0) {
            auto prolog_instructions = _generate_xdp_prolog(input_memory.size());
            byte_code.insert(byte_code.begin(), prolog_instructions.begin(), prolog_instructions.end());
        }

        // If caller requested debug output, then print the test file name, input memory, and BPF instructions.
        if (options.debug) {
            std::cerr << "Test file: " << test << std::endl;
            std::cerr << "Input memory: " << _base_16_encode(input_memory) << std::endl;
            std::cerr << "Expected return value: " << expected_return_value << std::endl;
            std::cerr << "Expected error string: " << expected_error_string << std::endl;
            std::cerr << "Byte code: " << _base_16_encode(_ebpf_inst_to_byte_vector(byte_code)) << std::endl;
            std::cerr << "Disassembly:" << std::endl;
            bpf_disassembler(byte_code, std::cerr, false);
        }

        std::string return_value_string;
        std::string error_string;

        // Build arguments for the executor
        std::vector<std::string> args;
        if (input_memory.size() > 0) {
            args.insert(args.begin(), _base_16_encode(input_memory));
        }
        if (options.elf_format) {
            args.push_back("--elf");
        }

        // Build the input data to send to the plugin
        std::string input_data;
        if (options.elf_format) {
            auto elf_bytes = _base_16_encode(_ebpf_inst_to_elf_file(
                options.xdp_prolog ? bpf_conformance_xdp_section_name : bpf_conformance_default_section_name,
                bpf_conformance_default_function_name,
                byte_code,
                {},
                {}));
            input_data = elf_bytes;
            if (options.debug) {
                std::cerr << "ELF-encoded bytes: " << elf_bytes << std::endl;
            }
        } else {
            input_data = _base_16_encode(_ebpf_inst_to_byte_vector(byte_code));
        }

        // Call the executor
        try {
            auto result = executor(input_data, args);
            return_value_string = result.stdout_output;
            error_string = result.stderr_output;

            // Strip the trailing newline from the return value.
            if (!return_value_string.empty() && return_value_string.back() == '\n') {
                return_value_string = return_value_string.substr(0, return_value_string.size() - 1);
            }

            // Strip the trailing newline from the error string.
            if (!error_string.empty() && error_string.back() == '\n') {
                error_string = error_string.substr(0, error_string.size() - 1);
            }

            // If the plugin returned a non-zero exit code, then check to see if the error string matches the expected
            // error string.
            if (result.exit_code != 0) {
                if (return_value_string.empty() && !error_string.empty()) {
                    return_value_string = error_string;
                }
                if (expected_error_string.empty()) {
                    test_results[test] = {
                        bpf_conformance_test_result_t::TEST_RESULT_ERROR,
                        "Plugin returned error code " + std::to_string(result.exit_code) + " and output " +
                            return_value_string};
                } else {
                    auto cr = return_value_string.find('\r');
                    if (cr != std::string::npos) {
                        return_value_string = return_value_string.substr(0, cr);
                    }

                    // Strip any trailing whitespace from the return value.
                    return_value_string = std::regex_replace(return_value_string, std::regex("\\s+$"), "");

                    if (expected_error_string == return_value_string) {
                        test_results[test] = {bpf_conformance_test_result_t::TEST_RESULT_PASS, ""};

                    } else {
                        test_results[test] = {
                            bpf_conformance_test_result_t::TEST_RESULT_FAIL,
                            "Plugin returned error code " + std::to_string(result.exit_code) + " and output " +
                                return_value_string + " but expected " + expected_error_string};
                    }
                }
                if (options.debug) {
                    auto [result_enum, message] = test_results[test];
                    std::cerr << "Test: \"" << test << "\" "
                              << (result_enum == bpf_conformance_test_result_t::TEST_RESULT_PASS ? "PASS" : "FAIL");
                    if (!message.empty()) {
                        std::cerr << "\n" << message;
                    }
                    std::cerr << std::endl;
                }

                _log_debug_result(test_results, test);
                continue;
            }
        } catch (const std::exception& e) {
            test_results[test] = {
                bpf_conformance_test_result_t::TEST_RESULT_ERROR,
                "Plugin failed to execute test with error " + std::string(e.what())};
            if (options.debug) {
                auto [result, message] = test_results[test];
                std::cerr << "Test: \"" << test << "\" "
                          << (result == bpf_conformance_test_result_t::TEST_RESULT_PASS ? "PASS" : "FAIL");
                if (!message.empty()) {
                    std::cerr << "\n" << message;
                }
                std::cerr << std::endl;
            }
            _log_debug_result(test_results, test);
            continue;
        }

        // Parse the return value from the plugin and compare it with the expected return value.
        uint64_t return_value = 0;
        try {
            return_value = static_cast<uint64_t>(std::stoull(return_value_string, nullptr, 16));
        } catch (const std::exception&) {
            test_results[test] = {
                bpf_conformance_test_result_t::TEST_RESULT_ERROR,
                "Plugin return value could not be parsed into a valid number (" + return_value_string + ")"};
            continue;
        }

        if (return_value != expected_return_value) {
            test_results[test] = {
                bpf_conformance_test_result_t::TEST_RESULT_FAIL,
                "Plugin returned incorrect return value " + std::to_string(return_value) + " expected " +
                    std::to_string(expected_return_value)};
        } else {
            test_results[test] = {bpf_conformance_test_result_t::TEST_RESULT_PASS, ""};
        }
        _log_debug_result(test_results, test);
    }

    // Compute list of opcodes not used in tests.
    for (auto& instruction : instructions_from_spec) {
        if (instructions_used.find(instruction) == instructions_used.end()) {
            instructions_not_used.insert(instruction);
        }
    }

    // If the caller asked for a list of opcodes used by the tests, then print the list.
    if (options.list_instructions_option == bpf_conformance_list_instructions_t::LIST_INSTRUCTIONS_USED ||
        options.list_instructions_option == bpf_conformance_list_instructions_t::LIST_INSTRUCTIONS_ALL) {
        std::cout << "Instructions used by tests:" << std::endl;
        for (auto instruction : instructions_used) {
            std::cout << instruction_to_name(instruction) << std::endl;
        }
    }

    if (options.list_instructions_option == bpf_conformance_list_instructions_t::LIST_INSTRUCTIONS_UNUSED ||
        options.list_instructions_option == bpf_conformance_list_instructions_t::LIST_INSTRUCTIONS_ALL) {
        std::cout << "Instructions not used by tests:" << std::endl;
        for (auto instruction : instructions_not_used) {
            std::cout << instruction_to_name(instruction) << std::endl;
        }
    }

    return test_results;
}
